package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Comprobante;

import java.util.List;

public interface IComprobanteService extends ICrudGenericoService<Comprobante, String> {
    List<ComboBoxOption> listarCombobox();
}
