package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum EstadoPago {
    PENDIENTE("Pendiente"),
    PAGADO("Pagado"),
    ANULADO("Anulado");

    private final String descripcion;

    EstadoPago(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
