package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Comprobante;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.ComprobanteRepository;
import pe.edu.upeu.systransporte.service.IComprobanteService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class ComprobanteServiceImp extends CrudGenericoServiceImp<Comprobante, String> implements IComprobanteService {

    private final ComprobanteRepository repo;

    @Override
    protected ICrudGenericoRepository<Comprobante, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Comprobante x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdComprobante()), x.getNumero()));
        }
        return listar;
    }
}
