package pe.edu.upeu.systransporte;

import javafx.application.Application;

public class App {
    public static void main(String[] args) {
        Application.launch(SysTransporte.class, args);
    }
}
