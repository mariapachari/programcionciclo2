package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Usuario;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.UsuarioRepository;
import pe.edu.upeu.systransporte.security.ControlIntentosLogin;
import pe.edu.upeu.systransporte.security.PasswordEncoder;
import pe.edu.upeu.systransporte.service.IUsuarioService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
public class UsuarioServiceImp extends CrudGenericoServiceImp<Usuario, String> implements IUsuarioService {

    private final UsuarioRepository repo;
    private final ControlIntentosLogin intentos = new ControlIntentosLogin();

    @Override
    protected ICrudGenericoRepository<Usuario, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Usuario x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdUsuario()), x.getUsuario()));
        }
        return listar;
    }

    /**
     * Login seguro: busca al usuario por nombre y compara la clave escrita con el
     * hash PBKDF2 guardado. Controla intentos fallidos (bloqueo temporal).
     *
     * @throws IllegalStateException    si el usuario está bloqueado
     * @throws IllegalArgumentException si las credenciales son incorrectas
     */
    @Override
    public Optional<Usuario> loginUsuario(String usuario, String clave) {
        if (usuario == null || usuario.isBlank() || clave == null || clave.isBlank()) {
            throw new IllegalArgumentException("Ingrese usuario y clave");
        }
        long espera = intentos.segundosBloqueo(usuario);
        if (espera > 0) {
            throw new IllegalStateException("Usuario bloqueado por intentos fallidos. Espere " + espera + " segundos");
        }
        Optional<Usuario> encontrado = repo.findByUsuario(usuario)
                .filter(u -> PasswordEncoder.verificar(clave, u.getClave()));
        if (encontrado.isPresent()) {
            intentos.registrarExito(usuario);
            return encontrado;
        }
        int quedan = intentos.registrarFallo(usuario);
        if (quedan == 0) {
            throw new IllegalStateException("Demasiados intentos fallidos. Usuario bloqueado "
                    + ControlIntentosLogin.SEGUNDOS_BLOQUEO + " segundos");
        }
        throw new IllegalArgumentException("Usuario o clave incorrectos. Le quedan " + quedan + " intento(s)");
    }

    /** Encripta las claves que aún estén en texto plano (bases de versiones anteriores). */
    @Override
    public int migrarClavesPlanas() {
        int n = 0;
        for (Usuario u : repo.findAll()) {
            if (u.getClave() != null && !PasswordEncoder.estaEncriptada(u.getClave())) {
                u.setClave(PasswordEncoder.encriptar(u.getClave()));
                repo.update(u);
                n++;
            }
        }
        return n;
    }

    // ===== MEJORA: evitar registros duplicados =====
    private void validarDuplicado(Usuario x) {
        if (repo.existeDuplicado("usuario", x.getUsuario(), x.getIdUsuario())) {
            throw new IllegalArgumentException("El nombre de usuario '" + x.getUsuario() + "' ya está en uso");
        }
    }

    @Override
    public Usuario save(Usuario x) {
        validarDuplicado(x);
        if (x.getClave() == null || x.getClave().isBlank()) {
            throw new IllegalArgumentException("La clave es obligatoria");
        }
        x.setClave(PasswordEncoder.encriptar(x.getClave()));   // nunca se guarda en texto plano
        return super.save(x);
    }

    @Override
    public Usuario update(String id, Usuario x) {
        validarDuplicado(x);
        if (x.getClave() == null || x.getClave().isBlank()) {
            // Clave vacía al editar = se mantiene la clave actual
            x.setClave(repo.findById(id).map(Usuario::getClave)
                    .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado: " + id)));
        } else if (!PasswordEncoder.estaEncriptada(x.getClave())) {
            x.setClave(PasswordEncoder.encriptar(x.getClave()));
        }
        return super.update(id, x);
    }
}
