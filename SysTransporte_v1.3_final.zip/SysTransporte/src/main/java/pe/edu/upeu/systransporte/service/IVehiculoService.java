package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Vehiculo;

import java.util.List;

public interface IVehiculoService extends ICrudGenericoService<Vehiculo, String> {
    List<ComboBoxOption> listarCombobox();
}
