package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum TipoVehiculo {
    CAMION("Camión"),
    FURGON("Furgón"),
    TRAILER("Tráiler"),
    CAMIONETA("Camioneta");

    private final String descripcion;

    TipoVehiculo(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
