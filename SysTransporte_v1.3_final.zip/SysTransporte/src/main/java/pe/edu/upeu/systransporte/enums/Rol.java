package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum Rol {
    ADMINISTRADOR("Administrador"),
    OPERADOR("Operador"),
    CONDUCTOR("Conductor");

    private final String descripcion;

    Rol(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
