package pe.edu.upeu.systransporte.components;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * INVESTIGACIÓN ADICIONAL N° 2 — Paginación de tablas.
 *
 * <p>En vez de mostrar todos los registros a la vez, la tabla muestra una
 * <b>página</b> de N filas (5, 10, 20 o 50) y una barra de navegación:
 * <pre>  «  ‹   Página 1 de 3 (25 registros)   ›  »   Filas: [10]</pre>
 *
 * <p>Uso en cualquier controlador (2 líneas):
 * <pre>
 *   paginador = new PaginadorTabla&lt;&gt;(tableView);   // en initialize()
 *   paginador.setDatos(listaFiltrada);              // en filtrar()
 * </pre>
 * La barra se inserta automáticamente debajo de la tabla, sin tocar el FXML.
 * El filtro de búsqueda se aplica sobre TODOS los registros y luego se pagina.
 */
public class PaginadorTabla<T> {

    public static final int FILAS_POR_DEFECTO = 10;

    private final TableView<T> tabla;
    private List<T> datos = List.of();
    private int paginaActual = 0;
    private int filasPorPagina = FILAS_POR_DEFECTO;

    private final Button btnPrimero = boton("«", "Primera página");
    private final Button btnAnterior = boton("‹", "Página anterior");
    private final Button btnSiguiente = boton("›", "Página siguiente");
    private final Button btnUltimo = boton("»", "Última página");
    private final Label lblInfo = new Label();
    private final ComboBox<Integer> cbxFilas = new ComboBox<>(FXCollections.observableArrayList(5, 10, 20, 50));
    private final HBox barra;

    public PaginadorTabla(TableView<T> tabla) {
        this.tabla = tabla;
        cbxFilas.setValue(filasPorPagina);
        cbxFilas.setTooltip(new Tooltip("Cantidad de filas por página"));
        cbxFilas.valueProperty().addListener((o, a, n) -> {
            if (n != null) {
                filasPorPagina = n;
                irA(0);
            }
        });
        btnPrimero.setOnAction(e -> irA(0));
        btnAnterior.setOnAction(e -> irA(paginaActual - 1));
        btnSiguiente.setOnAction(e -> irA(paginaActual + 1));
        btnUltimo.setOnAction(e -> irA(totalPaginas() - 1));
        lblInfo.setMinWidth(220);
        lblInfo.setAlignment(Pos.CENTER);
        lblInfo.setStyle("-fx-font-weight: bold;");

        Region espacio = new Region();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        barra = new HBox(6, btnPrimero, btnAnterior, lblInfo, btnSiguiente, btnUltimo, espacio,
                new Label("Filas por página:"), cbxFilas);
        barra.setAlignment(Pos.CENTER_LEFT);
        barra.setPadding(new Insets(4, 2, 2, 2));
        barra.getStyleClass().add("barra-paginacion");
        insertarDebajoDeLaTabla();
        actualizar();
    }

    /** Recibe la lista completa (ya filtrada) y muestra la primera página. */
    public void setDatos(List<T> nuevosDatos) {
        this.datos = nuevosDatos == null ? List.of() : nuevosDatos;
        irA(0);
    }

    public void irA(int pagina) {
        int total = totalPaginas();
        paginaActual = Math.max(0, Math.min(pagina, total - 1));
        actualizar();
    }

    public int getPaginaActual() { return paginaActual; }

    public int totalPaginas() {
        return Math.max(1, (int) Math.ceil(datos.size() / (double) filasPorPagina));
    }

    private void actualizar() {
        int desde = paginaActual * filasPorPagina;
        int hasta = Math.min(desde + filasPorPagina, datos.size());
        tabla.setItems(FXCollections.observableArrayList(desde < hasta ? datos.subList(desde, hasta) : List.of()));
        lblInfo.setText(datos.isEmpty() ? "Sin registros"
                : "Página " + (paginaActual + 1) + " de " + totalPaginas()
                + "  (" + (desde + 1) + "-" + hasta + " de " + datos.size() + ")");
        boolean esPrimera = paginaActual == 0, esUltima = paginaActual >= totalPaginas() - 1;
        btnPrimero.setDisable(esPrimera);
        btnAnterior.setDisable(esPrimera);
        btnSiguiente.setDisable(esUltima);
        btnUltimo.setDisable(esUltima);
    }

    /** Envuelve la tabla en un VBox (tabla + barra) en el mismo lugar del FXML. */
    private void insertarDebajoDeLaTabla() {
        Parent padre = tabla.getParent();
        if (!(padre instanceof Pane contenedor)) {
            return;
        }
        int idx = contenedor.getChildren().indexOf(tabla);
        Priority hgrow = HBox.getHgrow(tabla);
        Priority vgrow = VBox.getVgrow(tabla);
        Double top = AnchorPane.getTopAnchor(tabla), bottom = AnchorPane.getBottomAnchor(tabla);
        Double left = AnchorPane.getLeftAnchor(tabla), right = AnchorPane.getRightAnchor(tabla);

        contenedor.getChildren().remove(tabla);
        VBox caja = new VBox(2, tabla, barra);
        VBox.setVgrow(tabla, Priority.ALWAYS);
        HBox.setHgrow(caja, hgrow);
        VBox.setVgrow(caja, vgrow);
        AnchorPane.setTopAnchor(caja, top);
        AnchorPane.setBottomAnchor(caja, bottom);
        AnchorPane.setLeftAnchor(caja, left);
        AnchorPane.setRightAnchor(caja, right);
        contenedor.getChildren().add(idx, (Node) caja);
    }

    private static Button boton(String texto, String ayuda) {
        Button b = new Button(texto);
        b.setTooltip(new Tooltip(ayuda));
        b.setMinWidth(34);
        b.setFocusTraversable(false);
        return b;
    }
}
