package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla "manifiesto".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Manifiesto {
    private String idGuia;

    private String numeroGuia;

    @NotNull(message = "Seleccione el viaje")
    private Viaje idViaje;

    @NotNull(message = "La fecha de emisión es obligatoria")
    private LocalDate fechaEmision;

    @NotNull(message = "El estado es obligatorio")
    private EstadoManifiesto estado;
}
