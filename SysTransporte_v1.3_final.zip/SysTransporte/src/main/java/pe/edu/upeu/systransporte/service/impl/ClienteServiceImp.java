package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Cliente;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.ClienteRepository;
import pe.edu.upeu.systransporte.service.IClienteService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class ClienteServiceImp extends CrudGenericoServiceImp<Cliente, String> implements IClienteService {

    private final ClienteRepository repo;

    @Override
    protected ICrudGenericoRepository<Cliente, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Cliente x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdCliente()), x.getRazonSocial() + " - RUC " + x.getRuc()));
        }
        return listar;
    }

    // ===== MEJORA: evitar registros duplicados =====
    private void validarDuplicado(Cliente x) {
        if (repo.existeDuplicado("ruc", x.getRuc(), x.getIdCliente())) {
            throw new IllegalArgumentException("Ya existe un cliente con el RUC " + x.getRuc());
        }
    }

    @Override
    public Cliente save(Cliente x) {
        validarDuplicado(x);
        return super.save(x);
    }

    @Override
    public Cliente update(String id, Cliente x) {
        validarDuplicado(x);
        return super.update(id, x);
    }
}
