package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Paquete;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.PaqueteRepository;
import pe.edu.upeu.systransporte.service.IPaqueteService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class PaqueteServiceImp extends CrudGenericoServiceImp<Paquete, Long> implements IPaqueteService {

    private final PaqueteRepository repo;

    @Override
    protected ICrudGenericoRepository<Paquete, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Paquete x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdPaquete()), x.getDescripcion()));
        }
        return listar;
    }

    // ===== MEJORA: la suma de pesos de los paquetes no supera el peso de la encomienda =====
    private void validarPeso(Paquete p) {
        double pesoEncomienda = p.getIdEncomienda().getPesoTon() == null ? 0 : p.getIdEncomienda().getPesoTon();
        double yaRegistrado = repo.pesoPaquetesDeEncomienda(p.getIdEncomienda().getIdEncomienda(), p.getIdPaquete());
        if (yaRegistrado + p.getPesoTon() > pesoEncomienda) {
            throw new IllegalArgumentException(String.format(
                    "Peso excedido: la encomienda pesa %.2f t y sus paquetes ya suman %.2f t", pesoEncomienda, yaRegistrado));
        }
    }

    @Override
    public Paquete save(Paquete p) {
        validarPeso(p);
        return super.save(p);
    }

    @Override
    public Paquete update(Long id, Paquete p) {
        validarPeso(p);
        return super.update(id, p);
    }
}
