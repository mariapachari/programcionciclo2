package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Movimiento;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.MovimientoRepository;
import pe.edu.upeu.systransporte.repository.EncomiendaRepository;
import pe.edu.upeu.systransporte.service.IMovimientoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class MovimientoServiceImp extends CrudGenericoServiceImp<Movimiento, Long> implements IMovimientoService {

    private final MovimientoRepository repo;
    private final EncomiendaRepository encomiendaRepository;

    @Override
    protected ICrudGenericoRepository<Movimiento, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Movimiento x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdMovimiento()), x.getObservacion()));
        }
        return listar;
    }

    /** Al registrar un movimiento, la encomienda toma el nuevo estado. */
    @Override
    public Movimiento save(Movimiento m) {
        Movimiento guardado = super.save(m);
        encomiendaRepository.actualizarEstado(m.getIdEncomienda().getIdEncomienda(), m.getEstado().name());
        return guardado;
    }
}
