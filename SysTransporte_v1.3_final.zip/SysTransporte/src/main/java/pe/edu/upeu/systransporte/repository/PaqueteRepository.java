package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class PaqueteRepository extends AbstractJpaRepository<Paquete, Long> {

    @Override
    protected String getTableName() { return "paquetes"; }

    @Override
    protected String getPkColumn() { return "id_paquete"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", en.descripcionCarga AS en_descripcionCarga" +
                    " FROM paquetes t " +
                    "JOIN encomienda en ON t.id_encomienda = en.id_encomienda ";

    @Override
    public List<Paquete> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.id_paquete DESC");
    }

    @Override
    public Optional<Paquete> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_paquete = ?", id);
    }

    @Override
    protected Paquete mapRow(ResultSet rs) throws SQLException {
        return Paquete.builder()
                .idPaquete(rs.getLong("id_paquete"))
                .idEncomienda(Encomienda.builder()
                        .idEncomienda(rs.getLong("id_encomienda"))
                        .descripcionCarga(rs.getString("en_descripcionCarga"))
                        .build())
                .descripcion(rs.getString("descripcion"))
                .cantidad(rs.getInt("cantidad"))
                .pesoTon(rs.getDouble("pesoTon"))
                .build();
    }

    @Override
    protected Paquete insert(Connection conn, Paquete e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO paquetes(id_encomienda, descripcion, cantidad, pesoTon) VALUES(?, ?, ?, ?)",
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getDescripcion(),
                e.getCantidad(),
                e.getPesoTon());
        e.setIdPaquete(id);
        return e;
    }

    @Override
    protected Paquete updateRow(Connection conn, Paquete e) throws SQLException {
        executeUpdate(conn,
                "UPDATE paquetes SET id_encomienda = ?, descripcion = ?, cantidad = ?, pesoTon = ? WHERE id_paquete = ?",
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getDescripcion(),
                e.getCantidad(),
                e.getPesoTon(),
                e.getIdPaquete());
        return e;
    }

    /** MEJORA: suma el peso (t) de los paquetes de una encomienda, sin contar el que se edita. */
    public double pesoPaquetesDeEncomienda(Long idEncomienda, Long excluirId) {
        return executeScalarDouble(
                "SELECT COALESCE(SUM(pesoTon), 0) FROM paquetes WHERE id_encomienda = ? AND id_paquete <> ?",
                idEncomienda, excluirId == null ? -1L : excluirId);
    }
}
