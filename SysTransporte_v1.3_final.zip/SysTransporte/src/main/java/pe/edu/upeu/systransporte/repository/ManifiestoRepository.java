package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class ManifiestoRepository extends AbstractJpaRepository<Manifiesto, String> {

    @Override
    protected String getTableName() { return "manifiesto"; }

    @Override
    protected String getPkColumn() { return "idGuia"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", vi.origen AS vi_origen" +
                    ", vi.destino AS vi_destino" +
                    " FROM manifiesto t " +
                    "JOIN viajes vi ON t.idViaje = vi.idViaje ";

    @Override
    public List<Manifiesto> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idGuia DESC");
    }

    @Override
    public Optional<Manifiesto> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idGuia = ?", id);
    }

    @Override
    protected Manifiesto mapRow(ResultSet rs) throws SQLException {
        return Manifiesto.builder()
                .idGuia(rs.getString("idGuia"))
                .numeroGuia(rs.getString("numeroGuia"))
                .idViaje(Viaje.builder()
                        .idViaje(rs.getString("idViaje"))
                        .origen(rs.getString("vi_origen"))
                        .destino(rs.getString("vi_destino"))
                        .build())
                .fechaEmision(rs.getObject("fechaEmision", LocalDate.class))
                .estado(toEnum(EstadoManifiesto.class, rs.getString("estado")))
                .build();
    }

    @Override
    protected Manifiesto insert(Connection conn, Manifiesto e) throws SQLException {
        if (e.getIdGuia() == null || e.getIdGuia().isBlank()) {
            e.setIdGuia(generarCodigo(conn, "GUI"));
        }
        if (e.getNumeroGuia() == null || e.getNumeroGuia().isBlank()) {
            e.setNumeroGuia(generarCorrelativo(conn, "numeroGuia", "T001"));
        }
        executeUpdate(conn,
                "INSERT INTO manifiesto(idGuia, numeroGuia, idViaje, fechaEmision, estado) VALUES(?, ?, ?, ?, ?)",
                e.getIdGuia(),
                e.getNumeroGuia(),
                e.getIdViaje() == null ? null : e.getIdViaje().getIdViaje(),
                e.getFechaEmision(),
                enumName(e.getEstado()));
        return e;
    }

    @Override
    protected Manifiesto updateRow(Connection conn, Manifiesto e) throws SQLException {
        executeUpdate(conn,
                "UPDATE manifiesto SET idViaje = ?, fechaEmision = ?, estado = ? WHERE idGuia = ?",
                e.getIdViaje() == null ? null : e.getIdViaje().getIdViaje(),
                e.getFechaEmision(),
                enumName(e.getEstado()),
                e.getIdGuia());
        return e;
    }
}
