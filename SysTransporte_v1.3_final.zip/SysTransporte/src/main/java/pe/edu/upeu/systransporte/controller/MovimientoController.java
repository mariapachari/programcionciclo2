package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.dto.SessionManager;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.Movimiento;
import pe.edu.upeu.systransporte.model.Usuario;
import pe.edu.upeu.systransporte.service.IMovimientoService;
import pe.edu.upeu.systransporte.service.IEncomiendaService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_movimiento.fxml — Seguimiento (Movimientos).
 */
@RequiredArgsConstructor
public class MovimientoController {
    private final IMovimientoService movimientoService;
    private final IEncomiendaService encomiendaService;

    @FXML
    TextField txtObservacion, txtFiltroDato;
    @FXML
    DatePicker dpFechaMovimiento;
    @FXML
    ComboBox<ComboBoxOption> cbxIdEncomienda, cbxEstado;

    @FXML
    private TableView<Movimiento> tableView;
    private PaginadorTabla<Movimiento> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Movimiento> listaMovimiento = FXCollections.observableArrayList();
    Movimiento formulario;
    Long idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdEncomienda.getItems().addAll(encomiendaService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdEncomienda);
        dpFechaMovimiento.setValue(LocalDate.now());
        cbxEstado.getItems().addAll(ComboHelper.desdeEnum(EstadoEncomienda.class));

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Movimiento> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idMovimiento", 80.0));
        columns.put("Encomienda", new ColumnInfo("idEncomienda.descripcionCarga", 200.0));
        columns.put("Usuario", new ColumnInfo("idUsuario.usuario", 100.0));
        columns.put("Fecha", new ColumnInfo("fechaMovimiento", 100.0));
        columns.put("Nuevo estado", new ColumnInfo("estado", 110.0));
        columns.put("Observación", new ColumnInfo("observacion", 220.0));

        Consumer<Movimiento> updateAction = this::editForm;
        Consumer<Movimiento> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaMovimiento = FXCollections.observableArrayList(movimientoService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaMovimiento
                : listaMovimiento.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Movimiento();
        String kIdEncomienda = ComboHelper.keySeleccionado(cbxIdEncomienda);
        formulario.setIdEncomienda(kIdEncomienda == null ? null : encomiendaService.findById(Long.parseLong(kIdEncomienda)));
        formulario.setIdUsuario(Usuario.builder()
                .idUsuario(SessionManager.getInstance().getUserId())
                .usuario(SessionManager.getInstance().getUserName())
                .build());
        formulario.setFechaMovimiento(dpFechaMovimiento.getValue());
        String kEstado = ComboHelper.keySeleccionado(cbxEstado);
        formulario.setEstado(kEstado == null ? null : EstadoEncomienda.valueOf(kEstado));
        formulario.setObservacion(txtObservacion.getText() == null ? null : txtObservacion.getText().trim());

        Set<ConstraintViolation<Movimiento>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Movimiento>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxIdEncomienda.getSelectionModel().clearSelection();
        dpFechaMovimiento.setValue(LocalDate.now());
        cbxEstado.getSelectionModel().clearSelection();
        txtObservacion.clear();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Movimiento x) {
        ComboHelper.seleccionar(cbxIdEncomienda, x.getIdEncomienda() == null ? null : x.getIdEncomienda().getIdEncomienda());
        dpFechaMovimiento.setValue(x.getFechaMovimiento());
        ComboHelper.seleccionar(cbxEstado, x.getEstado());
        txtObservacion.setText(x.getObservacion());
        idCE = x.getIdMovimiento();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Movimiento x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdMovimiento() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            movimientoService.delete(x.getIdMovimiento());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Movimiento>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("idEncomienda", cbxIdEncomienda);
        campos.put("fechaMovimiento", dpFechaMovimiento);
        campos.put("estado", cbxEstado);
        campos.put("observacion", txtObservacion);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdMovimiento(idCE);
                movimientoService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                movimientoService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxIdEncomienda, dpFechaMovimiento, cbxEstado, txtObservacion)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
