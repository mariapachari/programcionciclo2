package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Persona;

import java.util.List;

public interface IPersonaService extends ICrudGenericoService<Persona, Long> {
    List<ComboBoxOption> listarCombobox();
}
