package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.DetalleManifiesto;
import pe.edu.upeu.systransporte.model.Encomienda;
import pe.edu.upeu.systransporte.model.Manifiesto;
import pe.edu.upeu.systransporte.model.Viaje;
import pe.edu.upeu.systransporte.service.IDetalleManifiestoService;
import pe.edu.upeu.systransporte.service.IEncomiendaService;
import pe.edu.upeu.systransporte.service.IManifiestoService;
import pe.edu.upeu.systransporte.service.IViajeService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_manifiesto.fxml — Manifiestos de Carga.
 */
@RequiredArgsConstructor
public class ManifiestoController {
    private final IManifiestoService manifiestoService;
    private final IViajeService viajeService;
    private final IDetalleManifiestoService detalleManifiestoService;   // para imprimir: carga de la guía
    private final IEncomiendaService encomiendaService;                 // para imprimir: destinatario y destino

    @FXML
    TextField txtFiltroDato;
    @FXML
    DatePicker dpFechaEmision;
    @FXML
    ComboBox<ComboBoxOption> cbxIdViaje, cbxEstado;

    @FXML
    private TableView<Manifiesto> tableView;
    private PaginadorTabla<Manifiesto> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Manifiesto> listaManifiesto = FXCollections.observableArrayList();
    Manifiesto formulario;
    String idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdViaje.getItems().addAll(viajeService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdViaje);
        dpFechaEmision.setValue(LocalDate.now());
        cbxEstado.getItems().addAll(ComboHelper.desdeEnum(EstadoManifiesto.class));

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Manifiesto> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idGuia", 80.0));
        columns.put("N° Guía", new ColumnInfo("numeroGuia", 120.0));
        columns.put("Viaje", new ColumnInfo("idViaje.idViaje", 100.0));
        columns.put("Fecha emisión", new ColumnInfo("fechaEmision", 110.0));
        columns.put("Estado", new ColumnInfo("estado", 100.0));

        Consumer<Manifiesto> updateAction = this::editForm;
        Consumer<Manifiesto> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaManifiesto = FXCollections.observableArrayList(manifiestoService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaManifiesto
                : listaManifiesto.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Manifiesto();
        String kIdViaje = ComboHelper.keySeleccionado(cbxIdViaje);
        formulario.setIdViaje(kIdViaje == null ? null : viajeService.findById(kIdViaje));
        formulario.setFechaEmision(dpFechaEmision.getValue());
        String kEstado = ComboHelper.keySeleccionado(cbxEstado);
        formulario.setEstado(kEstado == null ? null : EstadoManifiesto.valueOf(kEstado));

        Set<ConstraintViolation<Manifiesto>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Manifiesto>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxIdViaje.getSelectionModel().clearSelection();
        dpFechaEmision.setValue(LocalDate.now());
        cbxEstado.getSelectionModel().clearSelection();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Manifiesto x) {
        ComboHelper.seleccionar(cbxIdViaje, x.getIdViaje() == null ? null : x.getIdViaje().getIdViaje());
        dpFechaEmision.setValue(x.getFechaEmision());
        ComboHelper.seleccionar(cbxEstado, x.getEstado());
        idCE = x.getIdGuia();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Manifiesto x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdGuia() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            manifiestoService.delete(x.getIdGuia());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Manifiesto>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("idViaje", cbxIdViaje);
        campos.put("fechaEmision", dpFechaEmision);
        campos.put("estado", cbxEstado);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdGuia(idCE);
                manifiestoService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                manifiestoService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    /** Imprime el manifiesto seleccionado en la tabla con toda la carga asignada. */
    @FXML
    public void imprimir() {
        stage = (Stage) miContenedor.getScene().getWindow();
        Manifiesto m = tableView.getSelectionModel().getSelectedItem();
        if (m == null) {
            lbnMsg.setText("Seleccione en la tabla el manifiesto que desea imprimir");
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            return;
        }
        try {
            // Viaje completo (conductor, placa, capacidad)
            Viaje viaje = viajeService.findById(m.getIdViaje().getIdViaje());

            // Detalles (encomiendas) que pertenecen a esta guía
            List<DetalleManifiesto> detalles = detalleManifiestoService.findAll().stream()
                    .filter(d -> d.getIdGuia() != null && Objects.equals(d.getIdGuia().getIdGuia(), m.getIdGuia()))
                    .sorted(Comparator.comparing(DetalleManifiesto::getIdDetalleManifiesto))
                    .toList();

            // Datos completos de cada encomienda (destinatario, destino)
            Map<Long, Encomienda> encomiendas = new HashMap<>();
            for (DetalleManifiesto d : detalles) {
                if (d.getIdEncomienda() == null) continue;
                Long id = d.getIdEncomienda().getIdEncomienda();
                if (!encomiendas.containsKey(id)) encomiendas.put(id, encomiendaService.findById(id));
            }

            ImpresionHelper.vistaPrevia(stage, "Manifiesto " + m.getNumeroGuia(),
                    ImpresionHelper.documentoManifiesto(m, viaje, detalles, encomiendas));
            lbnMsg.setText("");
        } catch (RuntimeException ex) {
            lbnMsg.setText("No se pudo preparar la impresión: " + ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxIdViaje, dpFechaEmision, cbxEstado)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
