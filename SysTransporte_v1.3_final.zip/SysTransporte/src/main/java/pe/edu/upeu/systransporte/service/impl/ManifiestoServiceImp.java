package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Manifiesto;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.ManifiestoRepository;
import pe.edu.upeu.systransporte.service.IManifiestoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class ManifiestoServiceImp extends CrudGenericoServiceImp<Manifiesto, String> implements IManifiestoService {

    private final ManifiestoRepository repo;

    @Override
    protected ICrudGenericoRepository<Manifiesto, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Manifiesto x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdGuia()), x.getNumeroGuia() + " - " + x.getIdViaje().getOrigen() + " → " + x.getIdViaje().getDestino()));
        }
        return listar;
    }
}
