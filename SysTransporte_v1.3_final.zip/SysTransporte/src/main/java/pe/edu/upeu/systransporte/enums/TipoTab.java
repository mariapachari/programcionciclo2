package pe.edu.upeu.systransporte.enums;

public enum TipoTab {
    INTERNO,
    EXTERNO
}
