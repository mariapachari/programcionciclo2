package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum TipoComprobante {
    BOLETA("Boleta"),
    FACTURA("Factura");

    private final String descripcion;

    TipoComprobante(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
