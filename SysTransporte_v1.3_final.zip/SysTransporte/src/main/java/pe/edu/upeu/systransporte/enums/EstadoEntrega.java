package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum EstadoEntrega {
    ENTREGADO("Entregado"),
    PENDIENTE("Pendiente"),
    RECHAZADO("Rechazado");

    private final String descripcion;

    EstadoEntrega(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
