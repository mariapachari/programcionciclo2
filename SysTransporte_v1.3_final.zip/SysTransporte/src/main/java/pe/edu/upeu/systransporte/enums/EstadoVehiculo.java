package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum EstadoVehiculo {
    DISPONIBLE("Disponible"),
    EN_RUTA("En ruta"),
    MANTENIMIENTO("Mantenimiento");

    private final String descripcion;

    EstadoVehiculo(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
