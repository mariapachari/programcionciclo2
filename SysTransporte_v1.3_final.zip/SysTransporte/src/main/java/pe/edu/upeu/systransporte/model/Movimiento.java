package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla "movimiento".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Movimiento {
    private Long idMovimiento;

    @NotNull(message = "Seleccione la encomienda")
    private Encomienda idEncomienda;

    @NotNull(message = "No hay usuario en sesión")
    private Usuario idUsuario;

    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fechaMovimiento;

    @NotNull(message = "Seleccione el nuevo estado")
    private EstadoEncomienda estado;

    @Size(max = 100, message = "Máximo 100 caracteres")
    private String observacion;
}
