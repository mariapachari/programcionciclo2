package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class GastoRepository extends AbstractJpaRepository<Gasto, String> {

    @Override
    protected String getTableName() { return "gastos"; }

    @Override
    protected String getPkColumn() { return "idGasto"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", vi.origen AS vi_origen" +
                    ", vi.destino AS vi_destino" +
                    " FROM gastos t " +
                    "JOIN viajes vi ON t.idViaje = vi.idViaje ";

    @Override
    public List<Gasto> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idGasto DESC");
    }

    @Override
    public Optional<Gasto> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idGasto = ?", id);
    }

    @Override
    protected Gasto mapRow(ResultSet rs) throws SQLException {
        return Gasto.builder()
                .idGasto(rs.getString("idGasto"))
                .idViaje(Viaje.builder()
                        .idViaje(rs.getString("idViaje"))
                        .origen(rs.getString("vi_origen"))
                        .destino(rs.getString("vi_destino"))
                        .build())
                .concepto(rs.getString("concepto"))
                .monto(rs.getDouble("monto"))
                .fecha(rs.getObject("fecha", LocalDate.class))
                .build();
    }

    @Override
    protected Gasto insert(Connection conn, Gasto e) throws SQLException {
        if (e.getIdGasto() == null || e.getIdGasto().isBlank()) {
            e.setIdGasto(generarCodigo(conn, "GAS"));
        }
        executeUpdate(conn,
                "INSERT INTO gastos(idGasto, idViaje, concepto, monto, fecha) VALUES(?, ?, ?, ?, ?)",
                e.getIdGasto(),
                e.getIdViaje() == null ? null : e.getIdViaje().getIdViaje(),
                e.getConcepto(),
                e.getMonto(),
                e.getFecha());
        return e;
    }

    @Override
    protected Gasto updateRow(Connection conn, Gasto e) throws SQLException {
        executeUpdate(conn,
                "UPDATE gastos SET idViaje = ?, concepto = ?, monto = ?, fecha = ? WHERE idGasto = ?",
                e.getIdViaje() == null ? null : e.getIdViaje().getIdViaje(),
                e.getConcepto(),
                e.getMonto(),
                e.getFecha(),
                e.getIdGasto());
        return e;
    }
}
