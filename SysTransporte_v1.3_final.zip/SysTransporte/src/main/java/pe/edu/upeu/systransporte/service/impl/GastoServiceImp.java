package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Gasto;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.GastoRepository;
import pe.edu.upeu.systransporte.service.IGastoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class GastoServiceImp extends CrudGenericoServiceImp<Gasto, String> implements IGastoService {

    private final GastoRepository repo;

    @Override
    protected ICrudGenericoRepository<Gasto, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Gasto x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdGasto()), x.getConcepto()));
        }
        return listar;
    }
}
