package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla "encomienda".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Encomienda {
    private Long idEncomienda;

    @NotNull(message = "Seleccione el cliente")
    private Cliente idCliente;

    @NotNull(message = "Seleccione el remitente")
    private Persona idRemitente;

    @NotNull(message = "Seleccione el destinatario")
    private Persona idDestinatario;

    @NotBlank(message = "El lugar de origen es obligatorio")
    private String lugarOrigen;

    @NotBlank(message = "El lugar de destino es obligatorio")
    private String lugarDestino;

    @NotBlank(message = "La descripción de la carga es obligatoria")
    private String descripcionCarga;

    @NotNull(message = "El peso es obligatorio")
    @Positive(message = "El peso debe ser mayor a 0")
    private Double pesoTon;

    @NotNull(message = "El estado es obligatorio")
    private EstadoEncomienda estado;

    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fechaRegistro;
}
