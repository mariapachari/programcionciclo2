package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.Viaje;
import pe.edu.upeu.systransporte.service.IViajeService;
import pe.edu.upeu.systransporte.service.IConductorService;
import pe.edu.upeu.systransporte.service.IVehiculoService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_viaje.fxml — Gestionar Viajes.
 */
@RequiredArgsConstructor
public class ViajeController {
    private final IViajeService viajeService;
    private final IConductorService conductorService;
    private final IVehiculoService vehiculoService;

    @FXML
    TextField txtOrigen, txtDestino, txtTipoCarga, txtCostoFlete, txtFiltroDato;
    @FXML
    DatePicker dpFechaSalida, dpFechaLlegada;
    @FXML
    ComboBox<ComboBoxOption> cbxIdConductor, cbxIdVehiculo, cbxEstado;

    @FXML
    private TableView<Viaje> tableView;
    private PaginadorTabla<Viaje> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Viaje> listaViaje = FXCollections.observableArrayList();
    Viaje formulario;
    String idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdConductor.getItems().addAll(conductorService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdConductor);
        cbxIdVehiculo.getItems().addAll(vehiculoService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdVehiculo);
        dpFechaSalida.setValue(LocalDate.now());
        cbxEstado.getItems().addAll(ComboHelper.desdeEnum(EstadoViaje.class));

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Viaje> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idViaje", 80.0));
        columns.put("Origen", new ColumnInfo("origen", 110.0));
        columns.put("Destino", new ColumnInfo("destino", 110.0));
        columns.put("Tipo de carga", new ColumnInfo("tipoCarga", 130.0));
        columns.put("Conductor", new ColumnInfo("idConductor.nombre", 160.0));
        columns.put("Vehículo", new ColumnInfo("idVehiculo.placa", 100.0));
        columns.put("Fecha salida", new ColumnInfo("fechaSalida", 105.0));
        columns.put("Fecha llegada", new ColumnInfo("fechaLlegada", 105.0));
        columns.put("Flete (S/)", new ColumnInfo("costoFlete", 90.0));
        columns.put("Estado", new ColumnInfo("estado", 100.0));

        Consumer<Viaje> updateAction = this::editForm;
        Consumer<Viaje> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaViaje = FXCollections.observableArrayList(viajeService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaViaje
                : listaViaje.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Viaje();
        formulario.setOrigen(txtOrigen.getText() == null ? null : txtOrigen.getText().trim());
        formulario.setDestino(txtDestino.getText() == null ? null : txtDestino.getText().trim());
        formulario.setTipoCarga(txtTipoCarga.getText() == null ? null : txtTipoCarga.getText().trim());
        String kIdConductor = ComboHelper.keySeleccionado(cbxIdConductor);
        formulario.setIdConductor(kIdConductor == null ? null : conductorService.findById(kIdConductor));
        String kIdVehiculo = ComboHelper.keySeleccionado(cbxIdVehiculo);
        formulario.setIdVehiculo(kIdVehiculo == null ? null : vehiculoService.findById(kIdVehiculo));
        formulario.setFechaSalida(dpFechaSalida.getValue());
        formulario.setFechaLlegada(dpFechaLlegada.getValue());
        formulario.setCostoFlete(parseDoubleSafe(txtCostoFlete.getText()));
        String kEstado = ComboHelper.keySeleccionado(cbxEstado);
        formulario.setEstado(kEstado == null ? null : EstadoViaje.valueOf(kEstado));

        Set<ConstraintViolation<Viaje>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Viaje>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        txtOrigen.clear();
        txtDestino.clear();
        txtTipoCarga.clear();
        cbxIdConductor.getSelectionModel().clearSelection();
        cbxIdVehiculo.getSelectionModel().clearSelection();
        dpFechaSalida.setValue(LocalDate.now());
        dpFechaLlegada.setValue(null);
        txtCostoFlete.clear();
        cbxEstado.getSelectionModel().clearSelection();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Viaje x) {
        txtOrigen.setText(x.getOrigen());
        txtDestino.setText(x.getDestino());
        txtTipoCarga.setText(x.getTipoCarga());
        ComboHelper.seleccionar(cbxIdConductor, x.getIdConductor() == null ? null : x.getIdConductor().getIdConductor());
        ComboHelper.seleccionar(cbxIdVehiculo, x.getIdVehiculo() == null ? null : x.getIdVehiculo().getIdVehiculo());
        dpFechaSalida.setValue(x.getFechaSalida());
        dpFechaLlegada.setValue(x.getFechaLlegada());
        txtCostoFlete.setText(x.getCostoFlete() == null ? "" : String.valueOf(x.getCostoFlete()));
        ComboHelper.seleccionar(cbxEstado, x.getEstado());
        idCE = x.getIdViaje();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Viaje x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdViaje() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            viajeService.delete(x.getIdViaje());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Viaje>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("origen", txtOrigen);
        campos.put("destino", txtDestino);
        campos.put("tipoCarga", txtTipoCarga);
        campos.put("idConductor", cbxIdConductor);
        campos.put("idVehiculo", cbxIdVehiculo);
        campos.put("fechaSalida", dpFechaSalida);
        campos.put("fechaLlegada", dpFechaLlegada);
        campos.put("costoFlete", txtCostoFlete);
        campos.put("estado", cbxEstado);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdViaje(idCE);
                viajeService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                viajeService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(txtOrigen, txtDestino, txtTipoCarga, cbxIdConductor, cbxIdVehiculo, dpFechaSalida, dpFechaLlegada, txtCostoFlete, cbxEstado)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
