package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Viaje;

import java.util.List;

public interface IViajeService extends ICrudGenericoService<Viaje, String> {
    List<ComboBoxOption> listarCombobox();
}
