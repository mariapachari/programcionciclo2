package pe.edu.upeu.systransporte;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import pe.edu.upeu.systransporte.config.AppContext;
import pe.edu.upeu.systransporte.config.DatabaseConfig;
import pe.edu.upeu.systransporte.service.IUsuarioService;

import java.io.IOException;

public class SysTransporte extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Abre la conexión a la BD (y crea las tablas) antes de mostrar el login
        DatabaseConfig.init();
        AppContext appContext = AppContext.getInstance();
        // Seguridad: encripta (PBKDF2) cualquier clave que aún esté en texto plano
        appContext.getBean(IUsuarioService.class).migrarClavesPlanas();
        FXMLLoader fxmlLoader = new FXMLLoader(SysTransporte.class.getResource("/view/login.fxml"));
        fxmlLoader.setControllerFactory(appContext::getBean);
        Scene scene = new Scene(fxmlLoader.load());
        scene.getStylesheets().add(SysTransporte.class.getResource("/css/style.css").toExternalForm());
        stage.getIcons().add(new Image(SysTransporte.class.getResource("/img/logo.png").toExternalForm()));
        stage.setTitle("SysTransporte - Iniciar sesión");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void stop() {
        DatabaseConfig.shutdown();
    }
}
