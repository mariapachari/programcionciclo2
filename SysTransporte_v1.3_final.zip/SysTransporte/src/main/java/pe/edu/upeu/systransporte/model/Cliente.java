package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidad que representa la tabla "clientes".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {
    private String idCliente;

    @NotBlank(message = "La razón social es obligatoria")
    @Size(max = 150, message = "Máximo 150 caracteres")
    private String razonSocial;

    @NotBlank(message = "El RUC es obligatorio")
    @Pattern(regexp = "\\d{11}", message = "El RUC debe tener 11 dígitos")
    private String ruc;

    @Pattern(regexp = "^$|\\d{6,20}", message = "Teléfono inválido (solo dígitos)")
    private String telefono;

    @Email(message = "Correo electrónico inválido")
    private String correo;
}
