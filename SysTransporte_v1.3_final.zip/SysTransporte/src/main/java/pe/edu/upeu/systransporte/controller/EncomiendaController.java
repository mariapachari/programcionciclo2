package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.Encomienda;
import pe.edu.upeu.systransporte.service.IEncomiendaService;
import pe.edu.upeu.systransporte.service.IClienteService;
import pe.edu.upeu.systransporte.service.IPersonaService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_encomienda.fxml — Gestionar Encomiendas.
 */
@RequiredArgsConstructor
public class EncomiendaController {
    private final IEncomiendaService encomiendaService;
    private final IClienteService clienteService;
    private final IPersonaService personaService;

    @FXML
    TextField txtLugarOrigen, txtLugarDestino, txtDescripcionCarga, txtPesoTon, txtFiltroDato;
    @FXML
    DatePicker dpFechaRegistro;
    @FXML
    ComboBox<ComboBoxOption> cbxIdCliente, cbxIdRemitente, cbxIdDestinatario, cbxEstado;

    @FXML
    private TableView<Encomienda> tableView;
    private PaginadorTabla<Encomienda> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Encomienda> listaEncomienda = FXCollections.observableArrayList();
    Encomienda formulario;
    Long idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdCliente.getItems().addAll(clienteService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdCliente);
        cbxIdRemitente.getItems().addAll(personaService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdRemitente);
        cbxIdDestinatario.getItems().addAll(personaService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdDestinatario);
        cbxEstado.getItems().addAll(ComboHelper.desdeEnum(EstadoEncomienda.class));
        dpFechaRegistro.setValue(LocalDate.now());

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Encomienda> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idEncomienda", 80.0));
        columns.put("Cliente", new ColumnInfo("idCliente.razonSocial", 180.0));
        columns.put("Remitente", new ColumnInfo("idRemitente.nombre", 160.0));
        columns.put("Destinatario", new ColumnInfo("idDestinatario.nombre", 160.0));
        columns.put("Origen", new ColumnInfo("lugarOrigen", 110.0));
        columns.put("Destino", new ColumnInfo("lugarDestino", 110.0));
        columns.put("Descripción", new ColumnInfo("descripcionCarga", 180.0));
        columns.put("Peso (t)", new ColumnInfo("pesoTon", 80.0));
        columns.put("Estado", new ColumnInfo("estado", 110.0));
        columns.put("Fecha registro", new ColumnInfo("fechaRegistro", 110.0));

        Consumer<Encomienda> updateAction = this::editForm;
        Consumer<Encomienda> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaEncomienda = FXCollections.observableArrayList(encomiendaService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaEncomienda
                : listaEncomienda.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Encomienda();
        String kIdCliente = ComboHelper.keySeleccionado(cbxIdCliente);
        formulario.setIdCliente(kIdCliente == null ? null : clienteService.findById(kIdCliente));
        String kIdRemitente = ComboHelper.keySeleccionado(cbxIdRemitente);
        formulario.setIdRemitente(kIdRemitente == null ? null : personaService.findById(Long.parseLong(kIdRemitente)));
        String kIdDestinatario = ComboHelper.keySeleccionado(cbxIdDestinatario);
        formulario.setIdDestinatario(kIdDestinatario == null ? null : personaService.findById(Long.parseLong(kIdDestinatario)));
        formulario.setLugarOrigen(txtLugarOrigen.getText() == null ? null : txtLugarOrigen.getText().trim());
        formulario.setLugarDestino(txtLugarDestino.getText() == null ? null : txtLugarDestino.getText().trim());
        formulario.setDescripcionCarga(txtDescripcionCarga.getText() == null ? null : txtDescripcionCarga.getText().trim());
        formulario.setPesoTon(parseDoubleSafe(txtPesoTon.getText()));
        String kEstado = ComboHelper.keySeleccionado(cbxEstado);
        formulario.setEstado(kEstado == null ? null : EstadoEncomienda.valueOf(kEstado));
        formulario.setFechaRegistro(dpFechaRegistro.getValue());

        Set<ConstraintViolation<Encomienda>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Encomienda>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxIdCliente.getSelectionModel().clearSelection();
        cbxIdRemitente.getSelectionModel().clearSelection();
        cbxIdDestinatario.getSelectionModel().clearSelection();
        txtLugarOrigen.clear();
        txtLugarDestino.clear();
        txtDescripcionCarga.clear();
        txtPesoTon.clear();
        cbxEstado.getSelectionModel().clearSelection();
        dpFechaRegistro.setValue(LocalDate.now());
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Encomienda x) {
        ComboHelper.seleccionar(cbxIdCliente, x.getIdCliente() == null ? null : x.getIdCliente().getIdCliente());
        ComboHelper.seleccionar(cbxIdRemitente, x.getIdRemitente() == null ? null : x.getIdRemitente().getIdPersona());
        ComboHelper.seleccionar(cbxIdDestinatario, x.getIdDestinatario() == null ? null : x.getIdDestinatario().getIdPersona());
        txtLugarOrigen.setText(x.getLugarOrigen());
        txtLugarDestino.setText(x.getLugarDestino());
        txtDescripcionCarga.setText(x.getDescripcionCarga());
        txtPesoTon.setText(x.getPesoTon() == null ? "" : String.valueOf(x.getPesoTon()));
        ComboHelper.seleccionar(cbxEstado, x.getEstado());
        dpFechaRegistro.setValue(x.getFechaRegistro());
        idCE = x.getIdEncomienda();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Encomienda x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdEncomienda() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            encomiendaService.delete(x.getIdEncomienda());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Encomienda>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("idCliente", cbxIdCliente);
        campos.put("idRemitente", cbxIdRemitente);
        campos.put("idDestinatario", cbxIdDestinatario);
        campos.put("lugarOrigen", txtLugarOrigen);
        campos.put("lugarDestino", txtLugarDestino);
        campos.put("descripcionCarga", txtDescripcionCarga);
        campos.put("pesoTon", txtPesoTon);
        campos.put("estado", cbxEstado);
        campos.put("fechaRegistro", dpFechaRegistro);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdEncomienda(idCE);
                encomiendaService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                encomiendaService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxIdCliente, cbxIdRemitente, cbxIdDestinatario, txtLugarOrigen, txtLugarDestino, txtDescripcionCarga, txtPesoTon, cbxEstado, dpFechaRegistro)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
