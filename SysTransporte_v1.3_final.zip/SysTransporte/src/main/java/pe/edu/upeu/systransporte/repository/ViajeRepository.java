package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class ViajeRepository extends AbstractJpaRepository<Viaje, String> {

    @Override
    protected String getTableName() { return "viajes"; }

    @Override
    protected String getPkColumn() { return "idViaje"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", co.nombre AS co_nombre" +
                    ", ve.placa AS ve_placa" +
                    ", ve.capacidadTon AS ve_capacidadTon" +
                    " FROM viajes t " +
                    "JOIN conductores co ON t.idConductor = co.idConductor " +
                    "JOIN vehiculos ve ON t.idVehiculo = ve.idVehiculo ";

    @Override
    public List<Viaje> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idViaje DESC");
    }

    @Override
    public Optional<Viaje> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idViaje = ?", id);
    }

    @Override
    protected Viaje mapRow(ResultSet rs) throws SQLException {
        return Viaje.builder()
                .idViaje(rs.getString("idViaje"))
                .origen(rs.getString("origen"))
                .destino(rs.getString("destino"))
                .tipoCarga(rs.getString("tipoCarga"))
                .idConductor(Conductor.builder()
                        .idConductor(rs.getString("idConductor"))
                        .nombre(rs.getString("co_nombre"))
                        .build())
                .idVehiculo(Vehiculo.builder()
                        .idVehiculo(rs.getString("idVehiculo"))
                        .placa(rs.getString("ve_placa"))
                        .capacidadTon(rs.getDouble("ve_capacidadTon"))
                        .build())
                .fechaSalida(rs.getObject("fechaSalida", LocalDate.class))
                .fechaLlegada(rs.getObject("fechaLlegada", LocalDate.class))
                .costoFlete(rs.getDouble("costoFlete"))
                .estado(toEnum(EstadoViaje.class, rs.getString("estado")))
                .build();
    }

    @Override
    protected Viaje insert(Connection conn, Viaje e) throws SQLException {
        if (e.getIdViaje() == null || e.getIdViaje().isBlank()) {
            e.setIdViaje(generarCodigo(conn, "VIA"));
        }
        executeUpdate(conn,
                "INSERT INTO viajes(idViaje, origen, destino, tipoCarga, idConductor, idVehiculo, fechaSalida, fechaLlegada, costoFlete, estado) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                e.getIdViaje(),
                e.getOrigen(),
                e.getDestino(),
                e.getTipoCarga(),
                e.getIdConductor() == null ? null : e.getIdConductor().getIdConductor(),
                e.getIdVehiculo() == null ? null : e.getIdVehiculo().getIdVehiculo(),
                e.getFechaSalida(),
                e.getFechaLlegada(),
                e.getCostoFlete(),
                enumName(e.getEstado()));
        return e;
    }

    @Override
    protected Viaje updateRow(Connection conn, Viaje e) throws SQLException {
        executeUpdate(conn,
                "UPDATE viajes SET origen = ?, destino = ?, tipoCarga = ?, idConductor = ?, idVehiculo = ?, fechaSalida = ?, fechaLlegada = ?, costoFlete = ?, estado = ? WHERE idViaje = ?",
                e.getOrigen(),
                e.getDestino(),
                e.getTipoCarga(),
                e.getIdConductor() == null ? null : e.getIdConductor().getIdConductor(),
                e.getIdVehiculo() == null ? null : e.getIdVehiculo().getIdVehiculo(),
                e.getFechaSalida(),
                e.getFechaLlegada(),
                e.getCostoFlete(),
                enumName(e.getEstado()),
                e.getIdViaje());
        return e;
    }
}
