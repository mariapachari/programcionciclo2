package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class UsuarioRepository extends AbstractJpaRepository<Usuario, String> {

    @Override
    protected String getTableName() { return "usuarios"; }

    @Override
    protected String getPkColumn() { return "idUsuario"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    " FROM usuarios t ";

    @Override
    public List<Usuario> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idUsuario ASC");
    }

    @Override
    public Optional<Usuario> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idUsuario = ?", id);
    }

    @Override
    protected Usuario mapRow(ResultSet rs) throws SQLException {
        return Usuario.builder()
                .idUsuario(rs.getString("idUsuario"))
                .usuario(rs.getString("usuario"))
                .clave(rs.getString("clave"))
                .rol(toEnum(Rol.class, rs.getString("rol")))
                .estado(toEnum(EstadoGeneral.class, rs.getString("estado")))
                .build();
    }

    @Override
    protected Usuario insert(Connection conn, Usuario e) throws SQLException {
        if (e.getIdUsuario() == null || e.getIdUsuario().isBlank()) {
            e.setIdUsuario(generarCodigo(conn, "USU"));
        }
        executeUpdate(conn,
                "INSERT INTO usuarios(idUsuario, usuario, clave, rol, estado) VALUES(?, ?, ?, ?, ?)",
                e.getIdUsuario(),
                e.getUsuario(),
                e.getClave(),
                enumName(e.getRol()),
                enumName(e.getEstado()));
        return e;
    }

    @Override
    protected Usuario updateRow(Connection conn, Usuario e) throws SQLException {
        executeUpdate(conn,
                "UPDATE usuarios SET usuario = ?, clave = ?, rol = ?, estado = ? WHERE idUsuario = ?",
                e.getUsuario(),
                e.getClave(),
                enumName(e.getRol()),
                enumName(e.getEstado()),
                e.getIdUsuario());
        return e;
    }

    /** Login: busca el usuario por nombre (la clave se verifica con el hash en el Service). */
    public Optional<Usuario> findByUsuario(String usuario) {
        return executeQueryOne(SELECT_JOIN + "WHERE LOWER(t.usuario) = LOWER(?)", usuario);
    }
}
