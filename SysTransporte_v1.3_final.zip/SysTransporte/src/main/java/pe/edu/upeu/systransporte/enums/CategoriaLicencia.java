package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum CategoriaLicencia {
    A_IIB("A-IIb"),
    A_IIIA("A-IIIa"),
    A_IIIB("A-IIIb"),
    A_IIIC("A-IIIc");

    private final String descripcion;

    CategoriaLicencia(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
