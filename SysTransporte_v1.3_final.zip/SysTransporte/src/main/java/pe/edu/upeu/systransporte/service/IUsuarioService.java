package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Usuario;

import java.util.List;
import java.util.Optional;

public interface IUsuarioService extends ICrudGenericoService<Usuario, String> {
    List<ComboBoxOption> listarCombobox();
    Optional<Usuario> loginUsuario(String usuario, String clave);
    int migrarClavesPlanas();
}
