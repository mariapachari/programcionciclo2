package pe.edu.upeu.systransporte.service.impl;

import pe.edu.upeu.systransporte.dto.MenuMenuItenTO;
import pe.edu.upeu.systransporte.service.IMenuMenuItemDao;

import java.util.*;

/**
 * Define los menús del sistema y qué rol puede ver cada opción.
 * Tipo de tab: "T" = se abre en una pestaña, "C" = cambia de escena (cerrar sesión).
 */
public class MenuMenuItemDaoImp implements IMenuMenuItemDao {

    // Opciones que puede ver el rol OPERADOR (el ADMINISTRADOR ve todo)
    private static final Set<String> OPERADOR = Set.of(
            "inicio", "salir", "cliente", "persona",
            "encomienda", "paquete", "movimiento", "entrega", "comprobante");

    // Opciones que puede ver el rol CONDUCTOR (registra seguimiento, entregas y gastos de su viaje)
    private static final Set<String> CONDUCTOR = Set.of(
            "inicio", "salir", "movimiento", "entrega", "gasto");

    @Override
    public List<MenuMenuItenTO> listaAccesos(String perfil, Properties idioma) {
        String mPrincipal   = idioma.getProperty("menu.principal", "Principal");
        String mRegistros   = idioma.getProperty("menu.registros", "Registros");
        String mOperaciones = idioma.getProperty("menu.operaciones", "Encomiendas");
        String mTransporte  = idioma.getProperty("menu.transporte", "Transporte");
        String mFacturacion = idioma.getProperty("menu.facturacion", "Facturación");
        String mSeguridad   = idioma.getProperty("menu.seguridad", "Seguridad");

        List<MenuMenuItenTO> lista = new ArrayList<>();
        lista.add(item("inicio", "/view/main_inicio.fxml", mPrincipal, idioma.getProperty("menuitem.inicio", "Inicio"), "Inicio", "T"));
        lista.add(item("salir", "/view/login.fxml", mPrincipal, idioma.getProperty("menuitem.salir", "Cerrar sesión"), "Salir", "C"));

        lista.add(item("cliente", "/view/main_cliente.fxml", mRegistros, idioma.getProperty("menuitem.cliente", "Clientes"), "Clientes", "T"));
        lista.add(item("persona", "/view/main_persona.fxml", mRegistros, idioma.getProperty("menuitem.persona", "Personas"), "Personas", "T"));
        lista.add(item("conductor", "/view/main_conductor.fxml", mRegistros, idioma.getProperty("menuitem.conductor", "Conductores"), "Conductores", "T"));
        lista.add(item("vehiculo", "/view/main_vehiculo.fxml", mRegistros, idioma.getProperty("menuitem.vehiculo", "Vehículos"), "Vehículos", "T"));

        lista.add(item("encomienda", "/view/main_encomienda.fxml", mOperaciones, idioma.getProperty("menuitem.encomienda", "Registrar encomienda"), "Encomiendas", "T"));
        lista.add(item("paquete", "/view/main_paquete.fxml", mOperaciones, idioma.getProperty("menuitem.paquete", "Paquetes"), "Paquetes", "T"));
        lista.add(item("movimiento", "/view/main_movimiento.fxml", mOperaciones, idioma.getProperty("menuitem.movimiento", "Seguimiento"), "Seguimiento", "T"));
        lista.add(item("entrega", "/view/main_entrega.fxml", mOperaciones, idioma.getProperty("menuitem.entrega", "Entregas"), "Entregas", "T"));

        lista.add(item("viaje", "/view/main_viaje.fxml", mTransporte, idioma.getProperty("menuitem.viaje", "Viajes"), "Viajes", "T"));
        lista.add(item("manifiesto", "/view/main_manifiesto.fxml", mTransporte, idioma.getProperty("menuitem.manifiesto", "Manifiestos"), "Manifiestos", "T"));
        lista.add(item("detalle", "/view/main_detalle_manifiesto.fxml", mTransporte, idioma.getProperty("menuitem.detalle", "Detalle de manifiesto"), "Detalle Manifiesto", "T"));
        lista.add(item("gasto", "/view/main_gasto.fxml", mTransporte, idioma.getProperty("menuitem.gasto", "Gastos de viaje"), "Gastos", "T"));

        lista.add(item("comprobante", "/view/main_comprobante.fxml", mFacturacion, idioma.getProperty("menuitem.comprobante", "Comprobantes"), "Comprobantes", "T"));

        lista.add(item("usuario", "/view/main_usuario.fxml", mSeguridad, idioma.getProperty("menuitem.usuario", "Usuarios"), "Usuarios", "T"));

        String rol = perfil == null ? "" : perfil;
        return switch (rol) {
            case "ADMINISTRADOR" -> lista;
            case "OPERADOR" -> lista.stream().filter(m -> OPERADOR.contains(m.getIdNombreObj())).toList();
            case "CONDUCTOR" -> lista.stream().filter(m -> CONDUCTOR.contains(m.getIdNombreObj())).toList();
            default -> lista.subList(0, 2);   // solo Inicio y Salir
        };
    }

    private MenuMenuItenTO item(String id, String ruta, String menu, String menuItem, String tab, String tipo) {
        // el nombre del ícono coincide con el id (ver /img/modulos)
        return new MenuMenuItenTO(id, ruta, menu, menuItem, tab, tipo, id);
    }

    @Override
    public Map<String, String[]> accesosAutorizados(List<MenuMenuItenTO> accesos) {
        Map<String, String[]> menuConfig = new HashMap<>();
        for (MenuMenuItenTO menu : accesos) {
            menuConfig.put("mi" + menu.getIdNombreObj(),
                    new String[]{menu.getRutaFile(), menu.getNombreTab(), menu.getTipoTab(), menu.getIcono()});
        }
        return menuConfig;
    }

    @Override
    public int[] contarMenuMunuItem(List<MenuMenuItenTO> data) {
        int menui = 0, menuitem = 0;
        String menuN = "";
        for (MenuMenuItenTO mmiItem : data) {
            if (!mmiItem.getMenunombre().equals(menuN)) {
                menuN = mmiItem.getMenunombre();
                menui++;
            }
            if (!mmiItem.getMenuitemnombre().equals("")) {
                menuitem++;
            }
        }
        return new int[]{menui, menuitem};
    }
}
