package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class DetalleManifiestoRepository extends AbstractJpaRepository<DetalleManifiesto, Long> {

    @Override
    protected String getTableName() { return "detalle_manifiesto"; }

    @Override
    protected String getPkColumn() { return "id_detalle_manifiesto"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", ma.numeroGuia AS ma_numeroGuia" +
                    ", en.descripcionCarga AS en_descripcionCarga" +
                    ", en.pesoTon AS en_pesoTon" +
                    " FROM detalle_manifiesto t " +
                    "JOIN manifiesto ma ON t.idGuia = ma.idGuia " +
                    "JOIN encomienda en ON t.id_encomienda = en.id_encomienda ";

    @Override
    public List<DetalleManifiesto> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.id_detalle_manifiesto DESC");
    }

    @Override
    public Optional<DetalleManifiesto> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_detalle_manifiesto = ?", id);
    }

    @Override
    protected DetalleManifiesto mapRow(ResultSet rs) throws SQLException {
        return DetalleManifiesto.builder()
                .idDetalleManifiesto(rs.getLong("id_detalle_manifiesto"))
                .idGuia(Manifiesto.builder()
                        .idGuia(rs.getString("idGuia"))
                        .numeroGuia(rs.getString("ma_numeroGuia"))
                        .build())
                .idEncomienda(Encomienda.builder()
                        .idEncomienda(rs.getLong("id_encomienda"))
                        .descripcionCarga(rs.getString("en_descripcionCarga"))
                        .pesoTon(rs.getDouble("en_pesoTon"))
                        .build())
                .pesoAsignadoTon(rs.getDouble("pesoAsignadoTon"))
                .build();
    }

    @Override
    protected DetalleManifiesto insert(Connection conn, DetalleManifiesto e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO detalle_manifiesto(idGuia, id_encomienda, pesoAsignadoTon) VALUES(?, ?, ?)",
                e.getIdGuia() == null ? null : e.getIdGuia().getIdGuia(),
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getPesoAsignadoTon());
        e.setIdDetalleManifiesto(id);
        return e;
    }

    @Override
    protected DetalleManifiesto updateRow(Connection conn, DetalleManifiesto e) throws SQLException {
        executeUpdate(conn,
                "UPDATE detalle_manifiesto SET idGuia = ?, id_encomienda = ?, pesoAsignadoTon = ? WHERE id_detalle_manifiesto = ?",
                e.getIdGuia() == null ? null : e.getIdGuia().getIdGuia(),
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getPesoAsignadoTon(),
                e.getIdDetalleManifiesto());
        return e;
    }

    /** Suma de toneladas ya asignadas a una guía (sin contar el detalle que se edita). */
    public double pesoAsignadoEnGuia(String idGuia, Long excluirId) {
        return executeScalarDouble(
                "SELECT COALESCE(SUM(pesoAsignadoTon), 0) FROM detalle_manifiesto " +
                        "WHERE idGuia = ? AND id_detalle_manifiesto <> ?",
                idGuia, excluirId == null ? -1L : excluirId);
    }

    /** Capacidad (t) del vehículo asignado al viaje de la guía. */
    public double capacidadVehiculoDeGuia(String idGuia) {
        return executeScalarDouble(
                "SELECT v.capacidadTon FROM manifiesto m " +
                        "JOIN viajes vi ON m.idViaje = vi.idViaje " +
                        "JOIN vehiculos v ON vi.idVehiculo = v.idVehiculo " +
                        "WHERE m.idGuia = ?",
                idGuia);
    }
}
