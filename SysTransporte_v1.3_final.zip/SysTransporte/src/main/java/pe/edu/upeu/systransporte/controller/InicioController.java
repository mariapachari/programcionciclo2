package pe.edu.upeu.systransporte.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.SessionManager;
import pe.edu.upeu.systransporte.enums.EstadoEncomienda;
import pe.edu.upeu.systransporte.enums.EstadoVehiculo;
import pe.edu.upeu.systransporte.enums.EstadoViaje;
import pe.edu.upeu.systransporte.service.IClienteService;
import pe.edu.upeu.systransporte.service.IEncomiendaService;
import pe.edu.upeu.systransporte.service.IVehiculoService;
import pe.edu.upeu.systransporte.service.IViajeService;

/**
 * Controlador de main_inicio.fxml.
 * MEJORA: muestra un resumen con datos REALES leídos de la base de datos.
 * Recibe los servicios por constructor (igual que los demás controladores).
 */
@RequiredArgsConstructor
public class InicioController {

    private final IClienteService clienteService;
    private final IEncomiendaService encomiendaService;
    private final IViajeService viajeService;
    private final IVehiculoService vehiculoService;

    @FXML
    Label lblBienvenida, lblClientes, lblEncomiendas, lblPendientes, lblViajes, lblVehiculos;

    @FXML
    public void initialize() {
        lblBienvenida.setText("Bienvenido, " + SessionManager.getInstance().getUserName()
                + " (" + SessionManager.getInstance().getUserPerfil() + ")");
        cargarResumen();
    }

    /** Cuenta registros usando los servicios (que a su vez consultan la BD). */
    @FXML
    public void cargarResumen() {
        try {
            lblClientes.setText(String.valueOf(clienteService.findAll().size()));
            lblEncomiendas.setText(String.valueOf(encomiendaService.findAll().size()));
            lblPendientes.setText(String.valueOf(encomiendaService.findAll().stream()
                    .filter(e -> e.getEstado() != EstadoEncomienda.ENTREGADO
                            && e.getEstado() != EstadoEncomienda.ANULADO)
                    .count()));
            lblViajes.setText(String.valueOf(viajeService.findAll().stream()
                    .filter(v -> v.getEstado() == EstadoViaje.EN_CURSO)
                    .count()));
            lblVehiculos.setText(String.valueOf(vehiculoService.findAll().stream()
                    .filter(v -> v.getEstado() == EstadoVehiculo.DISPONIBLE)
                    .count()));
        } catch (RuntimeException ex) {
            lblBienvenida.setText("No se pudo leer la base de datos: " + ex.getMessage());
        }
    }
}
