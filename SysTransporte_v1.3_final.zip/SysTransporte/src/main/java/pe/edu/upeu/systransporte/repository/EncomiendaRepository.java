package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class EncomiendaRepository extends AbstractJpaRepository<Encomienda, Long> {

    @Override
    protected String getTableName() { return "encomienda"; }

    @Override
    protected String getPkColumn() { return "id_encomienda"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", c.razonSocial AS c_razonSocial" +
                    ", pr.nombre AS pr_nombre" +
                    ", pr.dni AS pr_dni" +
                    ", pd.nombre AS pd_nombre" +
                    ", pd.dni AS pd_dni" +
                    " FROM encomienda t " +
                    "JOIN clientes c ON t.idCliente = c.idCliente " +
                    "JOIN persona pr ON t.id_remitente = pr.id_persona " +
                    "JOIN persona pd ON t.id_destinatario = pd.id_persona ";

    @Override
    public List<Encomienda> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.id_encomienda DESC");
    }

    @Override
    public Optional<Encomienda> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_encomienda = ?", id);
    }

    @Override
    protected Encomienda mapRow(ResultSet rs) throws SQLException {
        return Encomienda.builder()
                .idEncomienda(rs.getLong("id_encomienda"))
                .idCliente(Cliente.builder()
                        .idCliente(rs.getString("idCliente"))
                        .razonSocial(rs.getString("c_razonSocial"))
                        .build())
                .idRemitente(Persona.builder()
                        .idPersona(rs.getLong("id_remitente"))
                        .nombre(rs.getString("pr_nombre"))
                        .dni(rs.getString("pr_dni"))
                        .build())
                .idDestinatario(Persona.builder()
                        .idPersona(rs.getLong("id_destinatario"))
                        .nombre(rs.getString("pd_nombre"))
                        .dni(rs.getString("pd_dni"))
                        .build())
                .lugarOrigen(rs.getString("lugar_origen"))
                .lugarDestino(rs.getString("lugar_destino"))
                .descripcionCarga(rs.getString("descripcionCarga"))
                .pesoTon(rs.getDouble("pesoTon"))
                .estado(toEnum(EstadoEncomienda.class, rs.getString("estado")))
                .fechaRegistro(rs.getObject("fechaRegistro", LocalDate.class))
                .build();
    }

    @Override
    protected Encomienda insert(Connection conn, Encomienda e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO encomienda(idCliente, id_remitente, id_destinatario, lugar_origen, lugar_destino, descripcionCarga, pesoTon, estado, fechaRegistro) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)",
                e.getIdCliente() == null ? null : e.getIdCliente().getIdCliente(),
                e.getIdRemitente() == null ? null : e.getIdRemitente().getIdPersona(),
                e.getIdDestinatario() == null ? null : e.getIdDestinatario().getIdPersona(),
                e.getLugarOrigen(),
                e.getLugarDestino(),
                e.getDescripcionCarga(),
                e.getPesoTon(),
                enumName(e.getEstado()),
                e.getFechaRegistro());
        e.setIdEncomienda(id);
        return e;
    }

    @Override
    protected Encomienda updateRow(Connection conn, Encomienda e) throws SQLException {
        executeUpdate(conn,
                "UPDATE encomienda SET idCliente = ?, id_remitente = ?, id_destinatario = ?, lugar_origen = ?, lugar_destino = ?, descripcionCarga = ?, pesoTon = ?, estado = ?, fechaRegistro = ? WHERE id_encomienda = ?",
                e.getIdCliente() == null ? null : e.getIdCliente().getIdCliente(),
                e.getIdRemitente() == null ? null : e.getIdRemitente().getIdPersona(),
                e.getIdDestinatario() == null ? null : e.getIdDestinatario().getIdPersona(),
                e.getLugarOrigen(),
                e.getLugarDestino(),
                e.getDescripcionCarga(),
                e.getPesoTon(),
                enumName(e.getEstado()),
                e.getFechaRegistro(),
                e.getIdEncomienda());
        return e;
    }

    /** Cambia solo el estado de la encomienda (lo usan Movimiento y Entrega). */
    public void actualizarEstado(Long idEncomienda, String estado) {
        executeUpdateStandalone("UPDATE encomienda SET estado = ? WHERE id_encomienda = ?", estado, idEncomienda);
    }
}
