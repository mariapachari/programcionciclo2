package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Conductor;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.ConductorRepository;
import pe.edu.upeu.systransporte.service.IConductorService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class ConductorServiceImp extends CrudGenericoServiceImp<Conductor, String> implements IConductorService {

    private final ConductorRepository repo;

    @Override
    protected ICrudGenericoRepository<Conductor, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Conductor x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdConductor()), x.getNombre() + " (" + x.getCategoriaLicencia() + ")"));
        }
        return listar;
    }
}
