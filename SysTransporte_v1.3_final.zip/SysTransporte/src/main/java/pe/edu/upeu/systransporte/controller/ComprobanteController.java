package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.Cliente;
import pe.edu.upeu.systransporte.model.Comprobante;
import pe.edu.upeu.systransporte.model.Encomienda;
import pe.edu.upeu.systransporte.model.Paquete;
import pe.edu.upeu.systransporte.service.IClienteService;
import pe.edu.upeu.systransporte.service.IComprobanteService;
import pe.edu.upeu.systransporte.service.IEncomiendaService;
import pe.edu.upeu.systransporte.service.IPaqueteService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_comprobante.fxml — Comprobantes de Pago.
 */
@RequiredArgsConstructor
public class ComprobanteController {
    private final IComprobanteService comprobanteService;
    private final IEncomiendaService encomiendaService;
    private final IClienteService clienteService;   // para imprimir: RUC del cliente
    private final IPaqueteService paqueteService;   // para imprimir: contenido de la encomienda

    @FXML
    TextField txtMonto, txtFiltroDato;
    @FXML
    DatePicker dpFecha;
    @FXML
    ComboBox<ComboBoxOption> cbxTipo, cbxIdEncomienda, cbxEstadoPago;

    @FXML
    private TableView<Comprobante> tableView;
    private PaginadorTabla<Comprobante> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Comprobante> listaComprobante = FXCollections.observableArrayList();
    Comprobante formulario;
    String idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxTipo.getItems().addAll(ComboHelper.desdeEnum(TipoComprobante.class));
        cbxIdEncomienda.getItems().addAll(encomiendaService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdEncomienda);
        dpFecha.setValue(LocalDate.now());
        cbxEstadoPago.getItems().addAll(ComboHelper.desdeEnum(EstadoPago.class));

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Comprobante> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idComprobante", 80.0));
        columns.put("Tipo", new ColumnInfo("tipo", 80.0));
        columns.put("Número", new ColumnInfo("numero", 120.0));
        columns.put("Encomienda", new ColumnInfo("idEncomienda.descripcionCarga", 200.0));
        columns.put("Fecha", new ColumnInfo("fecha", 100.0));
        columns.put("Monto (S/)", new ColumnInfo("monto", 90.0));
        columns.put("Estado pago", new ColumnInfo("estadoPago", 100.0));

        Consumer<Comprobante> updateAction = this::editForm;
        Consumer<Comprobante> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaComprobante = FXCollections.observableArrayList(comprobanteService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaComprobante
                : listaComprobante.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Comprobante();
        String kTipo = ComboHelper.keySeleccionado(cbxTipo);
        formulario.setTipo(kTipo == null ? null : TipoComprobante.valueOf(kTipo));
        String kIdEncomienda = ComboHelper.keySeleccionado(cbxIdEncomienda);
        formulario.setIdEncomienda(kIdEncomienda == null ? null : encomiendaService.findById(Long.parseLong(kIdEncomienda)));
        formulario.setFecha(dpFecha.getValue());
        formulario.setMonto(parseDoubleSafe(txtMonto.getText()));
        String kEstadoPago = ComboHelper.keySeleccionado(cbxEstadoPago);
        formulario.setEstadoPago(kEstadoPago == null ? null : EstadoPago.valueOf(kEstadoPago));

        Set<ConstraintViolation<Comprobante>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Comprobante>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxTipo.getSelectionModel().clearSelection();
        cbxIdEncomienda.getSelectionModel().clearSelection();
        dpFecha.setValue(LocalDate.now());
        txtMonto.clear();
        cbxEstadoPago.getSelectionModel().clearSelection();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Comprobante x) {
        ComboHelper.seleccionar(cbxTipo, x.getTipo());
        ComboHelper.seleccionar(cbxIdEncomienda, x.getIdEncomienda() == null ? null : x.getIdEncomienda().getIdEncomienda());
        dpFecha.setValue(x.getFecha());
        txtMonto.setText(x.getMonto() == null ? "" : String.valueOf(x.getMonto()));
        ComboHelper.seleccionar(cbxEstadoPago, x.getEstadoPago());
        idCE = x.getIdComprobante();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Comprobante x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdComprobante() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            comprobanteService.delete(x.getIdComprobante());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Comprobante>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("tipo", cbxTipo);
        campos.put("idEncomienda", cbxIdEncomienda);
        campos.put("fecha", dpFecha);
        campos.put("monto", txtMonto);
        campos.put("estadoPago", cbxEstadoPago);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdComprobante(idCE);
                comprobanteService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                comprobanteService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    /** Imprime el comprobante seleccionado en la tabla (boleta o factura). */
    @FXML
    public void imprimir() {
        stage = (Stage) miContenedor.getScene().getWindow();
        Comprobante c = tableView.getSelectionModel().getSelectedItem();
        if (c == null) {
            lbnMsg.setText("Seleccione en la tabla el comprobante que desea imprimir");
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            return;
        }
        try {
            // La tabla solo trae datos resumidos: se cargan los datos completos para el documento
            Encomienda enc = encomiendaService.findById(c.getIdEncomienda().getIdEncomienda());
            Cliente cli = enc.getIdCliente() == null ? null
                    : clienteService.findById(enc.getIdCliente().getIdCliente());
            List<Paquete> paquetes = paqueteService.findAll().stream()
                    .filter(p -> p.getIdEncomienda() != null
                            && Objects.equals(p.getIdEncomienda().getIdEncomienda(), enc.getIdEncomienda()))
                    .toList();

            ImpresionHelper.vistaPrevia(stage, c.getTipo() + " " + c.getNumero(),
                    ImpresionHelper.documentoComprobante(c, enc, cli, paquetes));
            lbnMsg.setText("");
        } catch (RuntimeException ex) {
            lbnMsg.setText("No se pudo preparar la impresión: " + ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxTipo, cbxIdEncomienda, dpFecha, txtMonto, cbxEstadoPago)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
