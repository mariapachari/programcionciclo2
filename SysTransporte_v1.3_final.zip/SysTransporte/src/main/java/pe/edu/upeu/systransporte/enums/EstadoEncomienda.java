package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum EstadoEncomienda {
    REGISTRADO("Registrado"),
    EN_ALMACEN("En almacén"),
    EN_TRANSITO("En tránsito"),
    EN_DESTINO("En destino"),
    ENTREGADO("Entregado"),
    ANULADO("Anulado");

    private final String descripcion;

    EstadoEncomienda(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
