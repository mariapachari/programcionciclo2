package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class EntregaRepository extends AbstractJpaRepository<Entrega, Long> {

    @Override
    protected String getTableName() { return "entrega"; }

    @Override
    protected String getPkColumn() { return "id_entrega"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", en.descripcionCarga AS en_descripcionCarga" +
                    " FROM entrega t " +
                    "JOIN encomienda en ON t.id_encomienda = en.id_encomienda ";

    @Override
    public List<Entrega> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.id_entrega DESC");
    }

    @Override
    public Optional<Entrega> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_entrega = ?", id);
    }

    @Override
    protected Entrega mapRow(ResultSet rs) throws SQLException {
        return Entrega.builder()
                .idEntrega(rs.getLong("id_entrega"))
                .idEncomienda(Encomienda.builder()
                        .idEncomienda(rs.getLong("id_encomienda"))
                        .descripcionCarga(rs.getString("en_descripcionCarga"))
                        .build())
                .fechaEntrega(rs.getObject("fechaEntrega", LocalDate.class))
                .receptor(rs.getString("receptor"))
                .estado(toEnum(EstadoEntrega.class, rs.getString("estado")))
                .observacion(rs.getString("observacion"))
                .build();
    }

    @Override
    protected Entrega insert(Connection conn, Entrega e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO entrega(id_encomienda, fechaEntrega, receptor, estado, observacion) VALUES(?, ?, ?, ?, ?)",
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getFechaEntrega(),
                e.getReceptor(),
                enumName(e.getEstado()),
                e.getObservacion());
        e.setIdEntrega(id);
        return e;
    }

    @Override
    protected Entrega updateRow(Connection conn, Entrega e) throws SQLException {
        executeUpdate(conn,
                "UPDATE entrega SET id_encomienda = ?, fechaEntrega = ?, receptor = ?, estado = ?, observacion = ? WHERE id_entrega = ?",
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getFechaEntrega(),
                e.getReceptor(),
                enumName(e.getEstado()),
                e.getObservacion(),
                e.getIdEntrega());
        return e;
    }
}
