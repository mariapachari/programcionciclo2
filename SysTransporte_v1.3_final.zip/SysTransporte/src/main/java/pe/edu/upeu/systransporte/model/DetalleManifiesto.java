package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidad que representa la tabla "detalle_manifiesto".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DetalleManifiesto {
    private Long idDetalleManifiesto;

    @NotNull(message = "Seleccione la guía")
    private Manifiesto idGuia;

    @NotNull(message = "Seleccione la encomienda")
    private Encomienda idEncomienda;

    @NotNull(message = "El peso asignado es obligatorio")
    @Positive(message = "El peso debe ser mayor a 0")
    private Double pesoAsignadoTon;
}
