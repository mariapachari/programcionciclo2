package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Entrega;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.EntregaRepository;
import pe.edu.upeu.systransporte.repository.EncomiendaRepository;
import pe.edu.upeu.systransporte.service.IEntregaService;
import pe.edu.upeu.systransporte.enums.EstadoEncomienda;
import pe.edu.upeu.systransporte.enums.EstadoEntrega;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class EntregaServiceImp extends CrudGenericoServiceImp<Entrega, Long> implements IEntregaService {

    private final EntregaRepository repo;
    private final EncomiendaRepository encomiendaRepository;

    @Override
    protected ICrudGenericoRepository<Entrega, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Entrega x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdEntrega()), x.getReceptor()));
        }
        return listar;
    }

    /** Si la entrega se confirma, la encomienda pasa a ENTREGADO. */
    private void actualizarEncomienda(Entrega e) {
        if (e.getEstado() == EstadoEntrega.ENTREGADO) {
            encomiendaRepository.actualizarEstado(e.getIdEncomienda().getIdEncomienda(), EstadoEncomienda.ENTREGADO.name());
        }
    }

    @Override
    public Entrega save(Entrega e) {
        Entrega guardada = super.save(e);
        actualizarEncomienda(e);
        return guardada;
    }

    @Override
    public Entrega update(Long id, Entrega e) {
        Entrega actualizada = super.update(id, e);
        actualizarEncomienda(e);
        return actualizada;
    }
}
