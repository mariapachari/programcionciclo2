package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

/**
 * Entidad que representa la tabla "conductores".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Conductor {
    private String idConductor;

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @NotBlank(message = "La licencia es obligatoria")
    private String licencia;

    @Pattern(regexp = "^$|\\d{6,20}", message = "Teléfono inválido (solo dígitos)")
    private String telefono;

    @NotNull(message = "La categoría de licencia es obligatoria")
    private CategoriaLicencia categoriaLicencia;

    @NotNull(message = "El estado es obligatorio")
    private EstadoGeneral estado;
}
