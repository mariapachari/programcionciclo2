package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Persona;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.PersonaRepository;
import pe.edu.upeu.systransporte.service.IPersonaService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class PersonaServiceImp extends CrudGenericoServiceImp<Persona, Long> implements IPersonaService {

    private final PersonaRepository repo;

    @Override
    protected ICrudGenericoRepository<Persona, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Persona x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdPersona()), x.getNombre() + " - DNI " + x.getDni()));
        }
        return listar;
    }

    // ===== MEJORA: evitar registros duplicados =====
    private void validarDuplicado(Persona x) {
        if (repo.existeDuplicado("dni", x.getDni(), x.getIdPersona())) {
            throw new IllegalArgumentException("Ya existe una persona con el DNI " + x.getDni());
        }
    }

    @Override
    public Persona save(Persona x) {
        validarDuplicado(x);
        return super.save(x);
    }

    @Override
    public Persona update(Long id, Persona x) {
        validarDuplicado(x);
        return super.update(id, x);
    }
}
