package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class PersonaRepository extends AbstractJpaRepository<Persona, Long> {

    @Override
    protected String getTableName() { return "persona"; }

    @Override
    protected String getPkColumn() { return "id_persona"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    " FROM persona t ";

    @Override
    public List<Persona> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.id_persona ASC");
    }

    @Override
    public Optional<Persona> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_persona = ?", id);
    }

    @Override
    protected Persona mapRow(ResultSet rs) throws SQLException {
        return Persona.builder()
                .idPersona(rs.getLong("id_persona"))
                .nombre(rs.getString("nombre"))
                .dni(rs.getString("dni"))
                .celular(rs.getString("celular"))
                .direccion(rs.getString("direccion"))
                .build();
    }

    @Override
    protected Persona insert(Connection conn, Persona e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO persona(nombre, dni, celular, direccion) VALUES(?, ?, ?, ?)",
                e.getNombre(),
                e.getDni(),
                e.getCelular(),
                e.getDireccion());
        e.setIdPersona(id);
        return e;
    }

    @Override
    protected Persona updateRow(Connection conn, Persona e) throws SQLException {
        executeUpdate(conn,
                "UPDATE persona SET nombre = ?, dni = ?, celular = ?, direccion = ? WHERE id_persona = ?",
                e.getNombre(),
                e.getDni(),
                e.getCelular(),
                e.getDireccion(),
                e.getIdPersona());
        return e;
    }
}
