package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum EstadoGeneral {
    ACTIVO("Activo"),
    INACTIVO("Inactivo");

    private final String descripcion;

    EstadoGeneral(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
