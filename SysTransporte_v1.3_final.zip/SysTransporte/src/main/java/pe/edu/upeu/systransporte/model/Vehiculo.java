package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

/**
 * Entidad que representa la tabla "vehiculos".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Vehiculo {
    private String idVehiculo;

    @NotBlank(message = "La placa es obligatoria")
    @Pattern(regexp = "[A-Z0-9]{3}-?[A-Z0-9]{3}", message = "Placa inválida (ej. ABC-123)")
    private String placa;

    @NotBlank(message = "La marca es obligatoria")
    private String marca;

    @NotNull(message = "El tipo de vehículo es obligatorio")
    private TipoVehiculo tipoVehiculo;

    @NotNull(message = "La capacidad es obligatoria")
    @Positive(message = "La capacidad debe ser mayor a 0")
    private Double capacidadTon;

    @NotNull(message = "El estado es obligatorio")
    private EstadoVehiculo estado;
}
