package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.DetalleManifiesto;
import pe.edu.upeu.systransporte.service.IDetalleManifiestoService;
import pe.edu.upeu.systransporte.service.IManifiestoService;
import pe.edu.upeu.systransporte.service.IEncomiendaService;

import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_detalle_manifiesto.fxml — Detalle de Manifiesto.
 */
@RequiredArgsConstructor
public class DetalleManifiestoController {
    private final IDetalleManifiestoService detalleManifiestoService;
    private final IManifiestoService manifiestoService;
    private final IEncomiendaService encomiendaService;

    @FXML
    TextField txtPesoAsignadoTon, txtFiltroDato;
    @FXML
    ComboBox<ComboBoxOption> cbxIdGuia, cbxIdEncomienda;

    @FXML
    private TableView<DetalleManifiesto> tableView;
    private PaginadorTabla<DetalleManifiesto> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<DetalleManifiesto> listaDetalleManifiesto = FXCollections.observableArrayList();
    DetalleManifiesto formulario;
    Long idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdGuia.getItems().addAll(manifiestoService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdGuia);
        cbxIdEncomienda.getItems().addAll(encomiendaService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdEncomienda);

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<DetalleManifiesto> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idDetalleManifiesto", 80.0));
        columns.put("Guía", new ColumnInfo("idGuia.numeroGuia", 130.0));
        columns.put("Encomienda", new ColumnInfo("idEncomienda.descripcionCarga", 200.0));
        columns.put("Peso asignado (t)", new ColumnInfo("pesoAsignadoTon", 120.0));

        Consumer<DetalleManifiesto> updateAction = this::editForm;
        Consumer<DetalleManifiesto> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaDetalleManifiesto = FXCollections.observableArrayList(detalleManifiestoService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaDetalleManifiesto
                : listaDetalleManifiesto.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new DetalleManifiesto();
        String kIdGuia = ComboHelper.keySeleccionado(cbxIdGuia);
        formulario.setIdGuia(kIdGuia == null ? null : manifiestoService.findById(kIdGuia));
        String kIdEncomienda = ComboHelper.keySeleccionado(cbxIdEncomienda);
        formulario.setIdEncomienda(kIdEncomienda == null ? null : encomiendaService.findById(Long.parseLong(kIdEncomienda)));
        formulario.setPesoAsignadoTon(parseDoubleSafe(txtPesoAsignadoTon.getText()));

        Set<ConstraintViolation<DetalleManifiesto>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<DetalleManifiesto>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxIdGuia.getSelectionModel().clearSelection();
        cbxIdEncomienda.getSelectionModel().clearSelection();
        txtPesoAsignadoTon.clear();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(DetalleManifiesto x) {
        ComboHelper.seleccionar(cbxIdGuia, x.getIdGuia() == null ? null : x.getIdGuia().getIdGuia());
        ComboHelper.seleccionar(cbxIdEncomienda, x.getIdEncomienda() == null ? null : x.getIdEncomienda().getIdEncomienda());
        txtPesoAsignadoTon.setText(x.getPesoAsignadoTon() == null ? "" : String.valueOf(x.getPesoAsignadoTon()));
        idCE = x.getIdDetalleManifiesto();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(DetalleManifiesto x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdDetalleManifiesto() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            detalleManifiestoService.delete(x.getIdDetalleManifiesto());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<DetalleManifiesto>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("idGuia", cbxIdGuia);
        campos.put("idEncomienda", cbxIdEncomienda);
        campos.put("pesoAsignadoTon", txtPesoAsignadoTon);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdDetalleManifiesto(idCE);
                detalleManifiestoService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                detalleManifiestoService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxIdGuia, cbxIdEncomienda, txtPesoAsignadoTon)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
