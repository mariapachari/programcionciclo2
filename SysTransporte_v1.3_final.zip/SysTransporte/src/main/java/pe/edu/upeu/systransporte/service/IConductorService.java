package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Conductor;

import java.util.List;

public interface IConductorService extends ICrudGenericoService<Conductor, String> {
    List<ComboBoxOption> listarCombobox();
}
