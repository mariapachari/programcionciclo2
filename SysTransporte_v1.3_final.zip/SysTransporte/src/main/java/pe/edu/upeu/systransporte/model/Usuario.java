package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

/**
 * Entidad que representa la tabla "usuarios".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
    private String idUsuario;

    @NotBlank(message = "El usuario es obligatorio")
    @Size(min = 3, max = 150, message = "El usuario debe tener entre 3 y 150 caracteres")
    @Pattern(regexp = "^[A-Za-z0-9._-]+$", message = "El usuario solo admite letras, números, punto, guion y guion bajo (sin espacios)")
    private String usuario;

    @NotBlank(message = "La clave es obligatoria")
    @Size(min = 6, message = "La clave debe tener al menos 6 caracteres")
    private String clave;

    @NotNull(message = "El rol es obligatorio")
    private Rol rol;

    @NotNull(message = "El estado es obligatorio")
    private EstadoGeneral estado;
}
