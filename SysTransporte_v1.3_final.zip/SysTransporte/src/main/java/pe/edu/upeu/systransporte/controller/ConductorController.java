package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.Conductor;
import pe.edu.upeu.systransporte.service.IConductorService;

import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_conductor.fxml — Gestionar Conductores.
 */
@RequiredArgsConstructor
public class ConductorController {
    private final IConductorService conductorService;

    @FXML
    TextField txtNombre, txtLicencia, txtTelefono, txtFiltroDato;
    @FXML
    ComboBox<ComboBoxOption> cbxCategoriaLicencia, cbxEstado;

    @FXML
    private TableView<Conductor> tableView;
    private PaginadorTabla<Conductor> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Conductor> listaConductor = FXCollections.observableArrayList();
    Conductor formulario;
    String idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxCategoriaLicencia.getItems().addAll(ComboHelper.desdeEnum(CategoriaLicencia.class));
        cbxEstado.getItems().addAll(ComboHelper.desdeEnum(EstadoGeneral.class));

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Conductor> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idConductor", 80.0));
        columns.put("Nombre", new ColumnInfo("nombre", 200.0));
        columns.put("N° Licencia", new ColumnInfo("licencia", 120.0));
        columns.put("Teléfono", new ColumnInfo("telefono", 110.0));
        columns.put("Categoría", new ColumnInfo("categoriaLicencia", 100.0));
        columns.put("Estado", new ColumnInfo("estado", 100.0));

        Consumer<Conductor> updateAction = this::editForm;
        Consumer<Conductor> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaConductor = FXCollections.observableArrayList(conductorService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaConductor
                : listaConductor.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Conductor();
        formulario.setNombre(txtNombre.getText() == null ? null : txtNombre.getText().trim());
        formulario.setLicencia(txtLicencia.getText() == null ? null : txtLicencia.getText().trim());
        formulario.setTelefono(txtTelefono.getText() == null ? null : txtTelefono.getText().trim());
        String kCategoriaLicencia = ComboHelper.keySeleccionado(cbxCategoriaLicencia);
        formulario.setCategoriaLicencia(kCategoriaLicencia == null ? null : CategoriaLicencia.valueOf(kCategoriaLicencia));
        String kEstado = ComboHelper.keySeleccionado(cbxEstado);
        formulario.setEstado(kEstado == null ? null : EstadoGeneral.valueOf(kEstado));

        Set<ConstraintViolation<Conductor>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Conductor>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        txtNombre.clear();
        txtLicencia.clear();
        txtTelefono.clear();
        cbxCategoriaLicencia.getSelectionModel().clearSelection();
        cbxEstado.getSelectionModel().clearSelection();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Conductor x) {
        txtNombre.setText(x.getNombre());
        txtLicencia.setText(x.getLicencia());
        txtTelefono.setText(x.getTelefono());
        ComboHelper.seleccionar(cbxCategoriaLicencia, x.getCategoriaLicencia());
        ComboHelper.seleccionar(cbxEstado, x.getEstado());
        idCE = x.getIdConductor();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Conductor x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdConductor() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            conductorService.delete(x.getIdConductor());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Conductor>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("nombre", txtNombre);
        campos.put("licencia", txtLicencia);
        campos.put("telefono", txtTelefono);
        campos.put("categoriaLicencia", cbxCategoriaLicencia);
        campos.put("estado", cbxEstado);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdConductor(idCE);
                conductorService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                conductorService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(txtNombre, txtLicencia, txtTelefono, cbxCategoriaLicencia, cbxEstado)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
