package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Paquete;

import java.util.List;

public interface IPaqueteService extends ICrudGenericoService<Paquete, Long> {
    List<ComboBoxOption> listarCombobox();
}
