package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ConductorRepository extends AbstractJpaRepository<Conductor, String> {

    @Override
    protected String getTableName() { return "conductores"; }

    @Override
    protected String getPkColumn() { return "idConductor"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    " FROM conductores t ";

    @Override
    public List<Conductor> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idConductor ASC");
    }

    @Override
    public Optional<Conductor> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idConductor = ?", id);
    }

    @Override
    protected Conductor mapRow(ResultSet rs) throws SQLException {
        return Conductor.builder()
                .idConductor(rs.getString("idConductor"))
                .nombre(rs.getString("nombre"))
                .licencia(rs.getString("licencia"))
                .telefono(rs.getString("telefono"))
                .categoriaLicencia(toEnum(CategoriaLicencia.class, rs.getString("categoriaLicencia")))
                .estado(toEnum(EstadoGeneral.class, rs.getString("estado")))
                .build();
    }

    @Override
    protected Conductor insert(Connection conn, Conductor e) throws SQLException {
        if (e.getIdConductor() == null || e.getIdConductor().isBlank()) {
            e.setIdConductor(generarCodigo(conn, "CON"));
        }
        executeUpdate(conn,
                "INSERT INTO conductores(idConductor, nombre, licencia, telefono, categoriaLicencia, estado) VALUES(?, ?, ?, ?, ?, ?)",
                e.getIdConductor(),
                e.getNombre(),
                e.getLicencia(),
                e.getTelefono(),
                enumName(e.getCategoriaLicencia()),
                enumName(e.getEstado()));
        return e;
    }

    @Override
    protected Conductor updateRow(Connection conn, Conductor e) throws SQLException {
        executeUpdate(conn,
                "UPDATE conductores SET nombre = ?, licencia = ?, telefono = ?, categoriaLicencia = ?, estado = ? WHERE idConductor = ?",
                e.getNombre(),
                e.getLicencia(),
                e.getTelefono(),
                enumName(e.getCategoriaLicencia()),
                enumName(e.getEstado()),
                e.getIdConductor());
        return e;
    }
}
