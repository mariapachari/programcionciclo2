package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Entrega;

import java.util.List;

public interface IEntregaService extends ICrudGenericoService<Entrega, Long> {
    List<ComboBoxOption> listarCombobox();
}
