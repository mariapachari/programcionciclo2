package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class VehiculoRepository extends AbstractJpaRepository<Vehiculo, String> {

    @Override
    protected String getTableName() { return "vehiculos"; }

    @Override
    protected String getPkColumn() { return "idVehiculo"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    " FROM vehiculos t ";

    @Override
    public List<Vehiculo> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idVehiculo ASC");
    }

    @Override
    public Optional<Vehiculo> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idVehiculo = ?", id);
    }

    @Override
    protected Vehiculo mapRow(ResultSet rs) throws SQLException {
        return Vehiculo.builder()
                .idVehiculo(rs.getString("idVehiculo"))
                .placa(rs.getString("placa"))
                .marca(rs.getString("marca"))
                .tipoVehiculo(toEnum(TipoVehiculo.class, rs.getString("tipoVehiculo")))
                .capacidadTon(rs.getDouble("capacidadTon"))
                .estado(toEnum(EstadoVehiculo.class, rs.getString("estado")))
                .build();
    }

    @Override
    protected Vehiculo insert(Connection conn, Vehiculo e) throws SQLException {
        if (e.getIdVehiculo() == null || e.getIdVehiculo().isBlank()) {
            e.setIdVehiculo(generarCodigo(conn, "VEH"));
        }
        executeUpdate(conn,
                "INSERT INTO vehiculos(idVehiculo, placa, marca, tipoVehiculo, capacidadTon, estado) VALUES(?, ?, ?, ?, ?, ?)",
                e.getIdVehiculo(),
                e.getPlaca(),
                e.getMarca(),
                enumName(e.getTipoVehiculo()),
                e.getCapacidadTon(),
                enumName(e.getEstado()));
        return e;
    }

    @Override
    protected Vehiculo updateRow(Connection conn, Vehiculo e) throws SQLException {
        executeUpdate(conn,
                "UPDATE vehiculos SET placa = ?, marca = ?, tipoVehiculo = ?, capacidadTon = ?, estado = ? WHERE idVehiculo = ?",
                e.getPlaca(),
                e.getMarca(),
                enumName(e.getTipoVehiculo()),
                e.getCapacidadTon(),
                enumName(e.getEstado()),
                e.getIdVehiculo());
        return e;
    }
}
