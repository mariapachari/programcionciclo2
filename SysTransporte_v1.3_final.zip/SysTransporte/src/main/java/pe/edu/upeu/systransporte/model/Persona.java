package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidad que representa la tabla "persona".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Persona {
    private Long idPersona;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 100, message = "Máximo 100 caracteres")
    private String nombre;

    @NotBlank(message = "El DNI es obligatorio")
    @Pattern(regexp = "\\d{8}", message = "El DNI debe tener 8 dígitos")
    private String dni;

    @Pattern(regexp = "^$|9\\d{8}", message = "El celular debe tener 9 dígitos y empezar con 9")
    private String celular;

    @Size(max = 100, message = "Máximo 100 caracteres")
    private String direccion;
}
