package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.DetalleManifiesto;

import java.util.List;

public interface IDetalleManifiestoService extends ICrudGenericoService<DetalleManifiesto, Long> {
    List<ComboBoxOption> listarCombobox();
}
