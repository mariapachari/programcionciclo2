package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Movimiento;

import java.util.List;

public interface IMovimientoService extends ICrudGenericoService<Movimiento, Long> {
    List<ComboBoxOption> listarCombobox();
}
