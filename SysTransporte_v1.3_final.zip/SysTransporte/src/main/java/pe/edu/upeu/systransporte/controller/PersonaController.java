package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Persona;
import pe.edu.upeu.systransporte.service.IPersonaService;

import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_persona.fxml — Gestionar Personas.
 */
@RequiredArgsConstructor
public class PersonaController {
    private final IPersonaService personaService;

    @FXML
    TextField txtNombre, txtDni, txtCelular, txtDireccion, txtFiltroDato;

    @FXML
    private TableView<Persona> tableView;
    private PaginadorTabla<Persona> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Persona> listaPersona = FXCollections.observableArrayList();
    Persona formulario;
    Long idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;


        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Persona> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idPersona", 80.0));
        columns.put("Nombre completo", new ColumnInfo("nombre", 220.0));
        columns.put("DNI", new ColumnInfo("dni", 100.0));
        columns.put("Celular", new ColumnInfo("celular", 110.0));
        columns.put("Dirección", new ColumnInfo("direccion", 220.0));

        Consumer<Persona> updateAction = this::editForm;
        Consumer<Persona> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaPersona = FXCollections.observableArrayList(personaService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaPersona
                : listaPersona.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Persona();
        formulario.setNombre(txtNombre.getText() == null ? null : txtNombre.getText().trim());
        formulario.setDni(txtDni.getText() == null ? null : txtDni.getText().trim());
        formulario.setCelular(txtCelular.getText() == null ? null : txtCelular.getText().trim());
        formulario.setDireccion(txtDireccion.getText() == null ? null : txtDireccion.getText().trim());

        Set<ConstraintViolation<Persona>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Persona>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        txtNombre.clear();
        txtDni.clear();
        txtCelular.clear();
        txtDireccion.clear();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Persona x) {
        txtNombre.setText(x.getNombre());
        txtDni.setText(x.getDni());
        txtCelular.setText(x.getCelular());
        txtDireccion.setText(x.getDireccion());
        idCE = x.getIdPersona();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Persona x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdPersona() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            personaService.delete(x.getIdPersona());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Persona>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("nombre", txtNombre);
        campos.put("dni", txtDni);
        campos.put("celular", txtCelular);
        campos.put("direccion", txtDireccion);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdPersona(idCE);
                personaService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                personaService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(txtNombre, txtDni, txtCelular, txtDireccion)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
