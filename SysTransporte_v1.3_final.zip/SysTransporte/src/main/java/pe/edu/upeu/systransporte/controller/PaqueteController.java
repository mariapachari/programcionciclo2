package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Paquete;
import pe.edu.upeu.systransporte.service.IPaqueteService;
import pe.edu.upeu.systransporte.service.IEncomiendaService;

import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_paquete.fxml — Gestionar Paquetes.
 */
@RequiredArgsConstructor
public class PaqueteController {
    private final IPaqueteService paqueteService;
    private final IEncomiendaService encomiendaService;

    @FXML
    TextField txtDescripcion, txtCantidad, txtPesoTon, txtFiltroDato;
    @FXML
    ComboBox<ComboBoxOption> cbxIdEncomienda;

    @FXML
    private TableView<Paquete> tableView;
    private PaginadorTabla<Paquete> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Paquete> listaPaquete = FXCollections.observableArrayList();
    Paquete formulario;
    Long idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdEncomienda.getItems().addAll(encomiendaService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdEncomienda);

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Paquete> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idPaquete", 80.0));
        columns.put("Encomienda", new ColumnInfo("idEncomienda.descripcionCarga", 200.0));
        columns.put("Descripción", new ColumnInfo("descripcion", 200.0));
        columns.put("Cantidad", new ColumnInfo("cantidad", 80.0));
        columns.put("Peso (t)", new ColumnInfo("pesoTon", 80.0));

        Consumer<Paquete> updateAction = this::editForm;
        Consumer<Paquete> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaPaquete = FXCollections.observableArrayList(paqueteService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaPaquete
                : listaPaquete.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Paquete();
        String kIdEncomienda = ComboHelper.keySeleccionado(cbxIdEncomienda);
        formulario.setIdEncomienda(kIdEncomienda == null ? null : encomiendaService.findById(Long.parseLong(kIdEncomienda)));
        formulario.setDescripcion(txtDescripcion.getText() == null ? null : txtDescripcion.getText().trim());
        formulario.setCantidad(parseIntSafe(txtCantidad.getText()));
        formulario.setPesoTon(parseDoubleSafe(txtPesoTon.getText()));

        Set<ConstraintViolation<Paquete>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Paquete>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    private Integer parseIntSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Integer.parseInt(value.trim()); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxIdEncomienda.getSelectionModel().clearSelection();
        txtDescripcion.clear();
        txtCantidad.clear();
        txtPesoTon.clear();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Paquete x) {
        ComboHelper.seleccionar(cbxIdEncomienda, x.getIdEncomienda() == null ? null : x.getIdEncomienda().getIdEncomienda());
        txtDescripcion.setText(x.getDescripcion());
        txtCantidad.setText(x.getCantidad() == null ? "" : String.valueOf(x.getCantidad()));
        txtPesoTon.setText(x.getPesoTon() == null ? "" : String.valueOf(x.getPesoTon()));
        idCE = x.getIdPaquete();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Paquete x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdPaquete() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            paqueteService.delete(x.getIdPaquete());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Paquete>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("idEncomienda", cbxIdEncomienda);
        campos.put("descripcion", txtDescripcion);
        campos.put("cantidad", txtCantidad);
        campos.put("pesoTon", txtPesoTon);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdPaquete(idCE);
                paqueteService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                paqueteService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxIdEncomienda, txtDescripcion, txtCantidad, txtPesoTon)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
