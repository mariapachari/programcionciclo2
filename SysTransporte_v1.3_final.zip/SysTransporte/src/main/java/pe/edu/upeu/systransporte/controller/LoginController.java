package pe.edu.upeu.systransporte.controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.SysTransporte;
import pe.edu.upeu.systransporte.components.StageManager;
import pe.edu.upeu.systransporte.components.Toast;
import pe.edu.upeu.systransporte.config.AppContext;
import pe.edu.upeu.systransporte.config.DatabaseConfig;
import pe.edu.upeu.systransporte.dto.SessionManager;
import pe.edu.upeu.systransporte.enums.EstadoGeneral;
import pe.edu.upeu.systransporte.model.Usuario;
import pe.edu.upeu.systransporte.service.IUsuarioService;

@RequiredArgsConstructor
public class LoginController {

    final private IUsuarioService us;

    @FXML
    TextField txtUsuario;

    @FXML
    PasswordField txtClave;

    @FXML
    public void login(ActionEvent e) {
        String usuarioTxt = txtUsuario.getText() == null ? "" : txtUsuario.getText().trim();
        String claveTxt = txtClave.getText() == null ? "" : txtClave.getText();
        // Validación de campos del formulario de login
        if (usuarioTxt.isEmpty()) {
            mensaje(e, "Ingrese su nombre de usuario");
            txtUsuario.requestFocus();
            return;
        }
        if (claveTxt.isEmpty()) {
            mensaje(e, "Ingrese su clave");
            txtClave.requestFocus();
            return;
        }
        try {
            us.loginUsuario(usuarioTxt, claveTxt)
                    .ifPresentOrElse(
                            usuario -> {
                                if (usuario.getEstado() != EstadoGeneral.ACTIVO) {
                                    mensaje(e, "El usuario está inactivo. Consulte al administrador");
                                } else {
                                    abrirPantalla(e, usuario);
                                }
                            },
                            () -> mensaje(e, "Error en las credenciales... Intente nuevamente")
                    );
        } catch (RuntimeException ex) {
            // Credenciales incorrectas o usuario bloqueado (ver ControlIntentosLogin)
            mensaje(e, ex.getMessage());
            txtClave.clear();
            txtClave.requestFocus();
        }
    }

    public void mensaje(ActionEvent e, String msg) {
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        double x = stage.getX() + stage.getWidth() / 2 - 150, y = stage.getY() + stage.getHeight() - 120;
        Toast.showToast(stage, msg, 2500, x, y);
    }

    @FXML
    public void logout() {
        DatabaseConfig.shutdown();
        Platform.exit();
        System.exit(0);
    }

    public void abrirPantalla(ActionEvent e, Usuario usuario) {
        SessionManager.getInstance().setUserId(usuario.getIdUsuario());
        SessionManager.getInstance().setUserName(usuario.getUsuario());
        SessionManager.getInstance().setUserPerfil(usuario.getRol().name());

        try {
            Rectangle2D rectangle2D = Screen.getPrimary().getVisualBounds();
            AppContext appContext = AppContext.getInstance();
            FXMLLoader fxmlLoader = new FXMLLoader(SysTransporte.class.getResource("/view/maingui.fxml"));
            fxmlLoader.setControllerFactory(appContext::getBean);
            Scene scene = new Scene(fxmlLoader.load(), rectangle2D.getWidth(), rectangle2D.getHeight());
            scene.getStylesheets().add(SysTransporte.class.getResource("/css/style.css").toExternalForm());
            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();

            StageManager.setPrimaryStage(stage);

            stage.setTitle("SysTransporte - Sistema de Transporte de Carga");
            stage.setScene(scene);
            stage.setX(rectangle2D.getMinX());
            stage.setY(rectangle2D.getMinY());
            stage.setResizable(true);
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
