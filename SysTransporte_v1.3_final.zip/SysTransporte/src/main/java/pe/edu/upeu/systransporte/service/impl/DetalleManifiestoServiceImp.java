package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.DetalleManifiesto;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.DetalleManifiestoRepository;
import pe.edu.upeu.systransporte.service.IDetalleManifiestoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class DetalleManifiestoServiceImp extends CrudGenericoServiceImp<DetalleManifiesto, Long> implements IDetalleManifiestoService {

    private final DetalleManifiestoRepository repo;

    @Override
    protected ICrudGenericoRepository<DetalleManifiesto, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (DetalleManifiesto x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdDetalleManifiesto()), x.getIdDetalleManifiesto().toString()));
        }
        return listar;
    }

    /** Regla de negocio: no superar la capacidad del vehículo del viaje. */
    private void validarCapacidad(DetalleManifiesto d) {
        String idGuia = d.getIdGuia().getIdGuia();
        double capacidad = repo.capacidadVehiculoDeGuia(idGuia);
        double ocupado = repo.pesoAsignadoEnGuia(idGuia, d.getIdDetalleManifiesto());
        if (ocupado + d.getPesoAsignadoTon() > capacidad) {
            throw new IllegalArgumentException(String.format(
                    "Capacidad excedida: el vehículo soporta %.2f t y ya tiene %.2f t asignadas", capacidad, ocupado));
        }
    }

    @Override
    public DetalleManifiesto save(DetalleManifiesto d) {
        validarCapacidad(d);
        return super.save(d);
    }

    @Override
    public DetalleManifiesto update(Long id, DetalleManifiesto d) {
        validarCapacidad(d);
        return super.update(id, d);
    }
}
