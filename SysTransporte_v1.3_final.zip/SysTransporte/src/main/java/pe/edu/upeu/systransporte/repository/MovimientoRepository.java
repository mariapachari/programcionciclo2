package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class MovimientoRepository extends AbstractJpaRepository<Movimiento, Long> {

    @Override
    protected String getTableName() { return "movimiento"; }

    @Override
    protected String getPkColumn() { return "id_movimiento"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", en.descripcionCarga AS en_descripcionCarga" +
                    ", us.usuario AS us_usuario" +
                    " FROM movimiento t " +
                    "JOIN encomienda en ON t.id_encomienda = en.id_encomienda " +
                    "JOIN usuarios us ON t.idUsuario = us.idUsuario ";

    @Override
    public List<Movimiento> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.id_movimiento DESC");
    }

    @Override
    public Optional<Movimiento> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_movimiento = ?", id);
    }

    @Override
    protected Movimiento mapRow(ResultSet rs) throws SQLException {
        return Movimiento.builder()
                .idMovimiento(rs.getLong("id_movimiento"))
                .idEncomienda(Encomienda.builder()
                        .idEncomienda(rs.getLong("id_encomienda"))
                        .descripcionCarga(rs.getString("en_descripcionCarga"))
                        .build())
                .idUsuario(Usuario.builder()
                        .idUsuario(rs.getString("idUsuario"))
                        .usuario(rs.getString("us_usuario"))
                        .build())
                .fechaMovimiento(rs.getObject("fechaMovimiento", LocalDate.class))
                .estado(toEnum(EstadoEncomienda.class, rs.getString("estado")))
                .observacion(rs.getString("observacion"))
                .build();
    }

    @Override
    protected Movimiento insert(Connection conn, Movimiento e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO movimiento(id_encomienda, idUsuario, fechaMovimiento, estado, observacion) VALUES(?, ?, ?, ?, ?)",
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getIdUsuario() == null ? null : e.getIdUsuario().getIdUsuario(),
                e.getFechaMovimiento(),
                enumName(e.getEstado()),
                e.getObservacion());
        e.setIdMovimiento(id);
        return e;
    }

    @Override
    protected Movimiento updateRow(Connection conn, Movimiento e) throws SQLException {
        executeUpdate(conn,
                "UPDATE movimiento SET id_encomienda = ?, idUsuario = ?, fechaMovimiento = ?, estado = ?, observacion = ? WHERE id_movimiento = ?",
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getIdUsuario() == null ? null : e.getIdUsuario().getIdUsuario(),
                e.getFechaMovimiento(),
                enumName(e.getEstado()),
                e.getObservacion(),
                e.getIdMovimiento());
        return e;
    }
}
