package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Encomienda;

import java.util.List;

public interface IEncomiendaService extends ICrudGenericoService<Encomienda, Long> {
    List<ComboBoxOption> listarCombobox();
}
