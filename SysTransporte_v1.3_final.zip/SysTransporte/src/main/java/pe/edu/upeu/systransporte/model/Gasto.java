package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla "gastos".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Gasto {
    private String idGasto;

    @NotNull(message = "Seleccione el viaje")
    private Viaje idViaje;

    @NotBlank(message = "El concepto es obligatorio")
    private String concepto;

    @NotNull(message = "El monto es obligatorio")
    @Positive(message = "El monto debe ser mayor a 0")
    private Double monto;

    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;
}
