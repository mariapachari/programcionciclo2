package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Manifiesto;

import java.util.List;

public interface IManifiestoService extends ICrudGenericoService<Manifiesto, String> {
    List<ComboBoxOption> listarCombobox();
}
