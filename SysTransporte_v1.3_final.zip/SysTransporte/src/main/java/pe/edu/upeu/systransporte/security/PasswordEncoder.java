package pe.edu.upeu.systransporte.security;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

/**
 * INVESTIGACIÓN ADICIONAL N° 1 — Encriptación (hash) de contraseñas.
 *
 * <p>Las claves NO se guardan en texto plano. Se usa el algoritmo estándar
 * <b>PBKDF2 con HMAC-SHA256</b> (incluido en Java, no necesita librerías):
 * <ol>
 *   <li>Se genera una <b>sal</b> aleatoria de 16 bytes con {@link SecureRandom}
 *       (dos usuarios con la misma clave tendrán hashes distintos).</li>
 *   <li>Se aplica la función 65 536 veces (iteraciones) para que un ataque de
 *       fuerza bruta sea muy lento.</li>
 *   <li>Se guarda en la BD con el formato: {@code pbkdf2$iteraciones$sal$hash}
 *       (sal y hash en Base64).</li>
 * </ol>
 * Para iniciar sesión se vuelve a calcular el hash con la misma sal y se compara
 * en tiempo constante ({@link MessageDigest#isEqual}).
 */
public final class PasswordEncoder {

    public static final String PREFIJO = "pbkdf2";
    private static final String ALGORITMO = "PBKDF2WithHmacSHA256";
    private static final int ITERACIONES = 65_536;
    private static final int LONGITUD_BITS = 256;
    private static final int LONGITUD_SAL = 16;
    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordEncoder() {
    }

    /** Convierte una clave en texto plano en un hash seguro para guardar en la BD. */
    public static String encriptar(String claveTextoPlano) {
        if (claveTextoPlano == null) {
            throw new IllegalArgumentException("La clave no puede ser nula");
        }
        byte[] sal = new byte[LONGITUD_SAL];
        RANDOM.nextBytes(sal);
        byte[] hash = pbkdf2(claveTextoPlano.toCharArray(), sal, ITERACIONES);
        Base64.Encoder b64 = Base64.getEncoder();
        return PREFIJO + "$" + ITERACIONES + "$" + b64.encodeToString(sal) + "$" + b64.encodeToString(hash);
    }

    /** Verifica si la clave escrita en el login coincide con el hash guardado. */
    public static boolean verificar(String claveTextoPlano, String hashGuardado) {
        if (claveTextoPlano == null || hashGuardado == null) {
            return false;
        }
        if (!estaEncriptada(hashGuardado)) {
            // Compatibilidad con bases antiguas (clave en texto plano)
            return MessageDigest.isEqual(claveTextoPlano.getBytes(), hashGuardado.getBytes());
        }
        String[] partes = hashGuardado.split("\\$");
        if (partes.length != 4) {
            return false;
        }
        try {
            int iteraciones = Integer.parseInt(partes[1]);
            byte[] sal = Base64.getDecoder().decode(partes[2]);
            byte[] esperado = Base64.getDecoder().decode(partes[3]);
            byte[] calculado = pbkdf2(claveTextoPlano.toCharArray(), sal, iteraciones);
            return MessageDigest.isEqual(esperado, calculado);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /** true si el valor ya tiene el formato de hash (no es texto plano). */
    public static boolean estaEncriptada(String valor) {
        return valor != null && valor.startsWith(PREFIJO + "$");
    }

    private static byte[] pbkdf2(char[] clave, byte[] sal, int iteraciones) {
        PBEKeySpec spec = new PBEKeySpec(clave, sal, iteraciones, LONGITUD_BITS);
        try {
            return SecretKeyFactory.getInstance(ALGORITMO).generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalStateException("No se pudo encriptar la clave", e);
        } finally {
            spec.clearPassword();
        }
    }
}
