package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.Entrega;
import pe.edu.upeu.systransporte.service.IEntregaService;
import pe.edu.upeu.systransporte.service.IEncomiendaService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_entrega.fxml — Registrar Entregas.
 */
@RequiredArgsConstructor
public class EntregaController {
    private final IEntregaService entregaService;
    private final IEncomiendaService encomiendaService;

    @FXML
    TextField txtReceptor, txtObservacion, txtFiltroDato;
    @FXML
    DatePicker dpFechaEntrega;
    @FXML
    ComboBox<ComboBoxOption> cbxIdEncomienda, cbxEstado;

    @FXML
    private TableView<Entrega> tableView;
    private PaginadorTabla<Entrega> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Entrega> listaEntrega = FXCollections.observableArrayList();
    Entrega formulario;
    Long idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdEncomienda.getItems().addAll(encomiendaService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdEncomienda);
        dpFechaEntrega.setValue(LocalDate.now());
        cbxEstado.getItems().addAll(ComboHelper.desdeEnum(EstadoEntrega.class));

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Entrega> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idEntrega", 80.0));
        columns.put("Encomienda", new ColumnInfo("idEncomienda.descripcionCarga", 200.0));
        columns.put("Fecha entrega", new ColumnInfo("fechaEntrega", 110.0));
        columns.put("Receptor", new ColumnInfo("receptor", 180.0));
        columns.put("Estado", new ColumnInfo("estado", 100.0));
        columns.put("Observación", new ColumnInfo("observacion", 200.0));

        Consumer<Entrega> updateAction = this::editForm;
        Consumer<Entrega> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaEntrega = FXCollections.observableArrayList(entregaService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaEntrega
                : listaEntrega.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Entrega();
        String kIdEncomienda = ComboHelper.keySeleccionado(cbxIdEncomienda);
        formulario.setIdEncomienda(kIdEncomienda == null ? null : encomiendaService.findById(Long.parseLong(kIdEncomienda)));
        formulario.setFechaEntrega(dpFechaEntrega.getValue());
        formulario.setReceptor(txtReceptor.getText() == null ? null : txtReceptor.getText().trim());
        String kEstado = ComboHelper.keySeleccionado(cbxEstado);
        formulario.setEstado(kEstado == null ? null : EstadoEntrega.valueOf(kEstado));
        formulario.setObservacion(txtObservacion.getText() == null ? null : txtObservacion.getText().trim());

        Set<ConstraintViolation<Entrega>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Entrega>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxIdEncomienda.getSelectionModel().clearSelection();
        dpFechaEntrega.setValue(LocalDate.now());
        txtReceptor.clear();
        cbxEstado.getSelectionModel().clearSelection();
        txtObservacion.clear();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Entrega x) {
        ComboHelper.seleccionar(cbxIdEncomienda, x.getIdEncomienda() == null ? null : x.getIdEncomienda().getIdEncomienda());
        dpFechaEntrega.setValue(x.getFechaEntrega());
        txtReceptor.setText(x.getReceptor());
        ComboHelper.seleccionar(cbxEstado, x.getEstado());
        txtObservacion.setText(x.getObservacion());
        idCE = x.getIdEntrega();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Entrega x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdEntrega() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            entregaService.delete(x.getIdEntrega());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Entrega>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("idEncomienda", cbxIdEncomienda);
        campos.put("fechaEntrega", dpFechaEntrega);
        campos.put("receptor", txtReceptor);
        campos.put("estado", cbxEstado);
        campos.put("observacion", txtObservacion);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdEntrega(idCE);
                entregaService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                entregaService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxIdEncomienda, dpFechaEntrega, txtReceptor, cbxEstado, txtObservacion)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
