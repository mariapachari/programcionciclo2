package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla "entrega".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Entrega {
    private Long idEntrega;

    @NotNull(message = "Seleccione la encomienda")
    private Encomienda idEncomienda;

    @NotNull(message = "La fecha de entrega es obligatoria")
    private LocalDate fechaEntrega;

    @NotBlank(message = "El nombre del receptor es obligatorio")
    private String receptor;

    @NotNull(message = "El estado es obligatorio")
    private EstadoEntrega estado;

    @Size(max = 200, message = "Máximo 200 caracteres")
    private String observacion;
}
