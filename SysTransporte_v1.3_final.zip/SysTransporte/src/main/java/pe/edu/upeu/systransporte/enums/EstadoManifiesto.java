package pe.edu.upeu.systransporte.enums;

import lombok.Getter;

@Getter
public enum EstadoManifiesto {
    EMITIDO("Emitido"),
    CERRADO("Cerrado"),
    ANULADO("Anulado");

    private final String descripcion;

    EstadoManifiesto(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
