package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla "viajes".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Viaje {
    private String idViaje;

    @NotBlank(message = "El origen es obligatorio")
    private String origen;

    @NotBlank(message = "El destino es obligatorio")
    private String destino;

    @NotBlank(message = "El tipo de carga es obligatorio")
    private String tipoCarga;

    @NotNull(message = "Seleccione el conductor")
    private Conductor idConductor;

    @NotNull(message = "Seleccione el vehículo")
    private Vehiculo idVehiculo;

    @NotNull(message = "La fecha de salida es obligatoria")
    private LocalDate fechaSalida;

    private LocalDate fechaLlegada;

    @NotNull(message = "El costo del flete es obligatorio")
    @Positive(message = "El flete debe ser mayor a 0")
    private Double costoFlete;

    @NotNull(message = "El estado es obligatorio")
    private EstadoViaje estado;
}
