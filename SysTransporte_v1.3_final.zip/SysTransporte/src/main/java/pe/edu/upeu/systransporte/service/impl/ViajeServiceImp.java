package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.EstadoGeneral;
import pe.edu.upeu.systransporte.enums.EstadoVehiculo;
import pe.edu.upeu.systransporte.model.Viaje;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.ViajeRepository;
import pe.edu.upeu.systransporte.service.IViajeService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class ViajeServiceImp extends CrudGenericoServiceImp<Viaje, String> implements IViajeService {

    private final ViajeRepository repo;

    @Override
    protected ICrudGenericoRepository<Viaje, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Viaje x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdViaje()), x.getIdViaje() + " - " + x.getOrigen() + " → " + x.getDestino() + " (" + x.getFechaSalida() + ")"));
        }
        return listar;
    }

    /** Regla de negocio: la llegada no puede ser antes de la salida. */
    private void validarFechas(Viaje v) {
        if (v.getFechaLlegada() != null && v.getFechaSalida() != null
                && v.getFechaLlegada().isBefore(v.getFechaSalida())) {
            throw new IllegalArgumentException("La fecha de llegada no puede ser anterior a la fecha de salida");
        }
    }

    /** MEJORA: no se asigna un conductor inactivo ni un vehículo en mantenimiento. */
    private void validarDisponibilidad(Viaje v) {
        if (v.getIdConductor().getEstado() == EstadoGeneral.INACTIVO) {
            throw new IllegalArgumentException("El conductor " + v.getIdConductor().getNombre() + " está INACTIVO");
        }
        if (v.getIdVehiculo().getEstado() == EstadoVehiculo.MANTENIMIENTO) {
            throw new IllegalArgumentException("El vehículo " + v.getIdVehiculo().getPlaca() + " está en MANTENIMIENTO");
        }
    }

    @Override
    public Viaje save(Viaje v) {
        validarFechas(v);
        validarDisponibilidad(v);
        return super.save(v);
    }

    @Override
    public Viaje update(String id, Viaje v) {
        validarFechas(v);
        validarDisponibilidad(v);
        return super.update(id, v);
    }
}
