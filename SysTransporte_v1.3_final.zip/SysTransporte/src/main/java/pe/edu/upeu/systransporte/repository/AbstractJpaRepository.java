package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.repository.helper.SqlHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public abstract class AbstractJpaRepository<T,ID>  extends SqlHelper<T>
        implements ICrudGenericoRepository<T,ID>{

    protected abstract String getTableName();
    protected abstract String getPkColumn();
    protected abstract T insert(Connection connection, T entity) throws SQLException;
    protected abstract T updateRow(Connection connection, T entity) throws SQLException;

    @Override
    public T save(T entity) {
        try(Connection conn = openConnection()) {
            conn.setAutoCommit(false);
            try {
                T result = insert(conn, entity);
                conn.commit();
                return result;
            } catch (Exception e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error en guardar: " + e.getMessage(), e);
        }
    }

    @Override
    public T update(T entity) {
        try(Connection conn = openConnection()) {
            conn.setAutoCommit(false);
            try {
                T result = updateRow(conn, entity);
                conn.commit();
                return result;
            } catch (Exception e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar: " + e.getMessage(), e);
        }
    }
    @Override
    public Optional<T> findById(ID id) {
        String sql = "SELECT * FROM " + getTableName() + " WHERE " + getPkColumn() + " = ?";
        return executeQueryOne(sql, id);
    }
    @Override
    public List<T> findAll() {
        String sql = "SELECT * FROM " + getTableName();
        return executeQuery(sql);
    }
    @Override
    public void deleteById(ID id) {
        String sql = "DELETE FROM " + getTableName() + " WHERE " + getPkColumn() + " = ?";
        executeUpdateStandalone(sql, id);
    }
    @Override
    public boolean existsById(ID id) {
        String sql = "SELECT 1 FROM " + getTableName() + " WHERE " + getPkColumn() + " = ?";
        return executeExists(sql, id);
    }





    /**
     * MEJORA: verifica si ya existe OTRO registro con el mismo valor en una columna.
     * Sirve para evitar duplicados (DNI, RUC, placa, usuario...).
     *
     * @param columna  columna a revisar (ej. "dni")
     * @param valor    valor ingresado en el formulario
     * @param idActual id del registro que se está editando (null si es nuevo)
     */
    public boolean existeDuplicado(String columna, Object valor, ID idActual) {
        if (valor == null) return false;
        if (idActual == null) {
            return executeScalarDouble("SELECT COUNT(*) FROM " + getTableName()
                    + " WHERE " + columna + " = ?", valor) > 0;
        }
        return executeScalarDouble("SELECT COUNT(*) FROM " + getTableName()
                + " WHERE " + columna + " = ? AND " + getPkColumn() + " <> ?", valor, idActual) > 0;
    }

    /**
     * Genera el siguiente código para tablas cuya PK es VARCHAR.
     * Ej: prefijo "CLI" → CLI0001, CLI0002, ...
     */
    protected String generarCodigo(Connection conn, String prefijo) throws SQLException {
        int max = maxCorrelativo(conn, getPkColumn(), prefijo);
        return prefijo + String.format("%04d", max + 1);
    }

    /**
     * Genera un número de documento correlativo por serie.
     * Ej: serie "B001" → B001-000001, B001-000002, ...
     */
    protected String generarCorrelativo(Connection conn, String columna, String serie) throws SQLException {
        int max = maxCorrelativo(conn, columna, serie + "-");
        return serie + "-" + String.format("%06d", max + 1);
    }

    private int maxCorrelativo(Connection conn, String columna, String prefijo) throws SQLException {
        String sql = "SELECT " + columna + " FROM " + getTableName() + " WHERE " + columna + " LIKE ?";
        int max = 0;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, prefijo + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String numero = rs.getString(1).substring(prefijo.length());
                    try {
                        max = Math.max(max, Integer.parseInt(numero));
                    } catch (NumberFormatException ignored) {
                        // código con formato distinto: se ignora
                    }
                }
            }
        }
        return max;
    }
}
