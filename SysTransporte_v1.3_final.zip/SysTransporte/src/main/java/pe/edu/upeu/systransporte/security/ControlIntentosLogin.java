package pe.edu.upeu.systransporte.security;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * INVESTIGACIÓN ADICIONAL N° 3 — Bloqueo temporal por intentos fallidos.
 *
 * <p>Si un usuario se equivoca de clave {@value #MAX_INTENTOS} veces seguidas,
 * queda bloqueado {@value #SEGUNDOS_BLOQUEO} segundos. Protege contra ataques
 * de fuerza bruta (probar claves una y otra vez).
 */
public class ControlIntentosLogin {

    public static final int MAX_INTENTOS = 3;
    public static final int SEGUNDOS_BLOQUEO = 30;

    private final Map<String, Integer> fallidos = new ConcurrentHashMap<>();
    private final Map<String, Instant> bloqueadoHasta = new ConcurrentHashMap<>();

    /** Segundos que faltan para desbloquear (0 = no está bloqueado). */
    public long segundosBloqueo(String usuario) {
        Instant hasta = bloqueadoHasta.get(clave(usuario));
        if (hasta == null) return 0;
        long seg = Duration.between(Instant.now(), hasta).toSeconds();
        if (seg <= 0) {
            bloqueadoHasta.remove(clave(usuario));
            return 0;
        }
        return seg + 1;
    }

    /** Registra un intento fallido y devuelve cuántos intentos le quedan. */
    public int registrarFallo(String usuario) {
        int n = fallidos.merge(clave(usuario), 1, Integer::sum);
        if (n >= MAX_INTENTOS) {
            fallidos.remove(clave(usuario));
            bloqueadoHasta.put(clave(usuario), Instant.now().plusSeconds(SEGUNDOS_BLOQUEO));
            return 0;
        }
        return MAX_INTENTOS - n;
    }

    public void registrarExito(String usuario) {
        fallidos.remove(clave(usuario));
        bloqueadoHasta.remove(clave(usuario));
    }

    private String clave(String usuario) {
        return usuario == null ? "" : usuario.trim().toLowerCase();
    }
}
