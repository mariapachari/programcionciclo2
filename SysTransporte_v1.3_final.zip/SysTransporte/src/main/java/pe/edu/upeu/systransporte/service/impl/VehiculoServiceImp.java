package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Vehiculo;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.VehiculoRepository;
import pe.edu.upeu.systransporte.service.IVehiculoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class VehiculoServiceImp extends CrudGenericoServiceImp<Vehiculo, String> implements IVehiculoService {

    private final VehiculoRepository repo;

    @Override
    protected ICrudGenericoRepository<Vehiculo, String> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Vehiculo x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdVehiculo()), x.getPlaca() + " - " + x.getMarca() + " (" + x.getCapacidadTon() + " t)"));
        }
        return listar;
    }

    // ===== MEJORA: evitar registros duplicados =====
    private void validarDuplicado(Vehiculo x) {
        if (repo.existeDuplicado("placa", x.getPlaca(), x.getIdVehiculo())) {
            throw new IllegalArgumentException("Ya existe un vehículo con la placa " + x.getPlaca());
        }
    }

    @Override
    public Vehiculo save(Vehiculo x) {
        validarDuplicado(x);
        return super.save(x);
    }

    @Override
    public Vehiculo update(String id, Vehiculo x) {
        validarDuplicado(x);
        return super.update(id, x);
    }
}
