package pe.edu.upeu.systransporte.components;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.print.PageLayout;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.transform.Scale;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import pe.edu.upeu.systransporte.dto.SessionManager;
import pe.edu.upeu.systransporte.enums.TipoComprobante;
import pe.edu.upeu.systransporte.model.*;

import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Arma e imprime los documentos del sistema (comprobante de pago y manifiesto de carga).
 * Usa javafx.print.PrinterJob: no necesita librerías extra.
 * En el diálogo de impresión se puede elegir una impresora real o "Microsoft Print to PDF"
 * para guardar el documento como PDF.
 */
public final class ImpresionHelper {

    // ===== DATOS DE LA EMPRESA (edítalos con los datos reales) =====
    public static final String EMPRESA = "SYSTRANSPORTE S.A.C.";
    public static final String RUC_EMPRESA = "20000000000";
    public static final String DIRECCION_EMPRESA = "Dirección de la empresa";
    public static final String TELEFONO_EMPRESA = "Teléfono de la empresa";
    public static final double IGV = 0.18;

    private static final double ANCHO = 540;          // ancho del documento en px (≈ hoja A4 menos márgenes)
    private static final String COLOR = "#1f3397";    // mismo azul de los títulos del sistema
    private static final DateTimeFormatter FMT_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private ImpresionHelper() {
    }

    // =====================================================================
    //  1. COMPROBANTE DE PAGO (boleta o factura)
    // =====================================================================
    public static VBox documentoComprobante(Comprobante c, Encomienda e, Cliente cliente, List<Paquete> paquetes) {
        boolean factura = c.getTipo() == TipoComprobante.FACTURA;
        VBox hoja = hoja();

        hoja.getChildren().add(cabecera(factura ? "FACTURA" : "BOLETA DE VENTA", c.getNumero()));

        String nombreCliente = cliente != null ? cliente.getRazonSocial()
                : (e.getIdCliente() != null ? e.getIdCliente().getRazonSocial() : null);
        hoja.getChildren().addAll(
                seccion("DATOS DEL CLIENTE Y DEL ENVÍO"),
                datos(
                        "Fecha de emisión", fecha(c.getFecha()),
                        factura ? "Razón social" : "Cliente", txt(nombreCliente),
                        "RUC", cliente != null ? txt(cliente.getRuc()) : "-",
                        "Remitente", persona(e.getIdRemitente()),
                        "Destinatario", persona(e.getIdDestinatario()),
                        "Ruta", txt(e.getLugarOrigen()) + "  →  " + txt(e.getLugarDestino()),
                        "Estado de pago", c.getEstadoPago() == null ? "-" : c.getEstadoPago().toString()));

        // Detalle: el servicio de transporte de la encomienda
        List<String[]> filas = new ArrayList<>();
        filas.add(new String[]{"1", "Servicio de transporte de carga: " + txt(e.getDescripcionCarga()),
                numero(e.getPesoTon()), dinero(c.getMonto())});
        hoja.getChildren().addAll(seccion("DETALLE"),
                tabla(new String[]{"Cant.", "Descripción", "Peso (t)", "Importe"},
                        new double[]{10, 55, 15, 20}, filas, new boolean[]{false, false, true, true}));

        // Paquetes que forman la encomienda (si se registraron)
        if (paquetes != null && !paquetes.isEmpty()) {
            List<String[]> filasPaq = new ArrayList<>();
            for (Paquete p : paquetes) {
                filasPaq.add(new String[]{String.valueOf(p.getCantidad()), txt(p.getDescripcion()), numero(p.getPesoTon())});
            }
            hoja.getChildren().addAll(texto("Contenido de la encomienda:", true),
                    tabla(new String[]{"Cant.", "Paquete", "Peso (t)"},
                            new double[]{10, 70, 20}, filasPaq, new boolean[]{false, false, true}));
        }

        // Totales
        double total = c.getMonto() == null ? 0 : c.getMonto();
        VBox totales = new VBox(3);
        totales.setAlignment(Pos.CENTER_RIGHT);
        if (factura) {
            double gravada = total / (1 + IGV);
            totales.getChildren().addAll(
                    lineaTotal("Op. gravada", dinero(gravada), false),
                    lineaTotal("IGV (18 %)", dinero(total - gravada), false));
        }
        totales.getChildren().add(lineaTotal("IMPORTE TOTAL", dinero(total), true));
        hoja.getChildren().add(totales);

        hoja.getChildren().add(pie("Gracias por su preferencia."));
        return hoja;
    }

    // =====================================================================
    //  2. MANIFIESTO DE CARGA
    // =====================================================================
    public static VBox documentoManifiesto(Manifiesto m, Viaje v, List<DetalleManifiesto> detalles,
                                           Map<Long, Encomienda> encomiendas) {
        VBox hoja = hoja();
        hoja.getChildren().add(cabecera("MANIFIESTO DE CARGA", m.getNumeroGuia()));

        String conductor = v.getIdConductor() == null ? "-" : txt(v.getIdConductor().getNombre());
        String placa = v.getIdVehiculo() == null ? "-" : txt(v.getIdVehiculo().getPlaca());
        Double capacidad = v.getIdVehiculo() == null ? null : v.getIdVehiculo().getCapacidadTon();

        hoja.getChildren().addAll(
                seccion("DATOS DEL VIAJE"),
                datos(
                        "Fecha de emisión", fecha(m.getFechaEmision()),
                        "Viaje", txt(v.getIdViaje()),
                        "Ruta", txt(v.getOrigen()) + "  →  " + txt(v.getDestino()),
                        "Fecha de salida", fecha(v.getFechaSalida()),
                        "Conductor", conductor,
                        "Vehículo (placa)", placa,
                        "Capacidad", capacidad == null ? "-" : numero(capacidad) + " t",
                        "Estado", m.getEstado() == null ? "-" : m.getEstado().toString()));

        List<String[]> filas = new ArrayList<>();
        double pesoTotal = 0;
        int n = 1;
        for (DetalleManifiesto d : detalles) {
            Encomienda e = d.getIdEncomienda() == null ? null : encomiendas.get(d.getIdEncomienda().getIdEncomienda());
            String carga = e != null ? e.getDescripcionCarga()
                    : (d.getIdEncomienda() == null ? null : d.getIdEncomienda().getDescripcionCarga());
            filas.add(new String[]{
                    String.valueOf(n++),
                    txt(carga),
                    e == null ? "-" : persona(e.getIdDestinatario()),
                    e == null ? "-" : txt(e.getLugarDestino()),
                    numero(d.getPesoAsignadoTon())});
            pesoTotal += d.getPesoAsignadoTon() == null ? 0 : d.getPesoAsignadoTon();
        }
        if (filas.isEmpty()) {
            filas.add(new String[]{"-", "Esta guía todavía no tiene encomiendas asignadas", "-", "-", "-"});
        }
        hoja.getChildren().addAll(seccion("CARGA TRANSPORTADA"),
                tabla(new String[]{"N°", "Encomienda", "Destinatario", "Destino", "Peso (t)"},
                        new double[]{7, 33, 28, 17, 15}, filas, new boolean[]{false, false, false, false, true}));

        VBox totales = new VBox(3);
        totales.setAlignment(Pos.CENTER_RIGHT);
        totales.getChildren().add(lineaTotal("PESO TOTAL", numero(pesoTotal) + " t", true));
        if (capacidad != null && capacidad > 0) {
            totales.getChildren().add(lineaTotal("Uso de la capacidad",
                    String.format(Locale.US, "%.1f %%", pesoTotal * 100 / capacidad), false));
        }
        hoja.getChildren().add(totales);

        // Firmas
        HBox firmas = new HBox(60, firma("Firma del conductor"), firma("Firma del responsable"));
        firmas.setAlignment(Pos.CENTER);
        firmas.setPadding(new Insets(40, 0, 0, 0));
        hoja.getChildren().addAll(firmas, pie(null));
        return hoja;
    }

    // =====================================================================
    //  VISTA PREVIA E IMPRESIÓN
    // =====================================================================

    /** Abre una ventana con la vista previa del documento y un botón para imprimirlo. */
    public static void vistaPrevia(Window owner, String titulo, Region documento) {
        Stage ventana = new Stage();
        ventana.initOwner(owner);
        ventana.initModality(Modality.WINDOW_MODAL);
        ventana.setTitle("Vista previa - " + titulo);

        StackPane fondo = new StackPane(documento);
        fondo.setPadding(new Insets(20));
        fondo.setStyle("-fx-background-color: #d9dce6;");
        ScrollPane scroll = new ScrollPane(fondo);
        scroll.setFitToWidth(true);

        Button btnImprimir = new Button("Imprimir / Guardar PDF");
        btnImprimir.setDefaultButton(true);
        btnImprimir.setOnAction(ev -> {
            if (imprimir(ventana, documento)) ventana.close();
        });
        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setCancelButton(true);
        btnCerrar.setOnAction(ev -> ventana.close());

        HBox barra = new HBox(10, btnImprimir, btnCerrar);
        barra.setAlignment(Pos.CENTER_RIGHT);
        barra.setPadding(new Insets(10));

        BorderPane raiz = new BorderPane(scroll);
        raiz.setBottom(barra);
        ventana.setScene(new Scene(raiz, ANCHO + 80, 720));
        ventana.show();
    }

    /**
     * Envía el nodo a la impresora. Muestra el diálogo de impresión (ahí se elige la impresora,
     * el papel o "Microsoft Print to PDF"). Escala el documento para que entre en una página.
     *
     * @return true si se imprimió
     */
    public static boolean imprimir(Window owner, Node documento) {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job == null) {
            alerta(owner, "No se encontró ninguna impresora instalada en el equipo.");
            return false;
        }
        if (!job.showPrintDialog(owner)) {   // el usuario canceló
            job.cancelJob();
            return false;
        }
        PageLayout pagina = job.getJobSettings().getPageLayout();
        double ancho = documento.getLayoutBounds().getWidth();
        double alto = documento.getLayoutBounds().getHeight();
        double escala = Math.min(1.0, Math.min(pagina.getPrintableWidth() / ancho, pagina.getPrintableHeight() / alto));

        Scale ajuste = new Scale(escala, escala);
        documento.getTransforms().add(ajuste);
        boolean ok = job.printPage(pagina, documento);
        documento.getTransforms().remove(ajuste);

        if (ok) {
            job.endJob();
        } else {
            job.cancelJob();
            alerta(owner, "No se pudo imprimir el documento.");
        }
        return ok;
    }

    // =====================================================================
    //  PIEZAS DEL DOCUMENTO
    // =====================================================================
    private static VBox hoja() {
        VBox hoja = new VBox(10);
        hoja.setPadding(new Insets(24));
        hoja.setMinWidth(ANCHO);
        hoja.setPrefWidth(ANCHO);
        hoja.setMaxWidth(ANCHO);
        hoja.setStyle("-fx-background-color: white; -fx-font-family: 'Arial'; -fx-font-size: 11px;");
        return hoja;
    }

    private static HBox cabecera(String titulo, String numero) {
        VBox empresa = new VBox(2);
        Image logo = cargarLogo();
        if (logo != null) {
            ImageView iv = new ImageView(logo);
            iv.setFitHeight(48);
            iv.setPreserveRatio(true);
            empresa.getChildren().add(iv);
        }
        Label nombre = new Label(EMPRESA);
        nombre.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + COLOR + ";");
        empresa.getChildren().addAll(nombre, new Label(DIRECCION_EMPRESA), new Label("Tel.: " + TELEFONO_EMPRESA));

        VBox recuadro = new VBox(4);
        recuadro.setAlignment(Pos.CENTER);
        recuadro.setPadding(new Insets(10, 16, 10, 16));
        recuadro.setMinWidth(190);
        recuadro.setStyle("-fx-border-color: " + COLOR + "; -fx-border-width: 2; -fx-border-radius: 6;");
        Label ruc = new Label("R.U.C. N° " + RUC_EMPRESA);
        ruc.setStyle("-fx-font-weight: bold;");
        Label tit = new Label(titulo);
        tit.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: " + COLOR + ";");
        Label num = new Label(txt(numero));
        num.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
        recuadro.getChildren().addAll(ruc, tit, num);

        Pane espacio = new Pane();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        HBox cab = new HBox(10, empresa, espacio, recuadro);
        cab.setAlignment(Pos.CENTER_LEFT);
        return cab;
    }

    private static Label seccion(String texto) {
        Label l = new Label(texto);
        l.setMaxWidth(Double.MAX_VALUE);
        l.setPadding(new Insets(4, 8, 4, 8));
        l.setStyle("-fx-background-color: #eef0f6; -fx-font-weight: bold; -fx-text-fill: " + COLOR + ";");
        return l;
    }

    /** Pares etiqueta/valor en dos columnas: datos("Fecha", "01/01/2026", "Cliente", "ABC", ...) */
    private static GridPane datos(String... paresEtiquetaValor) {
        GridPane g = new GridPane();
        g.setHgap(10);
        g.setVgap(4);
        ColumnConstraints c1 = new ColumnConstraints();
        c1.setPercentWidth(28);
        ColumnConstraints c2 = new ColumnConstraints();
        c2.setPercentWidth(72);
        g.getColumnConstraints().addAll(c1, c2);
        for (int i = 0; i + 1 < paresEtiquetaValor.length; i += 2) {
            Label k = new Label(paresEtiquetaValor[i] + ":");
            k.setStyle("-fx-font-weight: bold;");
            Label v = new Label(paresEtiquetaValor[i + 1]);
            v.setWrapText(true);
            g.addRow(i / 2, k, v);
        }
        return g;
    }

    private static GridPane tabla(String[] cabeceras, double[] porcentajes, List<String[]> filas, boolean[] derecha) {
        GridPane g = new GridPane();
        for (double p : porcentajes) {
            ColumnConstraints cc = new ColumnConstraints();
            cc.setPercentWidth(p);
            g.getColumnConstraints().add(cc);
        }
        for (int c = 0; c < cabeceras.length; c++) {
            g.add(celda(cabeceras[c], derecha[c], true, false), c, 0);
        }
        for (int f = 0; f < filas.size(); f++) {
            String[] fila = filas.get(f);
            for (int c = 0; c < fila.length; c++) {
                g.add(celda(fila[c], derecha[c], false, f % 2 == 1), c, f + 1);
            }
        }
        return g;
    }

    private static Label celda(String texto, boolean derecha, boolean cabecera, boolean alterna) {
        Label l = new Label(texto);
        l.setWrapText(true);
        l.setMaxWidth(Double.MAX_VALUE);
        l.setMaxHeight(Double.MAX_VALUE);
        l.setAlignment(derecha ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
        l.setPadding(new Insets(4, 6, 4, 6));
        GridPane.setHalignment(l, derecha ? HPos.RIGHT : HPos.LEFT);
        GridPane.setFillWidth(l, true);
        GridPane.setFillHeight(l, true);
        if (cabecera) {
            l.setStyle("-fx-background-color: " + COLOR + "; -fx-text-fill: white; -fx-font-weight: bold;");
        } else {
            l.setStyle("-fx-background-color: " + (alterna ? "#f6f7fb" : "white") + ";"
                    + " -fx-border-color: transparent transparent #d9dce6 transparent;");
        }
        return l;
    }

    private static HBox lineaTotal(String etiqueta, String valor, boolean resaltado) {
        Label k = new Label(etiqueta);
        Label v = new Label(valor);
        v.setMinWidth(110);
        v.setAlignment(Pos.CENTER_RIGHT);
        String estilo = resaltado ? "-fx-font-weight: bold; -fx-font-size: 13px; -fx-text-fill: " + COLOR + ";" : "";
        k.setStyle(estilo);
        v.setStyle(estilo);
        HBox h = new HBox(20, k, v);
        h.setAlignment(Pos.CENTER_RIGHT);
        return h;
    }

    private static VBox firma(String texto) {
        Region linea = new Region();
        linea.setPrefSize(180, 1);
        linea.setMaxHeight(1);
        linea.setStyle("-fx-background-color: black;");
        VBox v = new VBox(4, linea, new Label(texto));
        v.setAlignment(Pos.CENTER);
        return v;
    }

    private static VBox pie(String mensaje) {
        VBox v = new VBox(2);
        v.setAlignment(Pos.CENTER);
        v.setPadding(new Insets(16, 0, 0, 0));
        if (mensaje != null) v.getChildren().add(texto(mensaje, true));
        String usuario = SessionManager.getInstance().getUserName();
        Label l = new Label("Emitido por: " + txt(usuario) + "  ·  Impreso el " + LocalDate.now().format(FMT_FECHA)
                + "  ·  SysTransporte");
        l.setStyle("-fx-font-size: 9px; -fx-text-fill: #666666;");
        v.getChildren().add(l);
        return v;
    }

    private static Label texto(String t, boolean negrita) {
        Label l = new Label(t);
        l.setWrapText(true);
        if (negrita) l.setStyle("-fx-font-weight: bold;");
        return l;
    }

    // =====================================================================
    //  FORMATO
    // =====================================================================
    private static String txt(String s) {
        return s == null || s.isBlank() ? "-" : s;
    }

    private static String fecha(LocalDate f) {
        return f == null ? "-" : f.format(FMT_FECHA);
    }

    private static String dinero(Double v) {
        return v == null ? "-" : String.format(Locale.US, "S/ %,.2f", v);
    }

    private static String numero(Double v) {
        return v == null ? "-" : String.format(Locale.US, "%.2f", v);
    }

    private static String persona(Persona p) {
        if (p == null) return "-";
        return txt(p.getNombre()) + (p.getDni() == null ? "" : "  (DNI " + p.getDni() + ")");
    }

    private static Image cargarLogo() {
        try (InputStream in = ImpresionHelper.class.getResourceAsStream("/img/logo.png")) {
            return in == null ? null : new Image(in);
        } catch (Exception ex) {
            return null;
        }
    }

    private static void alerta(Window owner, String mensaje) {
        Alert a = new Alert(Alert.AlertType.WARNING, mensaje);
        a.setHeaderText(null);
        a.setTitle("Impresión");
        if (owner != null) a.initOwner(owner);
        a.showAndWait();
    }
}
