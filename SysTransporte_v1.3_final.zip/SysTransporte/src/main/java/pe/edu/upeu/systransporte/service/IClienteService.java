package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Cliente;

import java.util.List;

public interface IClienteService extends ICrudGenericoService<Cliente, String> {
    List<ComboBoxOption> listarCombobox();
}
