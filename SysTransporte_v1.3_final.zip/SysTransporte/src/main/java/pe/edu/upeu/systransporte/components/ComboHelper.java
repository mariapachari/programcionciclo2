package pe.edu.upeu.systransporte.components;

import javafx.scene.control.ComboBox;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;

import java.util.ArrayList;
import java.util.List;

/**
 * Utilidades para llenar y seleccionar ComboBox con {@link ComboBoxOption}.
 */
public final class ComboHelper {

    private ComboHelper() {
    }

    /** Convierte los valores de un enum en opciones (key = name(), value = descripción). */
    public static <E extends Enum<E>> List<ComboBoxOption> desdeEnum(Class<E> tipo) {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (E valor : tipo.getEnumConstants()) {
            lista.add(new ComboBoxOption(valor.name(), valor.toString()));
        }
        return lista;
    }

    /** Selecciona en el combo la opción cuyo key coincide (o limpia si no hay). */
    public static void seleccionar(ComboBox<ComboBoxOption> combo, Object key) {
        if (key == null) {
            combo.getSelectionModel().clearSelection();
            return;
        }
        String k = key instanceof Enum<?> e ? e.name() : String.valueOf(key);
        combo.getItems().stream()
                .filter(op -> op.getKey().equals(k))
                .findFirst()
                .ifPresentOrElse(op -> combo.getSelectionModel().select(op),
                        () -> combo.getSelectionModel().clearSelection());
    }

    /** Devuelve el key seleccionado o null. */
    public static String keySeleccionado(ComboBox<ComboBoxOption> combo) {
        ComboBoxOption op = combo.getSelectionModel().getSelectedItem();
        return op == null ? null : op.getKey();
    }
}
