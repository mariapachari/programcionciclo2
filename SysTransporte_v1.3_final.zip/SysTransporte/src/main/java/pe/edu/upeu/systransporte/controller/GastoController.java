package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Gasto;
import pe.edu.upeu.systransporte.service.IGastoService;
import pe.edu.upeu.systransporte.service.IViajeService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_gasto.fxml — Gastos de Viaje.
 */
@RequiredArgsConstructor
public class GastoController {
    private final IGastoService gastoService;
    private final IViajeService viajeService;

    @FXML
    TextField txtConcepto, txtMonto, txtFiltroDato;
    @FXML
    DatePicker dpFecha;
    @FXML
    ComboBox<ComboBoxOption> cbxIdViaje;

    @FXML
    private TableView<Gasto> tableView;
    private PaginadorTabla<Gasto> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Gasto> listaGasto = FXCollections.observableArrayList();
    Gasto formulario;
    String idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxIdViaje.getItems().addAll(viajeService.listarCombobox());
        new ComboBoxAutoComplete<>(cbxIdViaje);
        dpFecha.setValue(LocalDate.now());

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Gasto> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idGasto", 80.0));
        columns.put("Viaje", new ColumnInfo("idViaje.idViaje", 100.0));
        columns.put("Concepto", new ColumnInfo("concepto", 200.0));
        columns.put("Monto (S/)", new ColumnInfo("monto", 90.0));
        columns.put("Fecha", new ColumnInfo("fecha", 100.0));

        Consumer<Gasto> updateAction = this::editForm;
        Consumer<Gasto> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaGasto = FXCollections.observableArrayList(gastoService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaGasto
                : listaGasto.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Gasto();
        String kIdViaje = ComboHelper.keySeleccionado(cbxIdViaje);
        formulario.setIdViaje(kIdViaje == null ? null : viajeService.findById(kIdViaje));
        formulario.setConcepto(txtConcepto.getText() == null ? null : txtConcepto.getText().trim());
        formulario.setMonto(parseDoubleSafe(txtMonto.getText()));
        formulario.setFecha(dpFecha.getValue());

        Set<ConstraintViolation<Gasto>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Gasto>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        cbxIdViaje.getSelectionModel().clearSelection();
        txtConcepto.clear();
        txtMonto.clear();
        dpFecha.setValue(LocalDate.now());
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Gasto x) {
        ComboHelper.seleccionar(cbxIdViaje, x.getIdViaje() == null ? null : x.getIdViaje().getIdViaje());
        txtConcepto.setText(x.getConcepto());
        txtMonto.setText(x.getMonto() == null ? "" : String.valueOf(x.getMonto()));
        dpFecha.setValue(x.getFecha());
        idCE = x.getIdGasto();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Gasto x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdGasto() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            gastoService.delete(x.getIdGasto());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Gasto>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("idViaje", cbxIdViaje);
        campos.put("concepto", txtConcepto);
        campos.put("monto", txtMonto);
        campos.put("fecha", dpFecha);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdGasto(idCE);
                gastoService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                gastoService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(cbxIdViaje, txtConcepto, txtMonto, dpFecha)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
