package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Encomienda;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.EncomiendaRepository;
import pe.edu.upeu.systransporte.service.IEncomiendaService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class EncomiendaServiceImp extends CrudGenericoServiceImp<Encomienda, Long> implements IEncomiendaService {

    private final EncomiendaRepository repo;

    @Override
    protected ICrudGenericoRepository<Encomienda, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Encomienda x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdEncomienda()), "#" + x.getIdEncomienda() + " - " + x.getDescripcionCarga() + " (" + x.getLugarOrigen() + " → " + x.getLugarDestino() + ")"));
        }
        return listar;
    }

    // ===== MEJORA: reglas de negocio de la encomienda =====
    private void validarReglas(Encomienda e) {
        if (e.getIdRemitente().getIdPersona().equals(e.getIdDestinatario().getIdPersona())) {
            throw new IllegalArgumentException("El remitente y el destinatario no pueden ser la misma persona");
        }
        if (e.getLugarOrigen().equalsIgnoreCase(e.getLugarDestino())) {
            throw new IllegalArgumentException("El lugar de origen y destino no pueden ser iguales");
        }
    }

    @Override
    public Encomienda save(Encomienda e) {
        validarReglas(e);
        return super.save(e);
    }

    @Override
    public Encomienda update(Long id, Encomienda e) {
        validarReglas(e);
        return super.update(id, e);
    }
}
