package pe.edu.upeu.systransporte.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.components.*;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.Vehiculo;
import pe.edu.upeu.systransporte.service.IVehiculoService;

import java.util.*;
import java.util.function.Consumer;

/**
 * Controlador de la vista main_vehiculo.fxml — Gestionar Vehículos.
 */
@RequiredArgsConstructor
public class VehiculoController {
    private final IVehiculoService vehiculoService;

    @FXML
    TextField txtPlaca, txtMarca, txtCapacidadTon, txtFiltroDato;
    @FXML
    ComboBox<ComboBoxOption> cbxTipoVehiculo, cbxEstado;

    @FXML
    private TableView<Vehiculo> tableView;
    private PaginadorTabla<Vehiculo> paginador;   // paginación de la tabla

    @FXML
    Label lbnMsg;
    @FXML
    private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Vehiculo> listaVehiculo = FXCollections.observableArrayList();
    Vehiculo formulario;
    String idCE = null;   // id del registro en edición (null = nuevo)

    private final ToltipCustom ttc = new ToltipCustom();

    @FXML
    public void initialize() {
        idCE = null;
        cbxTipoVehiculo.getItems().addAll(ComboHelper.desdeEnum(TipoVehiculo.class));
        cbxEstado.getItems().addAll(ComboHelper.desdeEnum(EstadoVehiculo.class));

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Vehiculo> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Código", new ColumnInfo("idVehiculo", 80.0));
        columns.put("Placa", new ColumnInfo("placa", 100.0));
        columns.put("Marca", new ColumnInfo("marca", 130.0));
        columns.put("Tipo", new ColumnInfo("tipoVehiculo", 110.0));
        columns.put("Capacidad (t)", new ColumnInfo("capacidadTon", 110.0));
        columns.put("Estado", new ColumnInfo("estado", 120.0));

        Consumer<Vehiculo> updateAction = this::editForm;
        Consumer<Vehiculo> deleteAction = this::eliminar;

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        paginador = new PaginadorTabla<>(tableView);
        tableView.setTableMenuButtonVisible(true);
        txtFiltroDato.textProperty().addListener((obs, anterior, nuevo) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            listaVehiculo = FXCollections.observableArrayList(vehiculoService.findAll());
            filtrar();
        } catch (Exception e) {
            lbnMsg.setText("Error al listar: " + e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545;");
        }
    }

    @FXML
    public void filtrar() {
        String texto = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        paginador.setDatos(texto.isEmpty() ? listaVehiculo
                : listaVehiculo.filtered(x -> x.toString().toLowerCase().contains(texto)));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Vehiculo();
        formulario.setPlaca(txtPlaca.getText() == null ? null : txtPlaca.getText().trim().toUpperCase()); // MEJORA: placa siempre en mayúsculas
        formulario.setMarca(txtMarca.getText() == null ? null : txtMarca.getText().trim());
        String kTipoVehiculo = ComboHelper.keySeleccionado(cbxTipoVehiculo);
        formulario.setTipoVehiculo(kTipoVehiculo == null ? null : TipoVehiculo.valueOf(kTipoVehiculo));
        formulario.setCapacidadTon(parseDoubleSafe(txtCapacidadTon.getText()));
        String kEstado = ComboHelper.keySeleccionado(cbxEstado);
        formulario.setEstado(kEstado == null ? null : EstadoVehiculo.valueOf(kEstado));

        Set<ConstraintViolation<Vehiculo>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Vehiculo>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private Double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Double.parseDouble(value.trim().replace(",", ".")); }
        catch (NumberFormatException e) { return null; }
    }

    @FXML
    public void clearForm() {
        txtPlaca.clear();
        txtMarca.clear();
        cbxTipoVehiculo.getSelectionModel().clearSelection();
        txtCapacidadTon.clear();
        cbxEstado.getSelectionModel().clearSelection();
        idCE = null;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(Vehiculo x) {
        txtPlaca.setText(x.getPlaca());
        txtMarca.setText(x.getMarca());
        ComboHelper.seleccionar(cbxTipoVehiculo, x.getTipoVehiculo());
        txtCapacidadTon.setText(x.getCapacidadTon() == null ? "" : String.valueOf(x.getCapacidadTon()));
        ComboHelper.seleccionar(cbxEstado, x.getEstado());
        idCE = x.getIdVehiculo();
        limpiarError();
        lbnMsg.setText("Editando registro: " + idCE);
        lbnMsg.setStyle("-fx-text-fill: #0d6efd; -fx-font-size: 13px;");
    }

    private void eliminar(Vehiculo x) {
        stage = (Stage) miContenedor.getScene().getWindow();
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Desea eliminar el registro " + x.getIdVehiculo() + "?", ButtonType.YES, ButtonType.NO);
        alerta.setHeaderText(null);
        alerta.setTitle("Confirmar eliminación");
        alerta.initOwner(stage);
        if (alerta.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;

        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            vehiculoService.delete(x.getIdVehiculo());
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            Toast.showToast(stage, "No se puede eliminar: el registro se usa en otra tabla", 3000, w, h);
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Vehiculo>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("placa", txtPlaca);
        campos.put("marca", txtMarca);
        campos.put("tipoVehiculo", cbxTipoVehiculo);
        campos.put("capacidadTon", txtCapacidadTon);
        campos.put("estado", cbxEstado);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (erroresOrdenados.isEmpty() && !violaciones.isEmpty()) {
            erroresOrdenados.put("general", violaciones.get(0).getMessage());
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.values().iterator().next());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        limpiarError();
        try {
            if (idCE != null) {
                formulario.setIdVehiculo(idCE);
                vehiculoService.update(idCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                vehiculoService.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Operación realizada con éxito");
            lbnMsg.setStyle("-fx-text-fill: #198754; -fx-font-size: 13px;");
        } catch (RuntimeException ex) {
            lbnMsg.setText(ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #dc3545; -fx-font-size: 13px;");
        }
    }

    public void limpiarError() {
        List.<Control>of(txtPlaca, txtMarca, cbxTipoVehiculo, txtCapacidadTon, cbxEstado)
                .forEach(c -> {
                    c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }
}
