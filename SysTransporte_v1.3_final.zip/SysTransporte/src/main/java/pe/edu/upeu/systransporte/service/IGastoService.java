package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Gasto;

import java.util.List;

public interface IGastoService extends ICrudGenericoService<Gasto, String> {
    List<ComboBoxOption> listarCombobox();
}
