module pe.edu.upeu.systransporte {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires static lombok;
    requires jakarta.validation;

    requires java.sql;
    requires java.naming;
    requires org.slf4j;
    requires com.zaxxer.hikari;
    requires java.prefs;
    requires java.desktop;

    opens pe.edu.upeu.systransporte to javafx.fxml;
    opens pe.edu.upeu.systransporte.controller to javafx.fxml;
    opens pe.edu.upeu.systransporte.model;
    exports pe.edu.upeu.systransporte;
}
