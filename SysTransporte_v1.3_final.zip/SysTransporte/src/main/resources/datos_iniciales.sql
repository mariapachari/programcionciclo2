-- ============================================================
-- DATOS INICIALES: se ejecutan SOLO si la tabla usuarios está vacía (primera vez).
-- Las claves '123456' se encriptan automáticamente al arrancar (PasswordEncoder).
-- ============================================================
MERGE INTO usuarios (idUsuario, usuario, clave, rol, estado) KEY (idUsuario) VALUES
    ('USU0001', 'admin',    '123456', 'ADMINISTRADOR', 'ACTIVO'),
    ('USU0002', 'operador', '123456', 'OPERADOR',      'ACTIVO'),
    ('USU0003', 'conductor','123456', 'CONDUCTOR',     'ACTIVO');

MERGE INTO clientes (idCliente, razonSocial, ruc, telefono, correo) KEY (idCliente) VALUES
    ('CLI0001', 'Agroexportadora Los Andes S.A.C.', '20512345671', '014567890', 'ventas@losandes.pe'),
    ('CLI0002', 'Distribuidora Juliaca E.I.R.L.',   '20498765432', '051321456', 'contacto@djuliaca.pe'),
    ('CLI0003', 'Ferretería El Constructor S.A.',   '20123456789', '054223344', 'compras@elconstructor.pe'),
    ('CLI0004', 'Transportes Altiplano S.A.C.', '20601234561', '051367890', 'logistica@altiplano.pe'),
    ('CLI0005', 'Minera Santa Rosa S.A.', '20478912345', '054281122', 'compras@santarosa.pe'),
    ('CLI0006', 'Textil Alpaca Andina S.A.C.', '20556677889', '051332211', 'ventas@alpacaandina.pe'),
    ('CLI0007', 'Comercial Titicaca E.I.R.L.', '20445566771', '051354477', 'comercial@titicaca.pe'),
    ('CLI0008', 'Importaciones Sur Perú S.A.C.', '20587654329', '054205566', 'importa@surperu.pe'),
    ('CLI0009', 'Agrícola Valle Majes S.A.', '20412398765', '054587744', 'info@vallemajes.pe'),
    ('CLI0010', 'Lácteos Puno S.A.C.', '20532165498', '051368899', 'pedidos@lacteospuno.pe'),
    ('CLI0011', 'Materiales del Sur S.R.L.', '20498712365', '054233366', 'ventas@matsur.pe'),
    ('CLI0012', 'Farmacias Unidas S.A.', '20565432178', '014445566', 'compras@farmaunidas.pe');

MERGE INTO conductores (idConductor, nombre, licencia, telefono, categoriaLicencia, estado) KEY (idConductor) VALUES
    ('CON0001', 'Carlos Mamani Quispe', 'Q45879632', '987111222', 'A_IIIC', 'ACTIVO'),
    ('CON0002', 'Luis Condori Apaza',   'Q41235698', '987333444', 'A_IIIB', 'ACTIVO'),
    ('CON0003', 'Jorge Flores Ramos',   'Q40011223', '987555666', 'A_IIB',  'INACTIVO');

MERGE INTO vehiculos (idVehiculo, placa, marca, capacidadTon, estado, tipoVehiculo) KEY (idVehiculo) VALUES
    ('VEH0001', 'V1A-852', 'Volvo FH',          30.00, 'EN_RUTA',       'TRAILER'),
    ('VEH0002', 'Z2B-147', 'Hino 500',          12.00, 'DISPONIBLE',    'CAMION'),
    ('VEH0003', 'X3C-369', 'Mercedes Sprinter',  3.50, 'MANTENIMIENTO', 'FURGON');

INSERT INTO persona (nombre, dni, celular, direccion)
    SELECT 'Ana Torres Huanca', '45879632', '951234567', 'Jr. Lima 123 - Juliaca'
    WHERE NOT EXISTS (SELECT 1 FROM persona WHERE dni = '45879632');
INSERT INTO persona (nombre, dni, celular, direccion)
    SELECT 'Pedro Quispe Mamani', '41236589', '962345678', 'Av. Arequipa 456 - Lima'
    WHERE NOT EXISTS (SELECT 1 FROM persona WHERE dni = '41236589');
INSERT INTO persona (nombre, dni, celular, direccion)
    SELECT 'María Chura Ccama', '70125896', '973456789', 'Calle Mercaderes 89 - Arequipa'
    WHERE NOT EXISTS (SELECT 1 FROM persona WHERE dni = '70125896');

MERGE INTO viajes (idViaje, origen, destino, tipoCarga, fechaSalida, fechaLlegada, idConductor, idVehiculo, estado, costoFlete) KEY (idViaje) VALUES
    ('VIA0001', 'Lima',     'Juliaca',  'Carga general', DATE '2026-11-10', NULL,              'CON0001', 'VEH0001', 'EN_CURSO',   4500.00),
    ('VIA0002', 'Arequipa', 'Puno',     'Materiales',    DATE '2026-11-05', DATE '2026-11-06', 'CON0002', 'VEH0002', 'FINALIZADO', 1800.00);

INSERT INTO encomienda (idCliente, id_remitente, id_destinatario, lugar_origen, lugar_destino, descripcionCarga, pesoTon, estado, fechaRegistro)
    SELECT 'CLI0001',
           (SELECT id_persona FROM persona WHERE dni = '41236589'),
           (SELECT id_persona FROM persona WHERE dni = '45879632'),
           'Lima', 'Juliaca', 'Cajas de frutas para exportación', 8.50, 'EN_TRANSITO', DATE '2026-11-09'
    WHERE NOT EXISTS (SELECT 1 FROM encomienda WHERE descripcionCarga = 'Cajas de frutas para exportación');
INSERT INTO encomienda (idCliente, id_remitente, id_destinatario, lugar_origen, lugar_destino, descripcionCarga, pesoTon, estado, fechaRegistro)
    SELECT 'CLI0003',
           (SELECT id_persona FROM persona WHERE dni = '70125896'),
           (SELECT id_persona FROM persona WHERE dni = '45879632'),
           'Arequipa', 'Puno', 'Bolsas de cemento y fierro', 10.00, 'ENTREGADO', DATE '2026-11-04'
    WHERE NOT EXISTS (SELECT 1 FROM encomienda WHERE descripcionCarga = 'Bolsas de cemento y fierro');
INSERT INTO encomienda (idCliente, id_remitente, id_destinatario, lugar_origen, lugar_destino, descripcionCarga, pesoTon, estado, fechaRegistro)
    SELECT 'CLI0002',
           (SELECT id_persona FROM persona WHERE dni = '45879632'),
           (SELECT id_persona FROM persona WHERE dni = '41236589'),
           'Juliaca', 'Lima', 'Fardos de fibra de alpaca', 2.25, 'REGISTRADO', DATE '2026-11-12'
    WHERE NOT EXISTS (SELECT 1 FROM encomienda WHERE descripcionCarga = 'Fardos de fibra de alpaca');

MERGE INTO manifiesto (idGuia, numeroGuia, idViaje, fechaEmision, estado) KEY (idGuia) VALUES
    ('GUI0001', 'T001-000001', 'VIA0001', DATE '2026-11-10', 'EMITIDO');

MERGE INTO gastos (idGasto, idViaje, concepto, monto, fecha) KEY (idGasto) VALUES
    ('GAS0001', 'VIA0001', 'Combustible (petróleo)', 1200.00, DATE '2026-11-10'),
    ('GAS0002', 'VIA0001', 'Peajes Lima - Juliaca',   185.50, DATE '2026-11-11');
