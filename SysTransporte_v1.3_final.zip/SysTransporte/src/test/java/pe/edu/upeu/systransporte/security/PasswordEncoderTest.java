package pe.edu.upeu.systransporte.security;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PasswordEncoderTest {

    @Test
    void laClaveSeGuardaEncriptadaYNoEnTextoPlano() {
        String hash = PasswordEncoder.encriptar("123456");
        assertTrue(hash.startsWith("pbkdf2$"));
        assertFalse(hash.contains("123456"));
        assertTrue(PasswordEncoder.estaEncriptada(hash));
    }

    @Test
    void verificaClaveCorrectaEIncorrecta() {
        String hash = PasswordEncoder.encriptar("secreta1");
        assertTrue(PasswordEncoder.verificar("secreta1", hash));
        assertFalse(PasswordEncoder.verificar("Secreta1", hash));
        assertFalse(PasswordEncoder.verificar(null, hash));
    }

    @Test
    void mismaClaveGeneraHashesDistintosPorLaSal() {
        assertNotEquals(PasswordEncoder.encriptar("123456"), PasswordEncoder.encriptar("123456"));
    }
}
