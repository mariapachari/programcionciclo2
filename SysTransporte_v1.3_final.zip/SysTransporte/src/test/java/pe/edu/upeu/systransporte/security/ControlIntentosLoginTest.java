package pe.edu.upeu.systransporte.security;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ControlIntentosLoginTest {

    @Test
    void seBloqueaAlTercerIntentoFallido() {
        ControlIntentosLogin c = new ControlIntentosLogin();
        assertEquals(2, c.registrarFallo("admin"));
        assertEquals(1, c.registrarFallo("admin"));
        assertEquals(0, c.registrarFallo("admin"));
        assertTrue(c.segundosBloqueo("admin") > 0);
        assertEquals(0, c.segundosBloqueo("operador"));
    }

    @Test
    void unLoginCorrectoReiniciaLosIntentos() {
        ControlIntentosLogin c = new ControlIntentosLogin();
        c.registrarFallo("admin");
        c.registrarFallo("admin");
        c.registrarExito("admin");
        assertEquals(2, c.registrarFallo("admin"));
    }
}
