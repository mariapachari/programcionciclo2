# Manual de SysTransporte — Sistema de Transporte de Carga (JavaFX + H2)

> Proyecto hecho con **la misma estructura de SysVentas** (proyecto del profesor):
> **Model → Repository → Service → Controller → View (FXML)**, con inyección de dependencias manual (`AppContext`),
> base de datos **H2 + HikariCP** y validación con **Jakarta Validation**.
> La base de datos sale del modelo **`transporte_carga_poo.architect`** (14 tablas).

---

## Índice

1. [Cómo ejecutar](#1-cómo-ejecutar)
2. [Qué se mejoró (versión 1.1 → 1.2)](#2-qué-se-mejoró)
3. [Cómo funciona: la arquitectura en capas](#3-cómo-funciona-la-arquitectura-en-capas)
4. [Cómo se conecta a la base de datos](#4-cómo-se-conecta-a-la-base-de-datos)
5. [Recorrido: qué pasa al hacer clic en "Guardar"](#5-recorrido-qué-pasa-al-hacer-clic-en-guardar)
6. [Login, roles y menús](#6-login-roles-y-menús)
7. [Reglas de negocio](#7-reglas-de-negocio)
8. [Ejemplos para enseñar en clase (demo paso a paso)](#8-ejemplos-para-enseñar-en-clase)
9. [Preguntas que puede hacer el profesor (con respuesta)](#9-preguntas-que-puede-hacer-el-profesor)

---

## 1. Cómo ejecutar

1. Abrir la carpeta `SysTransporte` en IntelliJ IDEA (proyecto Maven).
2. Esperar a que Maven descargue las dependencias.
3. Ejecutar `pe.edu.upeu.systransporte.App` o en terminal: `mvn clean javafx:run`.

| Usuario  | Clave  | Rol           | Qué ve                                    |
|----------|--------|---------------|-------------------------------------------|
| admin    | 123456 | ADMINISTRADOR | Todos los módulos                          |
| operador | 123456 | OPERADOR      | Clientes, Personas, Encomiendas, Paquetes, Seguimiento, Entregas, Comprobantes |

Al arrancar, `DatabaseConfig` crea `~/SysTransporte/data/systransporte.mv.db`, ejecuta `schema_transporte.sql`
(crea las 14 tablas si no existen) y, solo la primera vez, `datos_iniciales.sql`. Para empezar de cero:
cerrar la app y borrar la carpeta `%USERPROFILE%\SysTransporte\data`.

---

## 2. Qué se mejoró

Las mejoras son **pequeñas y siguen el mismo patrón del profe** (no se cambió la estructura de paquetes ni de clases).

| # | Mejora | Dónde está | Por qué |
|---|--------|-----------|---------|
| 1 | **No permite duplicados**: DNI de persona, RUC de cliente, placa de vehículo y nombre de usuario. | `AbstractJpaRepository.existeDuplicado(...)` + `PersonaServiceImp`, `ClienteServiceImp`, `VehiculoServiceImp`, `UsuarioServiceImp` | Antes se podían registrar dos personas con el mismo DNI. |
| 2 | **Encomienda**: el remitente y el destinatario no pueden ser la misma persona; origen y destino no pueden ser iguales. | `EncomiendaServiceImp.validarReglas()` | Datos sin sentido de negocio. |
| 3 | **Viaje**: no se puede asignar un conductor INACTIVO ni un vehículo en MANTENIMIENTO. | `ViajeServiceImp.validarDisponibilidad()` | Regla real de una empresa de transporte. |
| 4 | **Paquetes**: la suma de pesos de los paquetes no puede superar el peso de la encomienda. | `PaqueteServiceImp.validarPeso()` + `PaqueteRepository.pesoPaquetesDeEncomienda()` | Mismo estilo que la regla de capacidad del manifiesto. |
| 5 | **Pantalla de Inicio con resumen** leído de la BD: clientes, encomiendas, por entregar, viajes en curso, vehículos disponibles + botón *Actualizar resumen*. | `InicioController`, `main_inicio.fxml`, registro en `AppContext` | Muestra que el sistema está conectado a la base de datos. |
| 6 | **Placa en mayúsculas automáticamente** (`abc-123` → `ABC-123`). | `VehiculoController.validarFormulario()` | Evita errores de validación por escribir en minúsculas. |
| 7 | La bienvenida muestra también el **rol** del usuario. | `InicioController` | Se ve claramente qué perfil inició sesión. |

Todas las reglas nuevas lanzan `IllegalArgumentException` en la capa **Service**; el controlador ya la atrapa
(`catch (RuntimeException ex)`) y muestra el mensaje en rojo en `lbnMsg`. Por eso no se tocaron las vistas de los CRUD.

---

## Novedades v1.3 (proyecto final)

| # | Mejora | Dónde está | Por qué |
|---|--------|-----------|---------|
| 1 | **Claves encriptadas** con PBKDF2-HMAC-SHA256 + sal aleatoria. El login compara hashes; al editar un usuario, la clave vacía conserva la anterior; las claves en texto plano se migran solas. | `security/PasswordEncoder`, `UsuarioServiceImp`, `UsuarioRepository.findByUsuario`, `SysTransporte.start` | Nunca guardar contraseñas legibles. |
| 2 | **Bloqueo por 3 intentos fallidos** (30 s) y mensajes «le quedan N intentos». Validación de campos vacíos en el login. | `security/ControlIntentosLogin`, `LoginController` | Evitar ataques de fuerza bruta. |
| 3 | **Paginación** (5/10/20/50 filas) en las 14 tablas, sin tocar los FXML. | `components/PaginadorTabla` + 2 líneas en cada controlador | Tablas grandes legibles y rápidas. |
| 4 | **Rol CONDUCTOR** (Seguimiento, Entregas, Gastos). | `enums/Rol`, `MenuMenuItemDaoImp` | Funcionalidades según perfil. |
| 5 | **BD en la carpeta del usuario** y datos de prueba solo la 1ra vez (antes el `MERGE` revertía los cambios en cada arranque). | `DatabaseConfig`, `datos_iniciales.sql` | Funciona instalado en «Archivos de programa». |
| 6 | **Empaquetado**: fat jar (maven-shade), `SysTransporte.exe` (jpackage), instalador (Inno Setup), GitHub Actions. | `pom.xml`, `instalador/`, `.github/workflows/` | Instalar en cualquier Windows sin Java. |
| 7 | **Pruebas unitarias** JUnit 5. | `src/test/java/.../security` | `mvnw test` |
| 8 | Validaciones más estrictas en Usuario: usuario 3–150 caracteres sin espacios, clave mínimo 6. | `model/Usuario` | |

---

## 3. Cómo funciona: la arquitectura en capas

```
VIEW (FXML)        main_encomienda.fxml     ← lo que ve el usuario
      │ fx:controller
CONTROLLER         EncomiendaController     ← lee el formulario, valida, llama al servicio
      │ usa la interfaz IEncomiendaService
SERVICE            EncomiendaServiceImp     ← reglas de negocio
      │ usa
REPOSITORY         EncomiendaRepository     ← SQL (JDBC puro)
      │ hereda de AbstractJpaRepository → SqlHelper
DATABASE           H2 (~/SysTransporte/data/systransporte.mv.db) vía HikariCP
```

| Paquete | Qué contiene | Ejemplo |
|---------|-------------|---------|
| `model` | Una clase por tabla, con Lombok (`@Data @Builder`) y validaciones (`@NotBlank`, `@Pattern`...) | `Encomienda` tiene `Cliente idCliente`, `Persona idRemitente` (objetos, no solo ids) |
| `repository` | SQL de cada tabla. `SqlHelper` tiene los métodos JDBC; `AbstractJpaRepository` el CRUD genérico | `EncomiendaRepository` hace `JOIN` con clientes y persona |
| `service` | Interfaz + implementación. `CrudGenericoServiceImp` da save/update/delete/findAll | `MovimientoServiceImp` cambia el estado de la encomienda |
| `controller` | Un controlador JavaFX por pantalla | `ViajeController` |
| `config` | `AppContext` (crea y conecta todos los objetos) y `DatabaseConfig` (conexión) | |
| `components` | Ayudas de interfaz reutilizables | `TableViewHelper` (columnas + botones editar/eliminar), `Toast`, `ComboHelper` |
| `enums` | Valores fijos de estados y tipos | `EstadoEncomienda`, `TipoVehiculo`, `Rol` |

**Herencia genérica (lo más importante de POO del proyecto):**

```java
public abstract class AbstractJpaRepository<T, ID> extends SqlHelper<T>
        implements ICrudGenericoRepository<T, ID> { ... }

public class ClienteRepository extends AbstractJpaRepository<Cliente, String> { ... } // PK VARCHAR
public class PersonaRepository extends AbstractJpaRepository<Persona, Long>   { ... } // PK INTEGER
```
Cada repositorio solo implementa lo que cambia (`getTableName`, `getPkColumn`, `mapRow`, `insert`, `updateRow`);
`findAll`, `findById`, `deleteById`, `existsById` y ahora `existeDuplicado` se heredan.

---

## 4. Cómo se conecta a la base de datos

1. `application.properties` define la URL:
   ```properties
   db.url=jdbc:h2:file:~/SysTransporte/data/systransporte
   db.ddl.auto=true
   db.ddl.script=schema_transporte.sql
   ```
2. `DatabaseConfig.init()` crea un **pool HikariCP** (máx. 5 conexiones) y ejecuta el script SQL sentencia por sentencia.
3. El script usa `CREATE TABLE IF NOT EXISTS` y `MERGE INTO ... KEY` → se puede ejecutar en cada arranque sin duplicar datos (**idempotente**).
4. Cada repositorio pide una conexión con `openConnection()` → `DatabaseConfig.getConnection()`, la usa en un `try-with-resources` y la devuelve al pool.
5. `save()` y `update()` usan **transacción**: `setAutoCommit(false)` → `commit()`; si falla, `rollback()`.

Diferencias con el modelo `.architect`: se agregó la columna `clave` a `usuarios` (para el login).
Las PK VARCHAR (`CLI0001`, `VIA0001`...) se generan con `generarCodigo()`; las INTEGER son `IDENTITY` (autoincremento).

---

## 5. Recorrido: qué pasa al hacer clic en "Guardar"

Ejemplo con **Persona**:

1. `main_persona.fxml` → botón `onAction="#validarFormulario"`.
2. `PersonaController.validarFormulario()` arma un objeto `Persona` con los TextField.
3. `validator.validate(formulario)` revisa las anotaciones del modelo (`@Pattern(regexp="\\d{8}")` para el DNI).
   Si hay errores → `mostrarErroresValidacion()` pinta el campo en rojo con tooltip.
4. Si es válido → `procesarFormulario()` → `personaService.save(formulario)` (o `update` si se está editando).
5. `PersonaServiceImp.save()` → **`validarDuplicado()`** (mejora) → `super.save()`.
6. `AbstractJpaRepository.save()` abre conexión + transacción → `PersonaRepository.insert()` →
   `executeInsertGetKey("INSERT INTO persona ...")` → la BD devuelve el id generado → `commit()`.
7. El controlador muestra el `Toast` "Se guardó correctamente!!", limpia el formulario y vuelve a `listar()`.

---

## 6. Login, roles y menús

- `LoginController.login()` → `usuarioService.loginUsuario(usuario, clave)` → `SELECT ... WHERE usuario=? AND clave=?`.
- Si el usuario está **INACTIVO** no entra.
- Se guardan los datos en `SessionManager` (Singleton): id, usuario y rol.
- `MainGuiController` dibuja los menús con `MenuMenuItemDaoImp.listaAccesos(rol)`:
  ADMINISTRADOR ve todo, OPERADOR solo una lista de opciones (`Set OPERADOR`).
- Cada opción abre su FXML en una pestaña; el `FXMLLoader` usa `setControllerFactory(appContext::getBean)` para que
  el controlador ya venga con sus servicios inyectados.
- `MovimientoController` toma el usuario de `SessionManager` para registrar **quién** hizo el movimiento.

---

## 7. Reglas de negocio

| Módulo | Regla | Clase |
|--------|-------|-------|
| Persona / Cliente / Vehículo / Usuario | DNI, RUC, placa y usuario únicos | `*ServiceImp.validarDuplicado()` |
| Encomienda | Remitente ≠ destinatario; origen ≠ destino | `EncomiendaServiceImp` |
| Paquete | Suma de pesos ≤ peso de la encomienda | `PaqueteServiceImp` |
| Viaje | Llegada ≥ salida; conductor ACTIVO; vehículo no en MANTENIMIENTO | `ViajeServiceImp` |
| Detalle manifiesto | Peso asignado ≤ capacidad del vehículo del viaje | `DetalleManifiestoServiceImp` |
| Movimiento | La encomienda toma el estado del movimiento | `MovimientoServiceImp` |
| Entrega | Si se entrega, la encomienda pasa a ENTREGADO | `EntregaServiceImp` |
| Comprobante | Número automático B001-000001 / F001-000001 | `ComprobanteRepository` |
| Eliminar | Pide confirmación; si el registro está en uso (FK) avisa y no borra | Todos los controladores |

---

## 8. Ejemplos para enseñar en clase

Demo recomendada (≈10 min). Entrar como **admin / 123456**.

### Ejemplo 1 — La pantalla de Inicio lee la BD
1. Ver las tarjetas: 3 clientes, 3 encomiendas, 2 por entregar, 1 viaje en curso, 1 vehículo disponible.
2. Registrar un cliente nuevo, volver a *Inicio* y pulsar **Actualizar resumen** → sube a 4.
   *Explicar:* `InicioController` → `clienteService.findAll()` → `SELECT` en H2.

### Ejemplo 2 — Validación del modelo (Jakarta Validation)
1. *Registros › Personas* → DNI `123` → Guardar.
2. Sale "El DNI debe tener 8 dígitos" y el campo se pone rojo.
   *Explicar:* viene de `@Pattern(regexp = "\\d{8}")` en `Persona.java`; no se escribió ningún `if`.

### Ejemplo 3 — Regla de negocio: duplicados (mejora)
1. Registrar persona: `Juan Pérez`, DNI `45879632` (ya existe: Ana Torres).
2. Mensaje: "Ya existe una persona con el DNI 45879632".
   *Explicar:* la validación del modelo pasa (8 dígitos), pero el **Service** consulta la BD con `existeDuplicado`.

### Ejemplo 4 — Encomienda con relaciones (FK)
1. *Encomiendas › Registrar encomienda*: Cliente *Agroexportadora Los Andes*, Remitente *Pedro Quispe*,
   Destinatario *Pedro Quispe* → Guardar → error "El remitente y el destinatario no pueden ser la misma persona".
2. Cambiar destinatario a *María Chura*, origen `Lima`, destino `Arequipa`, carga `Cajas de café`, peso `5`, estado *Registrado* → se guarda.
3. En la tabla se ven los **nombres** (no ids): el repositorio hace `JOIN clientes` y `JOIN persona` dos veces (alias `pr` y `pd`).

### Ejemplo 5 — Paquetes no superan el peso (mejora)
1. *Encomiendas › Paquetes*: elegir la encomienda de café (5 t), paquete de `3` t → OK.
2. Otro paquete de `3` t → error "Peso excedido: la encomienda pesa 5.00 t y sus paquetes ya suman 3.00 t".

### Ejemplo 6 — Seguimiento cambia el estado
1. *Encomiendas › Seguimiento*: elegir la encomienda de café, estado *En tránsito*, observación `Salió de Lima`.
2. Ir a *Registrar encomienda*: la encomienda ahora está **En tránsito**.
   *Explicar:* `MovimientoServiceImp.save()` llama a `encomiendaRepository.actualizarEstado(...)`.

### Ejemplo 7 — Viaje con vehículo en mantenimiento (mejora)
1. *Transporte › Viajes*: vehículo `X3C-369` (Mantenimiento) → error.
2. Conductor *Jorge Flores* (Inactivo) → error.
3. Con `Z2B-147` y *Luis Condori* sí se guarda.

### Ejemplo 8 — Integridad referencial al eliminar
1. Intentar eliminar el cliente *Agroexportadora Los Andes* (tiene encomiendas).
2. Mensaje "No se puede eliminar: el registro se usa en otra tabla" → la FK de la BD lo impide.

### Ejemplo 9 — Roles
1. Cerrar sesión y entrar como **operador / 123456** → no aparecen Transporte ni Seguridad.

---

## 9. Preguntas que puede hacer el profesor

**1. ¿Qué arquitectura usa el proyecto?**
Arquitectura en capas: Model, Repository, Service, Controller y View (FXML). Cada capa solo habla con la de abajo. Es la misma estructura de SysVentas.

**2. ¿Dónde y cómo se conecta a la base de datos?**
En `config/DatabaseConfig`. Lee `application.properties` (URL `jdbc:h2:file:~/SysTransporte/data/systransporte`), crea un pool de conexiones HikariCP y ejecuta `schema_transporte.sql`. Los repositorios piden la conexión con `openConnection()`.

**3. ¿Qué es HikariCP y para qué sirve?**
Es un pool de conexiones: mantiene conexiones abiertas y las reutiliza, en vez de abrir una nueva en cada consulta. Es más rápido. Aquí el máximo es 5.

**4. ¿Por qué el script SQL no duplica datos si se ejecuta en cada arranque?**
Porque es idempotente: `CREATE TABLE IF NOT EXISTS`, `MERGE INTO ... KEY (...)` y `INSERT ... WHERE NOT EXISTS`.

**5. ¿Qué es `AppContext`?**
Un contenedor de inyección de dependencias manual (patrón Singleton). Crea los repositorios, se los pasa a los servicios por constructor, y los servicios a los controladores. `getBean(Clase)` devuelve el objeto. Es lo que haría Spring con `@Autowired`.

**6. ¿Cómo sabe JavaFX qué controlador usar con sus servicios?**
Con `fxmlLoader.setControllerFactory(appContext::getBean)`: en vez de hacer `new Controller()`, el FXMLLoader le pide el controlador ya armado al `AppContext`.

**7. ¿Qué pilares de POO se ven?**
- **Herencia:** `ClienteRepository extends AbstractJpaRepository`, `ClienteServiceImp extends CrudGenericoServiceImp`.
- **Abstracción:** clases abstractas (`SqlHelper`, `AbstractJpaRepository`) e interfaces (`ICrudGenericoService`).
- **Polimorfismo:** `ViajeServiceImp` sobrescribe (`@Override`) `save()` para agregar validaciones; el controlador llama a `save()` sin saber cuál se ejecuta.
- **Encapsulamiento:** atributos `private` con getters/setters generados por Lombok.

**8. ¿Para qué sirven los genéricos `<T, ID>`?**
Para escribir el CRUD una sola vez y reutilizarlo con cualquier entidad y cualquier tipo de clave (`String` para clientes, `Long` para personas).

**9. ¿Qué es `mapRow`?**
Un método abstracto que convierte una fila del `ResultSet` en un objeto Java. Cada repositorio lo implementa (patrón *Template Method*: el padre define el algoritmo, el hijo un paso).

**10. ¿Por qué se usa `PreparedStatement` con `?`**
Evita la inyección SQL y maneja bien los tipos (fechas, decimales). Los valores se ponen con `setParams`.

**11. ¿Cómo funciona la transacción al guardar?**
En `AbstractJpaRepository.save()`: `setAutoCommit(false)`, ejecuta el insert, `commit()`. Si hay error, `rollback()` y no queda nada a medias.

**12. ¿Cuál es la diferencia entre la validación del modelo y la del servicio?**
La del **modelo** (Jakarta: `@NotBlank`, `@Pattern`) revisa el formato del dato sin ir a la BD. La del **servicio** es regla de negocio y puede consultar la BD (ej. DNI duplicado, capacidad del vehículo).

**13. ¿Cómo se evita un DNI duplicado?**
`PersonaServiceImp.validarDuplicado()` llama a `repo.existeDuplicado("dni", dni, idActual)`, que hace `SELECT COUNT(*) FROM persona WHERE dni = ? AND id_persona <> ?`. Se excluye el id actual para poder editar sin que choque consigo mismo.

**14. ¿Por qué `Encomienda` tiene un objeto `Cliente` y no solo un `String idCliente`?**
Es **asociación/composición entre clases** (como `Producto` tiene `Marca` en SysVentas). Así la tabla puede mostrar `idCliente.razonSocial`. El repositorio llena el objeto con un `JOIN`.

**15. ¿Cómo se hace el JOIN doble a persona en encomienda?**
Con alias: `JOIN persona pr ON t.id_remitente = pr.id_persona JOIN persona pd ON t.id_destinatario = pd.id_persona`, y las columnas se renombran (`pr.nombre AS pr_nombre`).

**16. ¿Cómo se generan los códigos `CLI0001`?**
`AbstractJpaRepository.generarCodigo(conn, "CLI")` busca el mayor número con ese prefijo y le suma 1. Las tablas con PK INTEGER usan `IDENTITY` (autoincremento de la BD).

**17. ¿Qué pasa si elimino un cliente que tiene encomiendas?**
La BD lo impide por la clave foránea (`REFERENCES clientes`). El controlador atrapa la excepción y muestra "No se puede eliminar: el registro se usa en otra tabla".

**18. ¿Para qué son los `enum`?**
Para valores fijos (estados, tipos, roles). Evitan errores de escritura; en la BD se guarda `name()` (ej. `EN_TRANSITO`) y en pantalla se ve `toString()` (ej. "En tránsito").

**19. ¿Cómo se controlan los permisos por rol?**
Al iniciar sesión el rol queda en `SessionManager`. `MenuMenuItemDaoImp.listaAccesos(rol)` devuelve solo los menús permitidos.

**20. ¿Qué patrones de diseño hay?**
Singleton (`AppContext`, `SessionManager`), Repository, Template Method (`mapRow`, `insert`), Inyección de dependencias por constructor (`@RequiredArgsConstructor`), Builder (Lombok `@Builder`), MVC en la vista.

**21. ¿Qué cambiaste del modelo `.architect`?**
Solo se agregó `clave` a la tabla `usuarios` para poder hacer login. Todo lo demás (14 tablas, columnas y FK) es igual al modelo.

**22. ¿Cómo cambiarías a MySQL?**
Agregar el driver `mysql-connector-j` al `pom.xml`, `requires` en `module-info` si hace falta, cambiar `db.url`, usuario y clave en `application.properties`, y ajustar el script (`AUTO_INCREMENT` en vez de `IDENTITY`). El resto del código no cambia porque usa JDBC.

**23. ¿Cómo agregarías un módulo nuevo?** (receta)
Crear tabla en el script → `model` → `XRepository extends AbstractJpaRepository` → `IXService` + `XServiceImp` → `XController` + `main_x.fxml` → registrar las 3 capas en `AppContext` → agregar el ítem en `MenuMenuItemDaoImp`.
