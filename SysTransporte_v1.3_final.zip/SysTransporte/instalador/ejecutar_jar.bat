@echo off
REM Ejecuta el .jar (requiere Java 21 instalado). Para usuarios finales use el instalador.
cd /d "%~dp0.."
if exist target\SysTransporte.jar (java -jar target\SysTransporte.jar) else (java -jar SysTransporte.jar)
if errorlevel 1 pause
