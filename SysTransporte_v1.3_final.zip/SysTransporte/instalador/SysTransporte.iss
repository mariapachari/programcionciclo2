﻿; ============================================================
;  Instalador de SysTransporte para Windows (Inno Setup 6)
;  Lo usa automáticamente instalador\construir_instalador.bat
;  Requiere haber generado antes: target\app\SysTransporte (jpackage)
; ============================================================
#define AppName "SysTransporte"
#define AppVersion "1.3.0"
#define AppPublisher "SysTransporte - Proyecto POO"
#define AppExe "SysTransporte.exe"

[Setup]
AppId={{6B0C7E3A-8E52-4B57-9A55-5F3C2D1A9E10}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
; Se puede instalar sin ser administrador (para el usuario actual) o para todos
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=..\target\instalador
OutputBaseFilename=SysTransporte-Setup-{#AppVersion}
SetupIconFile=systransporte.ico
UninstallDisplayIcon={app}\{#AppExe}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"

[Files]
; Aplicación + Java (JRE) incluido: el usuario NO necesita instalar Java
Source: "..\target\app\SysTransporte\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\docs\Manual_de_Usuario_SysTransporte.pdf"; DestDir: "{app}\docs"; Flags: ignoreversion skipifsourcedoesntexist

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{autoprograms}\Manual de usuario SysTransporte"; Filename: "{app}\docs\Manual_de_Usuario_SysTransporte.pdf"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "Abrir SysTransporte ahora"; Flags: nowait postinstall skipifsilent
