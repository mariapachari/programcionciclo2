@echo off
REM ==================================================================
REM  SysTransporte - Genera el .jar, la app .exe y el instalador Windows
REM  Requisitos en la PC donde se ejecuta (solo para CONSTRUIR):
REM    - JDK 21 (trae jpackage):  winget install EclipseAdoptium.Temurin.21.JDK
REM    - Inno Setup 6 (opcional): winget install JRSoftware.InnoSetup
REM  Resultado en la carpeta target\ :
REM    SysTransporte.jar                         (ejecutable: java -jar)
REM    app\SysTransporte\SysTransporte.exe       (exe con Java incluido)
REM    instalador\SysTransporte-Setup-1.3.0.exe  (instalador para Windows)
REM    instalador\SysTransporte-1.3.0-portable.zip
REM ==================================================================
setlocal
chcp 65001 >nul
cd /d "%~dp0.."
set VERSION=1.3.0

echo.
echo [1/5] Verificando JDK 21...
where jpackage >nul 2>&1
if errorlevel 1 goto :sinjdk

echo [2/5] Compilando, probando y empaquetando el .jar con Maven...
call mvnw.cmd -B clean package
if errorlevel 1 goto :errorbuild
if not exist target\SysTransporte.jar goto :errorbuild

echo [3/5] Creando SysTransporte.exe con Java incluido (jpackage)...
if exist target\dist rmdir /s /q target\dist
if exist target\app rmdir /s /q target\app
mkdir target\dist
copy /y target\SysTransporte.jar target\dist\ >nul
jpackage --type app-image --name SysTransporte --app-version %VERSION% --vendor "SysTransporte" --description "Sistema de Transporte de Carga" --input target\dist --main-jar SysTransporte.jar --main-class pe.edu.upeu.systransporte.App --icon instalador\systransporte.ico --java-options "-Dfile.encoding=UTF-8" --dest target\app
if errorlevel 1 goto :errorjpackage

echo [4/5] Creando version portable (ZIP)...
if not exist target\instalador mkdir target\instalador
powershell -NoProfile -Command "Compress-Archive -Path 'target\app\SysTransporte' -DestinationPath 'target\instalador\SysTransporte-%VERSION%-portable.zip' -Force"

echo [5/5] Creando el instalador .exe...
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if defined ISCC goto :inno

where candle.exe >nul 2>&1
if errorlevel 1 goto :sininstalador
echo     Inno Setup no encontrado; usando jpackage + WiX...
jpackage --type exe --app-image target\app\SysTransporte --name SysTransporte --app-version %VERSION% --vendor "SysTransporte" --win-menu --win-shortcut --win-dir-chooser --win-per-user-install --dest target\instalador
if errorlevel 1 goto :sininstalador
goto :fin

:inno
"%ISCC%" /Q instalador\SysTransporte.iss
if errorlevel 1 goto :sininstalador
goto :fin

:sininstalador
echo.
echo  AVISO: no se encontro Inno Setup 6 ni WiX 3, por eso no se creo el Setup.exe.
echo  Instale Inno Setup con:  winget install JRSoftware.InnoSetup
echo  y vuelva a ejecutar este archivo. Igual ya tiene:
echo    - target\SysTransporte.jar
echo    - target\app\SysTransporte\SysTransporte.exe
echo    - target\instalador\SysTransporte-%VERSION%-portable.zip
goto :abrir

:fin
echo.
echo  LISTO. Instalador creado en target\instalador
:abrir
explorer target\instalador
pause
exit /b 0

:sinjdk
echo  ERROR: no se encontro "jpackage". Instale el JDK 21 con:
echo     winget install EclipseAdoptium.Temurin.21.JDK
echo  Cierre esta ventana, abra una nueva y ejecute otra vez este archivo.
pause
exit /b 1

:errorbuild
echo  ERROR: Maven no pudo compilar el proyecto. Revise los mensajes de arriba.
pause
exit /b 1

:errorjpackage
echo  ERROR: jpackage no pudo crear la aplicacion.
pause
exit /b 1
