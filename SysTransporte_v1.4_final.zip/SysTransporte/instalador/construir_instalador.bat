@echo off
REM ==================================================================
REM  SysTransporte - CREA EL INSTALADOR DE WINDOWS (.exe) CON UN CLIC
REM  Si falta algo, lo instala solo con winget (Windows 10/11):
REM    - JDK 21 (trae jpackage)  -> EclipseAdoptium.Temurin.21.JDK
REM    - Inno Setup 6            -> JRSoftware.InnoSetup
REM  Necesita internet la primera vez (descarga JDK, Inno Setup y librerias Maven).
REM  Resultado:
REM    target\instalador\SysTransporte-Setup-1.4.0.exe   (INSTALADOR)
REM    target\instalador\SysTransporte-1.4.0-portable.zip
REM    target\instalador\SysTransporte.jar
REM ==================================================================
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0.."
set VERSION=1.4.0

echo.
echo ===== SysTransporte: creando el instalador para Windows =====
echo.
echo [1/6] Buscando el JDK 21...
call :buscar_jdk
if defined JDKBIN goto :jdk_ok
where winget >nul 2>&1
if errorlevel 1 goto :sinwinget
echo     No se encontro. Instalando JDK 21 (Temurin) con winget...
winget install -e --id EclipseAdoptium.Temurin.21.JDK --accept-package-agreements --accept-source-agreements --silent
call :buscar_jdk
if not defined JDKBIN goto :sinjdk
:jdk_ok
set "PATH=%JDKBIN%;%PATH%"
for %%d in ("%JDKBIN%\..") do set "JAVA_HOME=%%~fd"
echo     JDK: %JAVA_HOME%

echo [2/6] Compilando, probando y empaquetando el .jar (Maven)...
call mvnw.cmd -B clean package
if errorlevel 1 goto :errorbuild
if not exist target\SysTransporte.jar goto :errorbuild

echo [3/6] Creando SysTransporte.exe con Java incluido (jpackage)...
if exist target\dist rmdir /s /q target\dist
if exist target\app rmdir /s /q target\app
mkdir target\dist
copy /y target\SysTransporte.jar target\dist\ >nul
jpackage --type app-image --name SysTransporte --app-version %VERSION% --vendor "SysTransporte" --description "Sistema de Transporte de Carga" --input target\dist --main-jar SysTransporte.jar --main-class pe.edu.upeu.systransporte.App --icon instalador\systransporte.ico --java-options "-Dfile.encoding=UTF-8" --dest target\app
if errorlevel 1 goto :errorjpackage

echo [4/6] Creando version portable (ZIP)...
if not exist target\instalador mkdir target\instalador
copy /y target\SysTransporte.jar target\instalador\ >nul
powershell -NoProfile -Command "Compress-Archive -Path 'target\app\SysTransporte' -DestinationPath 'target\instalador\SysTransporte-%VERSION%-portable.zip' -Force"

echo [5/6] Buscando Inno Setup 6...
call :buscar_inno
if defined ISCC goto :inno
where winget >nul 2>&1
if errorlevel 1 goto :sininno
echo     No se encontro. Instalando Inno Setup 6 con winget...
winget install -e --id JRSoftware.InnoSetup --accept-package-agreements --accept-source-agreements --silent
call :buscar_inno
if not defined ISCC goto :sininno

:inno
echo [6/6] Creando el instalador SysTransporte-Setup-%VERSION%.exe...
"%ISCC%" /Q instalador\SysTransporte.iss
if errorlevel 1 goto :sininno
echo.
echo  ================================================================
echo   LISTO. Instalador creado:
echo   target\instalador\SysTransporte-Setup-%VERSION%.exe
echo  ================================================================
explorer target\instalador
pause
exit /b 0

REM ---------------- funciones ----------------
:buscar_jdk
set "JDKBIN="
where jpackage >nul 2>&1 && for /f "delims=" %%p in ('where jpackage') do if not defined JDKBIN set "JDKBIN=%%~dpp"
if defined JDKBIN (set "JDKBIN=%JDKBIN:~0,-1%" & exit /b 0)
for /d %%d in ("%ProgramFiles%\Eclipse Adoptium\jdk-21*") do if exist "%%d\bin\jpackage.exe" set "JDKBIN=%%d\bin"
if not defined JDKBIN for /d %%d in ("%ProgramFiles%\Java\jdk-21*") do if exist "%%d\bin\jpackage.exe" set "JDKBIN=%%d\bin"
exit /b 0

:buscar_inno
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
exit /b 0

REM ---------------- errores ----------------
:sinwinget
echo  ERROR: no hay JDK 21 ni winget. Instale el JDK 21 desde https://adoptium.net
echo  (elija "JDK 21 - Windows x64 .msi") y ejecute otra vez este archivo.
pause
exit /b 1

:sinjdk
echo  ERROR: no se pudo instalar el JDK 21. Instalelo desde https://adoptium.net
echo  y ejecute otra vez este archivo.
pause
exit /b 1

:sininno
echo.
echo  AVISO: no se pudo usar Inno Setup, por eso no se creo el Setup.exe.
echo  Instalelo desde https://jrsoftware.org/isdl.php y ejecute otra vez este archivo.
echo  Igual ya tiene en target\instalador: SysTransporte.jar y la version portable (ZIP).
explorer target\instalador
pause
exit /b 1

:errorbuild
echo  ERROR: Maven no pudo compilar el proyecto (revise los mensajes de arriba
echo  y que tenga internet para descargar las librerias la primera vez).
pause
exit /b 1

:errorjpackage
echo  ERROR: jpackage no pudo crear la aplicacion.
pause
exit /b 1
