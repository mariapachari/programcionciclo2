# SysTransporte — Sistema de Transporte de Carga (POO) · v1.4.0

Proyecto JavaFX con arquitectura en capas **Model → Repository → Service → Controller → View (FXML)**,
inyección de dependencias manual (`AppContext`), base de datos **H2 + HikariCP**, validación con **Jakarta Validation**
y empaquetado como **.jar** y **instalador para Windows (.exe)**.

## Entregables del proyecto final

| N° | Requerimiento | Dónde está |
|----|---------------|-----------|
| 0 | Caso y lista de requerimientos | `docs/01_Lista_de_Requerimientos_SysTransporte.pdf` |
| 0 | Modelo de BD (SQL Power Architect) | `db/transporte_carga_poo.architect` |
| 0 | Código en GitHub (privado + `dmamanipar`) | ejecutar `subir_a_github.bat` |
| 1 | Repositorio, Servicio y Controllers | `src/main/java/.../repository`, `service`, `controller` |
| 2 | Manual de usuario por roles | `docs/Manual_de_Usuario_SysTransporte.pdf` |
| 3 | Empaquetado .jar / .exe | `mvnw clean package` → `target/SysTransporte.jar`; `instalador/construir_instalador.bat` |
| 4 | Interfaz en JavaFX | `src/main/resources/view/*.fxml` |
| 5 | Validación y mensajes | anotaciones en `model/`, controladores (`lbnMsg`, `Toast`, `ToltipCustom`) |
| 6 | Investigación adicional | `security/PasswordEncoder` (PBKDF2), `security/ControlIntentosLogin`, `components/PaginadorTabla`, instalador jpackage + Inno Setup, GitHub Actions, JUnit |
| 7–8 | Exposición / examen | `docs/Guia_de_Exposicion_y_Preguntas.pdf` |
| 9 | Instalador Windows | doble clic en `CREAR_INSTALADOR_EXE.bat` → `target/instalador/SysTransporte-Setup-1.4.0.exe` |

## Generar el instalador de Windows (.exe)

**Opción A – en su PC (Windows 10/11): doble clic en `CREAR_INSTALADOR_EXE.bat`.**
Si falta el JDK 21 o Inno Setup 6, el script los instala solo con `winget` (acepte el aviso de Windows).
La primera vez necesita internet (≈ 10 minutos).

Resultado en `target\instalador\`: `SysTransporte-Setup-1.4.0.exe` (instalador), `SysTransporte-1.4.0-portable.zip`
y en `target\`: `SysTransporte.jar`.

**Opción B – automático en GitHub:** al subir el código (`subir_a_github.bat`) el workflow
`.github/workflows/instalador-windows.yml` compila en Windows y deja el Setup.exe en
*Actions → última ejecución → Artifacts*. Con una etiqueta `v1.4.0` lo publica como *Release*.

El instalador incluye su propio Java (no hay que instalar nada en la PC del usuario final).

## Investigación adicional (v1.3)

- **Encriptación de claves**: PBKDF2-HMAC-SHA256, 65 536 iteraciones, sal aleatoria de 16 bytes (`security/PasswordEncoder`).
  Las claves antiguas en texto plano se migran solas al arrancar.
- **Bloqueo por intentos fallidos**: 3 errores → 30 s de bloqueo (`security/ControlIntentosLogin`).
- **Paginación** en las 14 tablas: 5/10/20/50 filas, navegación « ‹ › » (`components/PaginadorTabla`).
- **Tercer rol CONDUCTOR**: ve Seguimiento, Entregas y Gastos.
- **Instalador Windows** con `jpackage` + Inno Setup y compilación en la nube con **GitHub Actions**.
- **Boletas/facturas solo a RUC registrados (v1.4)**: el comprobante guarda el RUC; al escribirlo se muestra la razón social o «RUC no registrado»; el Service rechaza RUC inexistentes y la impresión vuelve a verificarlo.
- **Pruebas unitarias** JUnit 5 (`src/test/java`).
- La BD se guarda en `%USERPROFILE%\SysTransporte\data` y los datos de prueba se cargan **solo la primera vez**.

## Cómo ejecutar

1. Abrir la carpeta `SysTransporte` en IntelliJ IDEA (se detecta como proyecto Maven).
2. Esperar a que Maven descargue las dependencias.
3. Ejecutar `pe.edu.upeu.systransporte.App` **o** en terminal: `mvn clean javafx:run`

Al arrancar, `DatabaseConfig` crea `~/SysTransporte/data/systransporte.mv.db`, ejecuta
`schema_transporte.sql` (crea las 14 tablas si no existen) y, solo si no hay usuarios, `datos_iniciales.sql`.

| Usuario  | Clave  | Rol           | Ve                                                     |
|----------|--------|---------------|--------------------------------------------------------|
| admin    | 123456 | ADMINISTRADOR | Todos los módulos                                      |
| operador | 123456 | OPERADOR      | Clientes, Personas, Encomiendas, Paquetes, Seguimiento, Entregas, Comprobantes |
| conductor| 123456 | CONDUCTOR     | Seguimiento, Entregas, Gastos de viaje                 |

> Para empezar de cero, cierra la app y borra la carpeta `%USERPROFILE%\SysTransporte\data`.

## Estructura (igual que SysVentas)

```
src/main/java/pe/edu/upeu/systransporte
├── App.java / SysTransporte.java     ← arranque
├── config/      AppContext (DI), DatabaseConfig (H2 + Hikari)
├── model/       14 entidades (una por tabla del modelo .architect)
├── repository/  SqlHelper, AbstractJpaRepository + 14 repositorios JDBC
├── service/     ICrudGenericoService + 14 interfaces / impl (reglas de negocio)
├── controller/  Login, MainGui, Inicio + 14 controladores CRUD
├── components/  TableViewHelper, Toast, ComboHelper, ComboBoxAutoComplete...
├── dto/         ComboBoxOption, SessionManager, MenuMenuItenTO
├── enums/       Estados y tipos (EstadoEncomienda, TipoVehiculo, Rol...)
└── exception/   ModelNotFoundException
src/main/resources
├── view/        login.fxml, maingui.fxml, main_inicio.fxml + 14 main_*.fxml
├── css/         style.css (+ estilos alternativos del profe)
├── img/         logo, banners e íconos de cada módulo
└── schema_transporte.sql
```

## Tablas del modelo → módulos

| Tabla              | Módulo / menú                 | PK                         |
|--------------------|-------------------------------|----------------------------|
| clientes           | Registros › Clientes          | `CLI0001` (autogenerado)   |
| persona            | Registros › Personas          | autoincremental            |
| conductores        | Registros › Conductores       | `CON0001`                  |
| vehiculos          | Registros › Vehículos         | `VEH0001`                  |
| encomienda         | Encomiendas › Registrar       | autoincremental            |
| paquetes           | Encomiendas › Paquetes        | autoincremental            |
| movimiento         | Encomiendas › Seguimiento     | autoincremental            |
| entrega            | Encomiendas › Entregas        | autoincremental            |
| viajes             | Transporte › Viajes           | `VIA0001`                  |
| manifiesto         | Transporte › Manifiestos      | `GUI0001`, N° guía `T001-000001` |
| detalle_manifiesto | Transporte › Detalle          | autoincremental            |
| gastos             | Transporte › Gastos           | `GAS0001`                  |
| comprobantes       | Facturación › Comprobantes    | `CPB0001`, N° `B001-…`/`F001-…` |
| usuarios           | Seguridad › Usuarios          | `USU0001`                  |

## Reglas de negocio (capa Service)

- **Viaje**: la fecha de llegada no puede ser anterior a la de salida; no acepta conductor INACTIVO ni vehículo en MANTENIMIENTO.
- **Duplicados**: no se repite DNI (persona), RUC (cliente), placa (vehículo) ni nombre de usuario.
- **Encomienda**: remitente ≠ destinatario y origen ≠ destino.
- **Paquetes**: la suma de pesos no supera el peso de la encomienda.
- **Detalle de manifiesto**: no permite asignar más toneladas que la capacidad del vehículo del viaje.
- **Movimiento**: al registrar un movimiento la encomienda cambia a ese estado (seguimiento).
- **Entrega**: si el estado es *Entregado*, la encomienda pasa a *ENTREGADO*.
- **Comprobante**: el número se genera solo según el tipo (Boleta `B001-000001`, Factura `F001-000001`).
- **Eliminar**: pide confirmación y avisa si el registro está siendo usado por otra tabla (FK).

## Inicio

La pantalla de Inicio muestra un resumen leído de la BD (clientes, encomiendas, por entregar, viajes en curso, vehículos disponibles).

Manual completo, ejemplos para clase y preguntas frecuentes: **`docs/MANUAL_SYSTRANSPORTE.md`**.

## Cambio respecto al modelo .architect

Se agregó la columna `clave VARCHAR(200)` a la tabla `usuarios` (guarda el hash PBKDF2 de la clave).
El archivo `db/transporte_carga_poo.architect` ya incluye esa columna.
