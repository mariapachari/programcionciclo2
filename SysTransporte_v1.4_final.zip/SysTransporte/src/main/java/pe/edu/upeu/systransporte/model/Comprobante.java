package pe.edu.upeu.systransporte.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.systransporte.enums.*;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla "comprobantes".
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Comprobante {
    private String idComprobante;

    @NotNull(message = "El tipo de comprobante es obligatorio")
    private TipoComprobante tipo;

    private String numero;

    @NotNull(message = "Seleccione la encomienda")
    private Encomienda idEncomienda;

    /** RUC del cliente al que se emite el comprobante: debe existir en la tabla clientes. */
    @NotBlank(message = "Ingrese el RUC del cliente")
    @Pattern(regexp = "^\\d{11}$", message = "El RUC debe tener 11 dígitos")
    private String ruc;

    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;

    @NotNull(message = "El monto es obligatorio")
    @Positive(message = "El monto debe ser mayor a 0")
    private Double monto;

    @NotNull(message = "El estado de pago es obligatorio")
    private EstadoPago estadoPago;
}
