package pe.edu.upeu.systransporte.service;

import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Cliente;

import java.util.List;
import java.util.Optional;

public interface IClienteService extends ICrudGenericoService<Cliente, String> {
    List<ComboBoxOption> listarCombobox();

    /** Devuelve el cliente con ese RUC, o vacío si el RUC no está registrado. */
    Optional<Cliente> buscarPorRuc(String ruc);
}
