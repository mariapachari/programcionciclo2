package pe.edu.upeu.systransporte.config;

import pe.edu.upeu.systransporte.controller.*;
import pe.edu.upeu.systransporte.repository.*;
import pe.edu.upeu.systransporte.service.*;
import pe.edu.upeu.systransporte.service.impl.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Contenedor de Inyección de Dependencias manual (igual que en SysVentas).
 * Arma la aplicación en 3 capas: Repositorios → Servicios → Controladores.
 */
public class AppContext {

    // Singleton: una sola instancia en toda la app
    private static AppContext instance;

    public static synchronized AppContext getInstance() {
        if (instance == null) instance = new AppContext();
        return instance;
    }

    // El "directorio": Clase → Objeto
    private final Map<Class<?>, Object> contenedor = new HashMap<>();

    // Constructor privado: aquí se arma toda la aplicación
    private AppContext() {
        registrarRepositorios();
        registrarServicios();
        registrarControladores();
    }

    // CAPA 1 — REPOSITORIOS (uno por tabla del modelo)
    private void registrarRepositorios() {
        registrar(ClienteRepository.class, new ClienteRepository());
        registrar(PersonaRepository.class, new PersonaRepository());
        registrar(ConductorRepository.class, new ConductorRepository());
        registrar(VehiculoRepository.class, new VehiculoRepository());
        registrar(UsuarioRepository.class, new UsuarioRepository());
        registrar(EncomiendaRepository.class, new EncomiendaRepository());
        registrar(ViajeRepository.class, new ViajeRepository());
        registrar(ManifiestoRepository.class, new ManifiestoRepository());
        registrar(DetalleManifiestoRepository.class, new DetalleManifiestoRepository());
        registrar(PaqueteRepository.class, new PaqueteRepository());
        registrar(EntregaRepository.class, new EntregaRepository());
        registrar(MovimientoRepository.class, new MovimientoRepository());
        registrar(ComprobanteRepository.class, new ComprobanteRepository());
        registrar(GastoRepository.class, new GastoRepository());
    }

    // CAPA 2 — SERVICIOS (reciben su repositorio por constructor)
    private void registrarServicios() {
        registrar(IClienteService.class, new ClienteServiceImp(getBean(ClienteRepository.class)));
        registrar(IPersonaService.class, new PersonaServiceImp(getBean(PersonaRepository.class)));
        registrar(IConductorService.class, new ConductorServiceImp(getBean(ConductorRepository.class)));
        registrar(IVehiculoService.class, new VehiculoServiceImp(getBean(VehiculoRepository.class)));
        registrar(IUsuarioService.class, new UsuarioServiceImp(getBean(UsuarioRepository.class)));
        registrar(IEncomiendaService.class, new EncomiendaServiceImp(getBean(EncomiendaRepository.class)));
        registrar(IViajeService.class, new ViajeServiceImp(getBean(ViajeRepository.class)));
        registrar(IManifiestoService.class, new ManifiestoServiceImp(getBean(ManifiestoRepository.class)));
        registrar(IDetalleManifiestoService.class, new DetalleManifiestoServiceImp(getBean(DetalleManifiestoRepository.class)));
        registrar(IPaqueteService.class, new PaqueteServiceImp(getBean(PaqueteRepository.class)));
        registrar(IEntregaService.class, new EntregaServiceImp(getBean(EntregaRepository.class), getBean(EncomiendaRepository.class)));
        registrar(IMovimientoService.class, new MovimientoServiceImp(getBean(MovimientoRepository.class), getBean(EncomiendaRepository.class)));
        registrar(IComprobanteService.class, new ComprobanteServiceImp(getBean(ComprobanteRepository.class), getBean(ClienteRepository.class)));
        registrar(IGastoService.class, new GastoServiceImp(getBean(GastoRepository.class)));

        registrar(IMenuMenuItemDao.class, new MenuMenuItemDaoImp());
    }

    // CAPA 3 — CONTROLADORES JavaFX (reciben los servicios que necesitan)
    private void registrarControladores() {
        registrar(LoginController.class, new LoginController(getBean(IUsuarioService.class)));
        registrar(MainGuiController.class, new MainGuiController(getBean(IMenuMenuItemDao.class)));
        registrar(InicioController.class, new InicioController(
                getBean(IClienteService.class),
                getBean(IEncomiendaService.class),
                getBean(IViajeService.class),
                getBean(IVehiculoService.class)));

        registrar(ClienteController.class, new ClienteController(
                getBean(IClienteService.class)));
        registrar(PersonaController.class, new PersonaController(
                getBean(IPersonaService.class)));
        registrar(ConductorController.class, new ConductorController(
                getBean(IConductorService.class)));
        registrar(VehiculoController.class, new VehiculoController(
                getBean(IVehiculoService.class)));
        registrar(UsuarioController.class, new UsuarioController(
                getBean(IUsuarioService.class)));
        registrar(EncomiendaController.class, new EncomiendaController(
                getBean(IEncomiendaService.class),
                getBean(IClienteService.class),
                getBean(IPersonaService.class)));
        registrar(ViajeController.class, new ViajeController(
                getBean(IViajeService.class),
                getBean(IConductorService.class),
                getBean(IVehiculoService.class)));
        registrar(ManifiestoController.class, new ManifiestoController(
                getBean(IManifiestoService.class),
                getBean(IViajeService.class),
                getBean(IDetalleManifiestoService.class),
                getBean(IEncomiendaService.class)));
        registrar(DetalleManifiestoController.class, new DetalleManifiestoController(
                getBean(IDetalleManifiestoService.class),
                getBean(IManifiestoService.class),
                getBean(IEncomiendaService.class)));
        registrar(PaqueteController.class, new PaqueteController(
                getBean(IPaqueteService.class),
                getBean(IEncomiendaService.class)));
        registrar(EntregaController.class, new EntregaController(
                getBean(IEntregaService.class),
                getBean(IEncomiendaService.class)));
        registrar(MovimientoController.class, new MovimientoController(
                getBean(IMovimientoService.class),
                getBean(IEncomiendaService.class)));
        registrar(ComprobanteController.class, new ComprobanteController(
                getBean(IComprobanteService.class),
                getBean(IEncomiendaService.class),
                getBean(IClienteService.class),
                getBean(IPaqueteService.class)));
        registrar(GastoController.class, new GastoController(
                getBean(IGastoService.class),
                getBean(IViajeService.class)));
    }

    /** Guarda un objeto en el directorio, indexado por su tipo o interfaz. */
    private void registrar(Class<?> tipo, Object bean) {
        contenedor.put(tipo, bean);
    }

    /** Busca y devuelve un objeto por su tipo o interfaz. */
    @SuppressWarnings("unchecked")
    public <T> T getBean(Class<T> tipo) {
        Object bean = contenedor.get(tipo);
        if (bean == null) {
            bean = contenedor.values().stream()
                    .filter(b -> tipo.isAssignableFrom(b.getClass()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException(
                            "Bean no encontrado: " + tipo.getName() +
                                    "\n→ ¿Lo registraste en AppContext?"));
        }
        return (T) bean;
    }
}
