package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.enums.*;
import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class ComprobanteRepository extends AbstractJpaRepository<Comprobante, String> {

    @Override
    protected String getTableName() { return "comprobantes"; }

    @Override
    protected String getPkColumn() { return "idComprobante"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    ", en.descripcionCarga AS en_descripcionCarga" +
                    " FROM comprobantes t " +
                    "JOIN encomienda en ON t.id_encomienda = en.id_encomienda ";

    @Override
    public List<Comprobante> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idComprobante DESC");
    }

    @Override
    public Optional<Comprobante> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idComprobante = ?", id);
    }

    @Override
    protected Comprobante mapRow(ResultSet rs) throws SQLException {
        return Comprobante.builder()
                .idComprobante(rs.getString("idComprobante"))
                .tipo(toEnum(TipoComprobante.class, rs.getString("tipo")))
                .numero(rs.getString("numero"))
                .ruc(rs.getString("ruc"))
                .idEncomienda(Encomienda.builder()
                        .idEncomienda(rs.getLong("id_encomienda"))
                        .descripcionCarga(rs.getString("en_descripcionCarga"))
                        .build())
                .fecha(rs.getObject("fecha", LocalDate.class))
                .monto(rs.getDouble("monto"))
                .estadoPago(toEnum(EstadoPago.class, rs.getString("estadoPago")))
                .build();
    }

    @Override
    protected Comprobante insert(Connection conn, Comprobante e) throws SQLException {
        if (e.getIdComprobante() == null || e.getIdComprobante().isBlank()) {
            e.setIdComprobante(generarCodigo(conn, "CPB"));
        }
        if (e.getNumero() == null || e.getNumero().isBlank()) {
            e.setNumero(generarCorrelativo(conn, "numero", e.getTipo() == TipoComprobante.FACTURA ? "F001" : "B001"));
        }
        executeUpdate(conn,
                "INSERT INTO comprobantes(idComprobante, tipo, numero, ruc, id_encomienda, fecha, monto, estadoPago) VALUES(?, ?, ?, ?, ?, ?, ?, ?)",
                e.getIdComprobante(),
                enumName(e.getTipo()),
                e.getNumero(),
                e.getRuc(),
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getFecha(),
                e.getMonto(),
                enumName(e.getEstadoPago()));
        return e;
    }

    @Override
    protected Comprobante updateRow(Connection conn, Comprobante e) throws SQLException {
        executeUpdate(conn,
                "UPDATE comprobantes SET tipo = ?, ruc = ?, id_encomienda = ?, fecha = ?, monto = ?, estadoPago = ? WHERE idComprobante = ?",
                enumName(e.getTipo()),
                e.getRuc(),
                e.getIdEncomienda() == null ? null : e.getIdEncomienda().getIdEncomienda(),
                e.getFecha(),
                e.getMonto(),
                enumName(e.getEstadoPago()),
                e.getIdComprobante());
        return e;
    }
}
