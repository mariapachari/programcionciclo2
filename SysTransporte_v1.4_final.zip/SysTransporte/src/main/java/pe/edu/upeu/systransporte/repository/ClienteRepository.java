package pe.edu.upeu.systransporte.repository;

import pe.edu.upeu.systransporte.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ClienteRepository extends AbstractJpaRepository<Cliente, String> {

    @Override
    protected String getTableName() { return "clientes"; }

    @Override
    protected String getPkColumn() { return "idCliente"; }

    private static final String SELECT_JOIN =
            "SELECT t.*" +
                    " FROM clientes t ";

    @Override
    public List<Cliente> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.idCliente ASC");
    }

    @Override
    public Optional<Cliente> findById(String id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.idCliente = ?", id);
    }

    /** Busca un cliente por su RUC (para validar e imprimir comprobantes). */
    public Optional<Cliente> findByRuc(String ruc) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.ruc = ?", ruc == null ? null : ruc.trim());
    }

    @Override
    protected Cliente mapRow(ResultSet rs) throws SQLException {
        return Cliente.builder()
                .idCliente(rs.getString("idCliente"))
                .razonSocial(rs.getString("razonSocial"))
                .ruc(rs.getString("ruc"))
                .telefono(rs.getString("telefono"))
                .correo(rs.getString("correo"))
                .build();
    }

    @Override
    protected Cliente insert(Connection conn, Cliente e) throws SQLException {
        if (e.getIdCliente() == null || e.getIdCliente().isBlank()) {
            e.setIdCliente(generarCodigo(conn, "CLI"));
        }
        executeUpdate(conn,
                "INSERT INTO clientes(idCliente, razonSocial, ruc, telefono, correo) VALUES(?, ?, ?, ?, ?)",
                e.getIdCliente(),
                e.getRazonSocial(),
                e.getRuc(),
                e.getTelefono(),
                e.getCorreo());
        return e;
    }

    @Override
    protected Cliente updateRow(Connection conn, Cliente e) throws SQLException {
        executeUpdate(conn,
                "UPDATE clientes SET razonSocial = ?, ruc = ?, telefono = ?, correo = ? WHERE idCliente = ?",
                e.getRazonSocial(),
                e.getRuc(),
                e.getTelefono(),
                e.getCorreo(),
                e.getIdCliente());
        return e;
    }
}
