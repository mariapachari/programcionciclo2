package pe.edu.upeu.systransporte.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.systransporte.dto.ComboBoxOption;
import pe.edu.upeu.systransporte.model.Comprobante;
import pe.edu.upeu.systransporte.repository.ICrudGenericoRepository;
import pe.edu.upeu.systransporte.repository.ClienteRepository;
import pe.edu.upeu.systransporte.repository.ComprobanteRepository;
import pe.edu.upeu.systransporte.service.IComprobanteService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class ComprobanteServiceImp extends CrudGenericoServiceImp<Comprobante, String> implements IComprobanteService {

    private final ComprobanteRepository repo;
    private final ClienteRepository clienteRepo;

    @Override
    protected ICrudGenericoRepository<Comprobante, String> getRepo() {
        return repo;
    }

    /** Regla de negocio: solo se emiten comprobantes a un RUC registrado en Clientes. */
    private void validarRuc(Comprobante x) {
        String ruc = x.getRuc() == null ? "" : x.getRuc().trim();
        if (!ruc.matches("\\d{11}")) {
            throw new IllegalArgumentException("El RUC debe tener 11 dígitos");
        }
        if (clienteRepo.findByRuc(ruc).isEmpty()) {
            throw new IllegalArgumentException("El RUC " + ruc
                    + " no está registrado. Regístrelo primero en Registros › Clientes");
        }
        x.setRuc(ruc);
    }

    @Override
    public Comprobante save(Comprobante x) {
        validarRuc(x);
        return super.save(x);
    }

    @Override
    public Comprobante update(String id, Comprobante x) {
        validarRuc(x);
        return super.update(id, x);
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Comprobante x : repo.findAll()) {
            listar.add(new ComboBoxOption(String.valueOf(x.getIdComprobante()), x.getNumero()));
        }
        return listar;
    }
}
