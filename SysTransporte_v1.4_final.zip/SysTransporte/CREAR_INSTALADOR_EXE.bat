@echo off
REM Doble clic aqui para crear el instalador SysTransporte-Setup-1.4.0.exe
call "%~dp0instalador\construir_instalador.bat"
